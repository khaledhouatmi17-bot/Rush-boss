import * as THREE from 'three';
import { SwordTrail } from './vfx.js';
import {
  buildStylizedPlayerRig,
  createContactAuraMesh,
  createCharacterAuraRing,
  updateRimShaderUniforms,
} from './stylized.js';
import { GLBAnimationController, disposeObject3D } from './modelManager.js';

export const PlayerState = {
  IDLE: 'IDLE',
  MOVE: 'MOVE',
  ATTACK: 'ATTACK',
  HEAVY: 'HEAVY',
  SKILL: 'SKILL',
  DODGE: 'DODGE',
  PARRY: 'PARRY',
  HIT: 'HIT',
  DEATH: 'DEATH',
  VICTORY: 'VICTORY',
};

const COMBO_CONFIG = [
  { clip: 'ATTACK_1', duration: 0.46, hitStart: 0.11, hitEnd: 0.30, damage: 88, poise: 16, knockback: 0.6, range: 3.45, stepSpeed: 5.6, arcTilt: 0.22, glbSpeed: 1.95 },
  { clip: 'ATTACK_2', duration: 0.48, hitStart: 0.11, hitEnd: 0.31, damage: 112, poise: 22, knockback: 0.85, range: 3.65, stepSpeed: 6.4, arcTilt: -0.28, glbSpeed: 1.88 },
  { clip: 'ATTACK_3', duration: 0.58, hitStart: 0.15, hitEnd: 0.39, damage: 170, poise: 38, knockback: 1.75, range: 4.0, stepSpeed: 7.5, arcTilt: 0.08, glbSpeed: 1.72 },
];

export const PERFECT_PARRY_WINDOW = 0.18;
export const PARRY_BLOCK_DURATION = 0.44;
export const PERFECT_DODGE_WINDOW = 0.18;

export const PLAYER_GLB_PATHS = {
  vanguard: '/models/Knight.glb',
  crimson_paladin: '/models/Barbarian.glb',
};

function createSwordEnergyTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 128;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  const half = size / 2;
  ctx.clearRect(0, 0, size, size);
  const g = ctx.createRadialGradient(half, half, 2, half, half, half);
  g.addColorStop(0.0, 'rgba(255, 255, 255, 0.95)');
  g.addColorStop(0.28, 'rgba(130, 232, 255, 0.65)');
  g.addColorStop(0.64, 'rgba(56, 175, 255, 0.2)');
  g.addColorStop(1.0, 'rgba(20, 110, 220, 0.0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export class PlayerCharacter {
  constructor(scene) {
    this.scene = scene;
    this.root = new THREE.Group();
    this.root.position.set(0, 0, 9.5);
    this.root.rotation.y = Math.PI;

    this.maxHp = 1000;
    this.hp = 1000;
    this.maxStamina = 100;
    this.stamina = 100;
    this.staminaDelay = 0;

    this.skillCooldownMax = 7.0;
    this.skillCooldown = 0;

    this.state = PlayerState.IDLE;
    this.stateTime = 0;
    this.comboStep = 0;
    this.comboResetTimer = 0;
    this.comboHitCount = 0;
    this.queuedAction = null;
    this.attackHasHit = false;
    this.hitTargets = new Set();
    this.slashArcFired = false;
    this.heavySlamFired = false;
    this.skillBurstFired = false;
    this.parryTriggered = false;
    this.blockTriggered = false;
    this.blockRecoilTimer = 0;
    this.isHeavyFinisher = false;
    this.isCriticalStrike = false;
    this.counterBuffTimer = 0;
    this.perfectDodgeTrailTimer = 0;
    this.hitFlashTimer = 0;
    this.dodgeDir = new THREE.Vector3(0, 0, -1);
    this.dodgeClip = 'DODGE';
    this.lastStepHalf = 0;

    this.vx = 0;
    this.vz = 0;
    this.facingYaw = Math.PI;
    this.radius = 0.62;

    this.swordBaseWorld = new THREE.Vector3();
    this.swordTipWorld = new THREE.Vector3();
    this.tmpVec = new THREE.Vector3();

    this.presetId = 'vanguard';
    this.isCustomModel = false;
    this.modelRequestId = 0;
    this.rig = null;
    this.glbCtrl = null;
    this.visualGroup = null;
    this.glbSwordBase = null;
    this.glbSwordTip = null;
    this.trackedMaterials = [];

    this.weaponLight = new THREE.PointLight(0x52d6ff, 1.05, 8.5, 1.7);
    this.weaponLight.position.set(0.35, 1.35, 0.55);
    this.root.add(this.weaponLight);

    this.contactAura = createContactAuraMesh(0x52d6ff, 0.92, 0.55);
    this.root.add(this.contactAura);

    this.auraRing = createCharacterAuraRing(0x52d6ff, 0.74, 0.9, 0.34);
    this.root.add(this.auraRing);

    this.swordEnergyTex = createSwordEnergyTexture();
    this.swordEnergySprite = new THREE.Sprite(
      new THREE.SpriteMaterial({
        map: this.swordEnergyTex,
        color: 0x62e2ff,
        transparent: true,
        opacity: 0.28,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    this.swordEnergySprite.scale.set(0.95, 0.95, 1);
    this.scene.add(this.swordEnergySprite);

    // Sync stylized rig at startup so there is never an invisible frame
    this.setPreset('vanguard');
    this.trail = new SwordTrail(scene, 16, 0x62d9ff);
    this.scene.add(this.root);
  }

  _clearVisual() {
    if (this.glbCtrl) {
      this.glbCtrl.dispose();
      this.glbCtrl = null;
    }
    if (this.visualGroup) {
      this.root.remove(this.visualGroup);
      disposeObject3D(this.visualGroup);
      this.visualGroup = null;
    }
    this.rig = null;
    this.glbSwordBase = null;
    this.glbSwordTip = null;
    this.trackedMaterials = [];
  }

  setPreset(presetId = 'vanguard') {
    this.presetId = presetId;
    this.isCustomModel = false;
    this._clearVisual();
    this.rig = buildStylizedPlayerRig(presetId);
    this.visualGroup = this.rig.root;
    this.root.add(this.visualGroup);
  }

  async loadPresetGLB(glbLoader, presetId = 'vanguard') {
    this.presetId = presetId;
    this.isCustomModel = false;
    const reqId = ++this.modelRequestId;
    const url = PLAYER_GLB_PATHS[presetId] || PLAYER_GLB_PATHS.vanguard;
    try {
      const loaded = await glbLoader.loadAsync(url, 1.9, {
        stylizeToon: false,
        addOutlines: false,
        enhancePBR: true,
        hideSpareWeapons: true,
        rimColor: presetId === 'crimson_paladin' ? 0xffaa44 : 0x6ce5ff,
        rimStrength: 0.62,
      });
      if (reqId !== this.modelRequestId || this.isCustomModel) {
        disposeObject3D(loaded.scene);
        return false;
      }
      this.applyLoadedGLB(loaded, false);
      return true;
    } catch (_) {
      if (reqId === this.modelRequestId && !this.isCustomModel) {
        this.setPreset(presetId);
      }
      return false;
    }
  }

  applyCustomGLB(clonedScene, animations, swordBase = null, swordTip = null, trackedMats = []) {
    this.modelRequestId++;
    this.isCustomModel = true;
    this._applyGLBVisual(clonedScene, animations, swordBase, swordTip, trackedMats);
  }

  applyLoadedGLB(loaded, isCustom = false) {
    this.isCustomModel = isCustom;
    this._applyGLBVisual(
      loaded.scene,
      loaded.animations,
      loaded.swordBaseMarker,
      loaded.swordTipMarker,
      loaded.trackedMaterials || []
    );
  }

  _applyGLBVisual(clonedScene, animations, swordBase, swordTip, trackedMats) {
    this._clearVisual();
    this.visualGroup = clonedScene;
    this.glbSwordBase = swordBase || clonedScene.getObjectByName('SwordBase') || null;
    this.glbSwordTip = swordTip || clonedScene.getObjectByName('SwordTip') || null;
    this.trackedMaterials = trackedMats || [];
    if (this.trackedMaterials.length === 0) {
      clonedScene.traverse((n) => {
        if ((n.isMesh || n.isSkinnedMesh) && !n.name.endsWith('_outline') && n.material) {
          const mats = Array.isArray(n.material) ? n.material : [n.material];
          this.trackedMaterials.push(...mats);
        }
      });
    }
    this.root.add(this.visualGroup);
    this.glbCtrl = new GLBAnimationController(this.visualGroup, animations);
    this._syncCurrentGlbAnimation();
  }

  _syncCurrentGlbAnimation() {
    if (!this.glbCtrl) return;
    switch (this.state) {
      case PlayerState.MOVE:
        this.glbCtrl.playState('RUN');
        break;
      case PlayerState.ATTACK: {
        const cfg = COMBO_CONFIG[this.comboStep];
        this.glbCtrl.playState(cfg.clip, true, cfg.glbSpeed, 0.08);
        break;
      }
      case PlayerState.HEAVY:
        this.glbCtrl.playState('HEAVY', true, 1.95, 0.08);
        break;
      case PlayerState.SKILL:
        this.glbCtrl.playState('SKILL', true, 1.05, 0.08);
        break;
      case PlayerState.DODGE:
        this.glbCtrl.playState(this.dodgeClip || 'DODGE', true, 1.0, 0.06);
        break;
      case PlayerState.PARRY:
        this.glbCtrl.playState('PARRY', true, 1.15, 0.06);
        break;
      case PlayerState.HIT:
        this.glbCtrl.playState('HIT', true, 1.75, 0.06);
        break;
      case PlayerState.DEATH:
        this.glbCtrl.playState('DEATH', true);
        break;
      case PlayerState.VICTORY:
        this.glbCtrl.playState('VICTORY', false);
        break;
      default:
        this.glbCtrl.playState('IDLE');
        break;
    }
  }

  reset() {
    this.hp = this.maxHp;
    this.stamina = this.maxStamina;
    this.staminaDelay = 0;
    this.skillCooldown = 0;
    this.state = PlayerState.IDLE;
    this.stateTime = 0;
    this.comboStep = 0;
    this.comboResetTimer = 0;
    this.comboHitCount = 0;
    this.queuedAction = null;
    this.attackHasHit = false;
    this.hitTargets.clear();
    this.slashArcFired = false;
    this.heavySlamFired = false;
    this.skillBurstFired = false;
    this.parryTriggered = false;
    this.blockTriggered = false;
    this.blockRecoilTimer = 0;
    this.isHeavyFinisher = false;
    this.isCriticalStrike = false;
    this.counterBuffTimer = 0;
    this.perfectDodgeTrailTimer = 0;
    this.hitFlashTimer = 0;
    this.lastStepHalf = 0;
    this.vx = 0;
    this.vz = 0;
    this.root.position.set(0, 0, 9.5);
    this.facingYaw = Math.PI;
    this.root.rotation.set(0, this.facingYaw, 0);
    this.trail.update(false);
    if (this.rig) this._resetPose(1);
    this.glbCtrl?.resetTransform();
    this.glbCtrl?.playState('IDLE', false, 1.0, 0.12);
  }

  isInvulnerable() {
    if (this.state === PlayerState.DODGE) {
      return this.stateTime >= 0.02 && this.stateTime <= 0.34;
    }
    return this.state === PlayerState.DEATH || this.state === PlayerState.VICTORY;
  }

  isPerfectDodgeWindow() {
    return this.state === PlayerState.DODGE && this.stateTime >= 0.02 && this.stateTime <= PERFECT_DODGE_WINDOW;
  }

  isPerfectParrying() {
    return this.state === PlayerState.PARRY && this.stateTime <= PERFECT_PARRY_WINDOW && !this.blockTriggered;
  }

  isBlocking() {
    return (
      this.state === PlayerState.PARRY &&
      this.stateTime <= PARRY_BLOCK_DURATION &&
      (this.stateTime > PERFECT_PARRY_WINDOW || this.blockTriggered)
    );
  }

  isParrying() {
    return this.isPerfectParrying();
  }

  hasHitTarget(target) {
    return this.hitTargets.has(target);
  }

  markTargetHit(target) {
    this.hitTargets.add(target);
    this.attackHasHit = true;
  }

  canAct() {
    return (
      this.state === PlayerState.IDLE ||
      this.state === PlayerState.MOVE ||
      (this.state === PlayerState.PARRY && this.parryTriggered && this.stateTime >= 0.14) ||
      (this.state === PlayerState.ATTACK && this.stateTime > COMBO_CONFIG[this.comboStep].duration * 0.66)
    );
  }

  canCancelIntoDefense() {
    if (this.state === PlayerState.IDLE || this.state === PlayerState.MOVE) return true;
    if (this.state === PlayerState.PARRY && this.parryTriggered && this.stateTime >= 0.14) return true;
    if (this.state === PlayerState.ATTACK && this.stateTime >= COMBO_CONFIG[this.comboStep].hitEnd) return true;
    if (this.state === PlayerState.HEAVY && this.stateTime >= 0.56) return true;
    if (this.state === PlayerState.SKILL && this.stateTime >= 0.52) return true;
    return false;
  }

  triggerLightAttack(targetPos) {
    if (this.state === PlayerState.DEATH || this.state === PlayerState.VICTORY) return false;
    if (this.state === PlayerState.ATTACK) {
      if (this.stateTime > (this.comboStep < 2 ? 0.1 : 0.24)) {
        this.queuedAction = 'ATTACK';
      }
      return false;
    }
    if (this.state === PlayerState.DODGE && this.stateTime >= 0.22) {
      this.queuedAction = 'ATTACK';
      return false;
    }
    if (!this.canAct() || this.stamina < 10) return false;

    this._consumeStamina(10);
    this.comboStep = this.comboResetTimer > 0 ? (this.comboStep + 1) % 3 : 0;
    this._startComboAttack(targetPos);
    return true;
  }

  _startComboAttack(targetPos) {
    const cfg = COMBO_CONFIG[this.comboStep];
    this.state = PlayerState.ATTACK;
    this.stateTime = 0;
    this.attackHasHit = false;
    this.hitTargets.clear();
    this.slashArcFired = false;
    this.isHeavyFinisher = false;
    this.isCriticalStrike = false;
    this.queuedAction = null;
    this.vx *= 0.35;
    this.vz *= 0.35;
    if (this.rig) {
      this.rig.hips.rotation.set(0, 0, 0);
      this.rig.torso.rotation.y = 0;
    }
    this._faceTarget(targetPos);
    this.glbCtrl?.playState(cfg.clip, true, cfg.glbSpeed, 0.07);
  }

  triggerHeavyAttack(targetPos, options = {}) {
    const isCritical = !!options.isCritical;
    if (this.state === PlayerState.ATTACK && this.stateTime > 0.1 && !isCritical) {
      this.queuedAction = 'HEAVY';
      return false;
    }
    if (this.state === PlayerState.DODGE && this.stateTime >= 0.22 && !isCritical) {
      this.queuedAction = 'HEAVY';
      return false;
    }
    if (!this.canAct() || this.stamina < 24) return false;
    const chainedFromLight = this.state === PlayerState.ATTACK || this.comboResetTimer > 0;
    this._consumeStamina(24);
    this.state = PlayerState.HEAVY;
    this.stateTime = 0;
    this.attackHasHit = false;
    this.hitTargets.clear();
    this.slashArcFired = false;
    this.heavySlamFired = false;
    this.isHeavyFinisher = !isCritical && chainedFromLight;
    this.isCriticalStrike = isCritical;
    this.queuedAction = null;
    this.comboStep = 0;
    this.comboResetTimer = 0;
    this.vx *= 0.3;
    this.vz *= 0.3;
    if (this.rig) {
      this.rig.hips.rotation.set(0, 0, 0);
      this.rig.torso.rotation.y = 0;
    }
    this._faceTarget(targetPos);
    this.glbCtrl?.playState('HEAVY', true, isCritical ? 2.15 : this.isHeavyFinisher ? 2.05 : 1.95, 0.07);
    return true;
  }

  triggerSkill(targetPos) {
    if (this.state === PlayerState.ATTACK && this.stateTime > 0.12) {
      this.queuedAction = 'SKILL';
      return false;
    }
    if (this.state === PlayerState.DODGE && this.stateTime >= 0.24) {
      this.queuedAction = 'SKILL';
      return false;
    }
    if (!this.canAct() || this.skillCooldown > 0 || this.stamina < 22) return false;
    this._consumeStamina(22);
    this.skillCooldown = this.skillCooldownMax;
    this.state = PlayerState.SKILL;
    this.stateTime = 0;
    this.attackHasHit = false;
    this.hitTargets.clear();
    this.slashArcFired = false;
    this.skillBurstFired = false;
    this.queuedAction = null;
    this.vx *= 0.3;
    this.vz *= 0.3;
    if (this.rig) {
      this.rig.hips.rotation.set(0, 0, 0);
      this.rig.torso.rotation.y = 0;
    }
    this._faceTarget(targetPos);
    this.glbCtrl?.playState('SKILL', true, 1.05, 0.08);
    return true;
  }

  triggerDodge(moveVec, vfx) {
    if (
      this.state === PlayerState.DEATH ||
      this.state === PlayerState.VICTORY ||
      this.state === PlayerState.DODGE ||
      this.state === PlayerState.HIT ||
      !this.canCancelIntoDefense()
    ) {
      return false;
    }
    if (this.stamina < 18) return false;
    this._consumeStamina(18);
    this.state = PlayerState.DODGE;
    this.stateTime = 0;
    this.queuedAction = null;
    if (this.rig) {
      this.rig.hips.rotation.set(0, 0, 0);
      this.rig.torso.rotation.y = 0;
    }

    if (moveVec && moveVec.lengthSq() > 0.04) {
      this.dodgeDir.copy(moveVec).normalize();
      this.facingYaw = Math.atan2(this.dodgeDir.x, this.dodgeDir.z);
      this.dodgeClip = 'DODGE';
    } else {
      this.dodgeDir.set(-Math.sin(this.facingYaw), 0, -Math.cos(this.facingYaw));
      this.dodgeClip = 'DODGE_BACK';
    }
    this.glbCtrl?.playState(this.dodgeClip, true, 1.0, 0.06);
    vfx?.spawnDust(this.root.position, 4);
    return true;
  }

  triggerParry(targetPos, vfx) {
    if (
      this.state === PlayerState.DEATH ||
      this.state === PlayerState.VICTORY ||
      this.state === PlayerState.DODGE ||
      this.state === PlayerState.PARRY ||
      this.state === PlayerState.HIT ||
      !this.canCancelIntoDefense()
    ) {
      return false;
    }
    if (this.stamina < 10) return false;
    this._consumeStamina(10);
    this.state = PlayerState.PARRY;
    this.stateTime = 0;
    this.parryTriggered = false;
    this.blockTriggered = false;
    this.blockRecoilTimer = 0;
    this.queuedAction = null;
    this.vx *= 0.2;
    this.vz *= 0.2;
    if (this.rig) {
      this.rig.hips.rotation.set(0, 0, 0);
      this.rig.torso.rotation.y = 0;
    }
    this._faceTarget(targetPos);
    this.glbCtrl?.playState('PARRY', true, 1.15, 0.06);
    vfx?.spawnShieldWard(this.root.position, this.facingYaw, 0x8cdbff);
    return true;
  }

  onParrySuccess() {
    this.parryTriggered = true;
    this.stamina = Math.min(this.maxStamina, this.stamina + 34);
    this.glbCtrl?.playState('PARRY_HIT', true, 1.35, 0.04);
  }

  onBlockSuccess(attackerPos, arena = null) {
    this.blockTriggered = true;
    this.blockRecoilTimer = 0.16;
    this.stamina = Math.max(0, this.stamina - 8);
    this.glbCtrl?.playState('PARRY_HIT', true, 0.92, 0.05);
    if (attackerPos) {
      this.tmpVec.subVectors(this.root.position, attackerPos).setY(0);
      if (this.tmpVec.lengthSq() > 0.0001) {
        this.tmpVec.normalize();
        this.root.position.addScaledVector(this.tmpVec, 0.35);
        arena?.resolveObstacleCollision(this.root.position, this.radius);
      }
    }
  }

  takeBlockedDamage(chipAmount) {
    if (chipAmount <= 0) return false;
    this.hp = Math.max(0, this.hp - chipAmount);
    this.hitFlashTimer = 0.1;
    if (this.hp <= 0) {
      this.state = PlayerState.DEATH;
      this.stateTime = 0;
      this.queuedAction = null;
      this.glbCtrl?.playState('DEATH', true, 1.0, 0.08);
    }
    return true;
  }

  onPerfectDodge() {
    this.stamina = Math.min(this.maxStamina, this.stamina + 26);
    this.counterBuffTimer = 2.2;
    this.perfectDodgeTrailTimer = 0.38;
  }

  consumeCounterBuff() {
    if (this.counterBuffTimer > 0) {
      this.counterBuffTimer = 0;
      return true;
    }
    return false;
  }

  takeDamage(amount, attackerPos, arena = null) {
    if (this.isInvulnerable()) return false;
    this.hp = Math.max(0, this.hp - amount);
    this.hitFlashTimer = 0.22;
    this.queuedAction = null;
    this.isHeavyFinisher = false;
    this.isCriticalStrike = false;
    if (this.hp <= 0) {
      this.state = PlayerState.DEATH;
      this.stateTime = 0;
      this.glbCtrl?.playState('DEATH', true, 1.0, 0.08);
    } else {
      this.state = PlayerState.HIT;
      this.stateTime = 0;
      this.glbCtrl?.playState('HIT', true, 1.75, 0.06);
      if (attackerPos) {
        this.tmpVec.subVectors(this.root.position, attackerPos).setY(0);
        if (this.tmpVec.lengthSq() > 0.0001) {
          this.tmpVec.normalize();
          this.root.position.addScaledVector(this.tmpVec, 0.72);
          arena?.resolveObstacleCollision(this.root.position, this.radius);
        }
      }
    }
    return true;
  }

  setVictory() {
    this.state = PlayerState.VICTORY;
    this.stateTime = 0;
    this.vx = 0;
    this.vz = 0;
    this.trail.update(false);
    this.glbCtrl?.playState('VICTORY', false, 1.0, 0.16);
  }

  _consumeStamina(cost) {
    this.stamina = Math.max(0, this.stamina - cost);
    this.staminaDelay = 0.52;
  }

  _faceTarget(pos) {
    if (!pos) return;
    const dx = pos.x - this.root.position.x;
    const dz = pos.z - this.root.position.z;
    if (dx * dx + dz * dz > 0.001) {
      this.facingYaw = Math.atan2(dx, dz);
    }
  }

  getActiveAttackInfo() {
    if (this.state === PlayerState.ATTACK) {
      const cfg = COMBO_CONFIG[this.comboStep];
      if (this.stateTime >= cfg.hitStart && this.stateTime <= cfg.hitEnd) {
        return {
          damage: cfg.damage,
          poise: cfg.poise,
          range: cfg.range,
          knockback: cfg.knockback,
          heavy: this.comboStep === 2,
          isComboFinisher: this.comboStep === 2,
          comboStep: this.comboStep,
        };
      }
    } else if (this.state === PlayerState.HEAVY) {
      if (this.isCriticalStrike) {
        if (this.stateTime >= 0.20 && this.stateTime <= 0.50) {
          return {
            damage: 340,
            poise: 0,
            range: 4.95,
            knockback: 2.6,
            heavy: true,
            isCriticalStrike: true,
          };
        }
      } else if (this.isHeavyFinisher) {
        if (this.stateTime >= 0.30 && this.stateTime <= 0.55) {
          return {
            damage: 255,
            poise: 56,
            range: 4.55,
            knockback: 2.3,
            heavy: true,
            isHeavyFinisher: true,
          };
        }
      } else if (this.stateTime >= 0.34 && this.stateTime <= 0.56) {
        return { damage: 210, poise: 46, range: 4.3, knockback: 2.0, heavy: true };
      }
    } else if (this.state === PlayerState.SKILL) {
      if (this.stateTime >= 0.18 && this.stateTime <= 0.54) {
        return { damage: 285, poise: 60, range: 5.3, knockback: 2.4, heavy: true, isSkill: true };
      }
    }
    return null;
  }

  update(dt, elapsed, moveVec, targetPos, arena, combatActive, events = {}) {
    this.stateTime += dt;
    if (this.skillCooldown > 0) this.skillCooldown = Math.max(0, this.skillCooldown - dt);
    if (this.comboResetTimer > 0) {
      this.comboResetTimer = Math.max(0, this.comboResetTimer - dt);
      if (this.comboResetTimer === 0) {
        this.comboHitCount = 0;
      }
    }
    if (this.counterBuffTimer > 0) this.counterBuffTimer = Math.max(0, this.counterBuffTimer - dt);
    if (this.perfectDodgeTrailTimer > 0) this.perfectDodgeTrailTimer = Math.max(0, this.perfectDodgeTrailTimer - dt);
    if (this.blockRecoilTimer > 0) this.blockRecoilTimer = Math.max(0, this.blockRecoilTimer - dt);

    if (this.staminaDelay > 0) {
      this.staminaDelay -= dt;
    } else if (this.state === PlayerState.IDLE || this.state === PlayerState.MOVE) {
      this.stamina = Math.min(this.maxStamina, this.stamina + 38 * dt);
    }

    if (this.hitFlashTimer > 0) this.hitFlashTimer -= dt;
    if (this.rig) {
      if (this.hitFlashTimer > 0) {
        this.rig.materials.armorMat.emissive.setHex(0xaa1810);
        this.rig.materials.armorMat.emissiveIntensity = 0.7;
      } else {
        this.rig.materials.armorMat.emissive.setHex(0x000000);
        this.rig.materials.armorMat.emissiveIntensity = 0;
      }
    } else if (this.trackedMaterials.length > 0) {
      for (const m of this.trackedMaterials) {
        if (!m || !m.emissive || m.name === 'RuneGlowMat') continue;
        if (this.hitFlashTimer > 0) {
          m.emissive.setHex(0xaa1810);
          m.emissiveIntensity = 0.75;
        } else {
          m.emissive.setHex(0x000000);
          m.emissiveIntensity = 0;
        }
      }
    }

    const moveMag = combatActive ? Math.min(1, moveVec.length()) : 0;

    if (this.state === PlayerState.IDLE || this.state === PlayerState.MOVE) {
      if (moveMag > 0.08) {
        this.state = PlayerState.MOVE;
        const isSprint = moveMag > 0.55;
        const maxSpeed = isSprint ? 7.6 : 4.5;
        const accel = Math.min(1, dt * 15);
        this.vx = THREE.MathUtils.lerp(this.vx, moveVec.x * maxSpeed, accel);
        this.vz = THREE.MathUtils.lerp(this.vz, moveVec.z * maxSpeed, accel);

        this.root.position.x += this.vx * dt;
        this.root.position.z += this.vz * dt;

        const targetYaw = Math.atan2(moveVec.x, moveVec.z);
        this.facingYaw = lerpAngle(this.facingYaw, targetYaw, Math.min(1, dt * 14));
        this.glbCtrl?.playState(isSprint ? 'RUN' : 'WALK', false, isSprint ? 1.12 : 1.0, 0.14);

        const stepFreq = isSprint ? 12.0 : 8.2;
        const stepPhase = Math.floor((elapsed * stepFreq) / Math.PI);
        if (stepPhase !== this.lastStepHalf) {
          this.lastStepHalf = stepPhase;
          events.onFootstep?.(isSprint);
        }
      } else {
        const damp = Math.min(1, dt * 16);
        this.vx = THREE.MathUtils.lerp(this.vx, 0, damp);
        this.vz = THREE.MathUtils.lerp(this.vz, 0, damp);
        this.root.position.x += this.vx * dt;
        this.root.position.z += this.vz * dt;
        this.state = PlayerState.IDLE;
        this.glbCtrl?.playState('IDLE', false, 1.0, 0.16);
      }
    } else if (this.state === PlayerState.ATTACK) {
      const cfg = COMBO_CONFIG[this.comboStep];
      if (this.stateTime < cfg.hitEnd) {
        this.root.position.x += Math.sin(this.facingYaw) * cfg.stepSpeed * dt * 0.62;
        this.root.position.z += Math.cos(this.facingYaw) * cfg.stepSpeed * dt * 0.62;
      }
      if (!this.slashArcFired && this.stateTime >= cfg.hitStart) {
        this.slashArcFired = true;
        events.onSlashArc?.(
          this.facingYaw,
          cfg.arcTilt,
          this.comboStep === 2 ? 1.56 : 1.18,
          false,
          this.comboStep === 2
        );
      }
      if (this.stateTime >= cfg.duration) {
        if (this.queuedAction === 'ATTACK' && this.stamina >= 10) {
          this._consumeStamina(10);
          this.comboStep = this.comboStep < 2 ? this.comboStep + 1 : 0;
          this._startComboAttack(targetPos);
          events.onComboSwing?.(this.comboStep);
        } else if (this.queuedAction === 'HEAVY' && this.stamina >= 24) {
          this.queuedAction = null;
          this.comboResetTimer = 0.2; // preserves finisher chain when transitioning ATTACK -> HEAVY
          this.state = PlayerState.IDLE;
          if (this.triggerHeavyAttack(targetPos)) {
            events.onHeavySwing?.(this.isHeavyFinisher, this.isCriticalStrike);
          }
        } else if (this.queuedAction === 'SKILL' && this.skillCooldown <= 0 && this.stamina >= 22) {
          this.queuedAction = null;
          this.state = PlayerState.IDLE;
          if (this.triggerSkill(targetPos)) events.onSkillCast?.();
        } else {
          this.comboResetTimer = 0.92;
          if (this.rig) {
            this.rig.hips.rotation.set(0, 0, 0);
            this.rig.torso.rotation.y = 0;
          }
          this.state = PlayerState.IDLE;
          this.stateTime = 0;
        }
      }
    } else if (this.state === PlayerState.HEAVY) {
      const lungeSpeed = this.isCriticalStrike ? 9.6 : this.isHeavyFinisher ? 8.2 : 7.2;
      const lungeStart = this.isCriticalStrike ? 0.08 : 0.22;
      const lungeEnd = this.isCriticalStrike ? 0.36 : 0.44;
      if (this.stateTime >= lungeStart && this.stateTime <= lungeEnd) {
        this.root.position.x += Math.sin(this.facingYaw) * lungeSpeed * dt;
        this.root.position.z += Math.cos(this.facingYaw) * lungeSpeed * dt;
      }
      const slamAt = this.isCriticalStrike ? 0.32 : this.isHeavyFinisher ? 0.39 : 0.43;
      if (!this.heavySlamFired && this.stateTime >= slamAt) {
        this.heavySlamFired = true;
        events.onHeavySlam?.(this.facingYaw, this.isHeavyFinisher, this.isCriticalStrike);
      }
      if (this.stateTime >= 0.78) {
        if (this.rig) {
          this.rig.hips.rotation.set(0, 0, 0);
          this.rig.torso.rotation.y = 0;
        }
        this.isHeavyFinisher = false;
        this.isCriticalStrike = false;
        this.state = PlayerState.IDLE;
        this.stateTime = 0;
      }
    } else if (this.state === PlayerState.SKILL) {
      if (this.stateTime >= 0.14 && this.stateTime <= 0.46) {
        this.root.position.x += Math.sin(this.facingYaw) * 7.6 * dt;
        this.root.position.z += Math.cos(this.facingYaw) * 7.6 * dt;
      }
      if (!this.skillBurstFired && this.stateTime >= 0.18) {
        this.skillBurstFired = true;
        events.onSkillUnleash?.(this.facingYaw);
      }
      if (!this.slashArcFired && this.stateTime >= 0.34) {
        this.slashArcFired = true;
        events.onSlashArc?.(this.facingYaw + Math.PI * 0.5, 0.08, 1.9, true, false);
      }
      if (this.stateTime >= 0.74) {
        if (this.rig) {
          this.rig.hips.rotation.set(0, 0, 0);
          this.rig.torso.rotation.y = 0;
        }
        this.state = PlayerState.IDLE;
        this.stateTime = 0;
      }
    } else if (this.state === PlayerState.DODGE) {
      const dashSpeed = this.stateTime < 0.28 ? 15.2 : 5.8;
      this.root.position.addScaledVector(this.dodgeDir, dashSpeed * dt);
      if (this.stateTime >= 0.42) {
        if (this.rig) this.rig.hips.rotation.x = 0;
        if (this.queuedAction === 'ATTACK' && this.stamina >= 10) {
          this._consumeStamina(10);
          this.comboStep = 0;
          this._startComboAttack(targetPos);
          events.onComboSwing?.(this.comboStep);
        } else if (this.queuedAction === 'HEAVY' && this.stamina >= 24) {
          this.queuedAction = null;
          this.state = PlayerState.IDLE;
          if (this.triggerHeavyAttack(targetPos)) {
            events.onHeavySwing?.(this.isHeavyFinisher, this.isCriticalStrike);
          }
        } else if (this.queuedAction === 'SKILL' && this.skillCooldown <= 0 && this.stamina >= 22) {
          this.queuedAction = null;
          this.state = PlayerState.IDLE;
          if (this.triggerSkill(targetPos)) events.onSkillCast?.();
        } else {
          this.state = PlayerState.IDLE;
          this.stateTime = 0;
        }
      }
    } else if (this.state === PlayerState.PARRY) {
      if (this.stateTime >= PARRY_BLOCK_DURATION) {
        this.state = PlayerState.IDLE;
        this.stateTime = 0;
      }
    } else if (this.state === PlayerState.HIT) {
      if (this.stateTime >= 0.34) {
        this.state = PlayerState.IDLE;
        this.stateTime = 0;
      }
    }

    arena.resolveObstacleCollision(this.root.position, this.radius);
    this.root.rotation.y = this.facingYaw;

    if (this.rig) {
      this._animateLimbs(dt, elapsed, moveMag);
    } else if (this.glbCtrl) {
      const animKey =
        this.state === PlayerState.MOVE
          ? moveMag > 0.55
            ? 'RUN'
            : 'WALK'
          : this.state === PlayerState.ATTACK
          ? COMBO_CONFIG[this.comboStep].clip
          : this.state === PlayerState.DODGE
          ? this.dodgeClip || 'DODGE'
          : this.state;
      this.glbCtrl.update(dt, animKey, elapsed, this.state === PlayerState.MOVE);
    }

    const isDodgeTrail = this.perfectDodgeTrailTimer > 0;
    const isFinisher =
      (this.state === PlayerState.ATTACK && this.comboStep === 2) ||
      (this.state === PlayerState.HEAVY && (this.isHeavyFinisher || this.isCriticalStrike));
    const showTrail =
      isDodgeTrail ||
      (this.state === PlayerState.ATTACK && this.stateTime >= 0.06 && this.stateTime <= 0.36) ||
      (this.state === PlayerState.HEAVY && this.stateTime >= 0.16 && this.stateTime <= 0.56) ||
      (this.state === PlayerState.SKILL && this.stateTime >= 0.12 && this.stateTime <= 0.54);

    const isCrimson = this.presetId === 'crimson_paladin';
    const baseTrailColor = isCrimson ? 0xffb347 : 0x56dcff;
    const trailHex =
      isDodgeTrail || this.counterBuffTimer > 0
        ? 0x7ae8ff
        : this.state === PlayerState.SKILL
        ? 0xff7b29
        : this.isCriticalStrike
        ? 0xffcf4d
        : isFinisher || this.state === PlayerState.HEAVY
        ? 0xffe066
        : baseTrailColor;

    this.weaponLight.color.setHex(trailHex);
    this.weaponLight.intensity =
      this.state === PlayerState.SKILL ? 3.4 : showTrail || this.counterBuffTimer > 0 ? 2.4 : 0.85;

    const auraColor =
      this.state === PlayerState.SKILL
        ? 0xff7b29
        : this.state === PlayerState.PARRY
        ? (this.isPerfectParrying() ? 0xb5f0ff : 0xffe082)
        : this.counterBuffTimer > 0 || isDodgeTrail
        ? 0x7ae8ff
        : baseTrailColor;

    if (this.contactAura) {
      const dead = this.state === PlayerState.DEATH;
      this.contactAura.visible = !dead;
      if (!dead) {
        const auraPulse = 1 + Math.sin(elapsed * 4.2) * 0.05;
        this.contactAura.material.color.setHex(auraColor);
        const auraScale =
          this.state === PlayerState.SKILL
            ? 1.32
            : this.state === PlayerState.PARRY
            ? 1.18
            : this.state === PlayerState.DODGE || this.counterBuffTimer > 0
            ? 1.15
            : auraPulse;
        this.contactAura.scale.setScalar(auraScale);
      }
    }

    if (this.auraRing) {
      const dead = this.state === PlayerState.DEATH;
      this.auraRing.visible = !dead;
      if (!dead) {
        this.auraRing.material.color.setHex(auraColor);
        this.auraRing.material.opacity =
          this.state === PlayerState.SKILL
            ? 0.72
            : this.state === PlayerState.PARRY
            ? 0.62
            : this.counterBuffTimer > 0
            ? 0.58
            : 0.3;
        this.auraRing.rotation.y += dt * (this.state === PlayerState.SKILL || this.counterBuffTimer > 0 ? 3.2 : 0.9);
        const ringScale =
          this.state === PlayerState.SKILL
            ? 1.28
            : this.state === PlayerState.PARRY
            ? 1.14
            : 1 + Math.sin(elapsed * 4.2) * 0.04;
        this.auraRing.scale.setScalar(ringScale);
      }
    }

    if (this.trackedMaterials.length > 0 && !this.isCustomModel) {
      const rimStrength =
        this.state === PlayerState.SKILL
          ? 0.84
          : this.state === PlayerState.PARRY || this.counterBuffTimer > 0
          ? 0.76
          : 0.62;
      updateRimShaderUniforms(this.trackedMaterials, auraColor, rimStrength);
    }

    if (this.rig) {
      this.rig.materials.bladeMat.emissiveIntensity =
        this.state === PlayerState.SKILL ? 2.45 : showTrail || this.counterBuffTimer > 0 ? 1.55 : 0.52;
    }
    this.trail.setColor(trailHex);

    const aliveAndVisible = this.state !== PlayerState.DEATH && this.root.visible;
    if (aliveAndVisible) {
      if (this.rig) {
        this.rig.swordBaseMarker.getWorldPosition(this.swordBaseWorld);
        this.rig.swordTipMarker.getWorldPosition(this.swordTipWorld);
      } else if (this.glbSwordBase && this.glbSwordTip) {
        this.glbSwordBase.getWorldPosition(this.swordBaseWorld);
        this.glbSwordTip.getWorldPosition(this.swordTipWorld);
      } else {
        const swingAngle = showTrail
          ? this.facingYaw + Math.sin(this.stateTime * 18) * 1.1
          : this.facingYaw - 0.55;
        this.swordBaseWorld.set(
          this.root.position.x + Math.cos(this.facingYaw) * 0.35,
          1.05,
          this.root.position.z - Math.sin(this.facingYaw) * 0.35
        );
        this.swordTipWorld.set(
          this.root.position.x + Math.sin(swingAngle) * 1.55,
          1.25,
          this.root.position.z + Math.cos(swingAngle) * 1.55
        );
      }

      if (this.swordEnergySprite) {
        this.swordEnergySprite.visible = true;
        this.swordEnergySprite.position.set(
          (this.swordBaseWorld.x + this.swordTipWorld.x) * 0.5,
          (this.swordBaseWorld.y + this.swordTipWorld.y) * 0.5,
          (this.swordBaseWorld.z + this.swordTipWorld.z) * 0.5
        );
        const pulse = 1 + Math.sin(elapsed * 7.5) * 0.1;
        const energyScale = (this.state === PlayerState.SKILL ? 1.65 : showTrail ? 1.32 : 0.92) * pulse;
        this.swordEnergySprite.scale.set(energyScale, energyScale, 1);
        this.swordEnergySprite.material.color.setHex(trailHex);
        this.swordEnergySprite.material.opacity =
          this.state === PlayerState.SKILL ? 0.82 : showTrail ? 0.64 : 0.28 + Math.sin(elapsed * 4.5) * 0.06;
      }

      if (showTrail) {
        this.trail.update(true, this.swordBaseWorld, this.swordTipWorld);
      } else {
        this.trail.update(false);
      }
    } else {
      if (this.swordEnergySprite) this.swordEnergySprite.visible = false;
      this.trail.update(false);
    }
  }

  _resetPose(blend) {
    if (!this.rig) return;
    const r = this.rig;
    const k = blend;
    r.hips.position.y = THREE.MathUtils.lerp(r.hips.position.y, 0.96, k);
    r.hips.rotation.set(THREE.MathUtils.lerp(r.hips.rotation.x, 0, k), THREE.MathUtils.lerp(r.hips.rotation.y, 0, k), 0);
    r.torso.rotation.set(THREE.MathUtils.lerp(r.torso.rotation.x, 0.06, k), THREE.MathUtils.lerp(r.torso.rotation.y, 0, k), 0);
    r.head.rotation.set(0, 0, 0);
    r.leftShoulder.rotation.set(THREE.MathUtils.lerp(r.leftShoulder.rotation.x, -0.25, k), 0, THREE.MathUtils.lerp(r.leftShoulder.rotation.z, 0.22, k));
    r.leftForearm.rotation.set(THREE.MathUtils.lerp(r.leftForearm.rotation.x, -0.65, k), 0, 0);
    r.rightShoulder.rotation.set(THREE.MathUtils.lerp(r.rightShoulder.rotation.x, -0.35, k), THREE.MathUtils.lerp(r.rightShoulder.rotation.y, 0, k), THREE.MathUtils.lerp(r.rightShoulder.rotation.z, -0.2, k));
    r.rightForearm.rotation.set(THREE.MathUtils.lerp(r.rightForearm.rotation.x, -0.55, k), 0, 0);
    r.weaponGroup.rotation.set(Math.PI * 0.45, 0, 0);
    r.leftHip.group.rotation.set(THREE.MathUtils.lerp(r.leftHip.group.rotation.x, 0, k), 0, 0);
    r.rightHip.group.rotation.set(THREE.MathUtils.lerp(r.rightHip.group.rotation.x, 0, k), 0, 0);
    r.leftHip.shin.rotation.x = THREE.MathUtils.lerp(r.leftHip.shin.rotation.x, 0.08, k);
    r.rightHip.shin.rotation.x = THREE.MathUtils.lerp(r.rightHip.shin.rotation.x, 0.08, k);
  }

  _animateLimbs(dt, elapsed, moveMag) {
    const r = this.rig;
    const b = Math.min(1, dt * 16);

    if (this.state === PlayerState.IDLE) {
      this._resetPose(b);
      const breath = Math.sin(elapsed * 2.4);
      r.hips.position.y = 0.96 + breath * 0.018;
      r.torso.rotation.x = 0.07 + breath * 0.028;
      r.head.rotation.y = Math.sin(elapsed * 1.1) * 0.05;
      r.leftShoulder.rotation.x = -0.28 + breath * 0.03;
      r.rightShoulder.rotation.x = -0.35 + breath * 0.045;
      r.cape.rotation.x = 0.1 + Math.sin(elapsed * 3.2) * 0.055;
    } else if (this.state === PlayerState.MOVE) {
      const isSprint = moveMag > 0.55;
      const freq = isSprint ? 12.0 : 8.2;
      const t = elapsed * freq;
      const stride = Math.sin(t) * (isSprint ? 0.8 : 0.48);
      r.hips.position.y = 0.93 + Math.abs(Math.cos(t)) * (isSprint ? 0.085 : 0.045);
      r.hips.rotation.x = 0;
      r.torso.rotation.x = isSprint ? 0.28 : 0.14;
      r.torso.rotation.y = -stride * 0.28;
      r.head.rotation.x = isSprint ? -0.14 : -0.05;
      r.leftHip.group.rotation.x = stride;
      r.rightHip.group.rotation.x = -stride;
      r.leftHip.shin.rotation.x = Math.max(0.08, -Math.cos(t) * (isSprint ? 0.78 : 0.52));
      r.rightHip.shin.rotation.x = Math.max(0.08, Math.cos(t) * (isSprint ? 0.78 : 0.52));
      r.leftShoulder.rotation.set(-stride * 0.65 - 0.22, 0.12, 0.24);
      r.leftForearm.rotation.x = isSprint ? -0.95 : -0.75;
      r.rightShoulder.rotation.set(stride * 0.55 - 0.35, 0, -0.25);
      r.rightForearm.rotation.x = isSprint ? -0.68 : -0.5;
      r.weaponGroup.rotation.set(Math.PI * (isSprint ? 0.54 : 0.47), 0, 0);
      r.cape.rotation.x = (isSprint ? 0.72 : 0.36) + Math.sin(t * 2) * 0.09;
    } else if (this.state === PlayerState.ATTACK) {
      const cfg = COMBO_CONFIG[this.comboStep];
      const p = Math.min(1, this.stateTime / cfg.duration);
      r.hips.position.y = 0.9;
      r.leftHip.group.rotation.x = -0.38;
      r.rightHip.group.rotation.x = 0.45;
      r.rightHip.shin.rotation.x = 0.38;
      if (this.comboStep === 0) {
        const swing = THREE.MathUtils.smoothstep(p, 0.12, 0.55);
        r.torso.rotation.x = 0.16;
        r.torso.rotation.y = THREE.MathUtils.lerp(-0.68, 0.9, swing);
        r.leftShoulder.rotation.set(-0.35, -0.3 + swing * 0.45, 0.42);
        r.rightShoulder.rotation.set(-1.35 + swing * 0.85, -0.95 + swing * 1.95, -0.52);
        r.rightForearm.rotation.x = THREE.MathUtils.lerp(-0.55, -0.15, swing);
        r.weaponGroup.rotation.set(Math.PI * 0.56, 0, -0.4);
      } else if (this.comboStep === 1) {
        const swing = THREE.MathUtils.smoothstep(p, 0.12, 0.55);
        r.torso.rotation.x = 0.18;
        r.torso.rotation.y = THREE.MathUtils.lerp(0.9, -0.9, swing);
        r.leftShoulder.rotation.set(-0.45, 0.35 - swing * 0.55, 0.48);
        r.rightShoulder.rotation.set(-1.1 + swing * 0.52, 1.05 - swing * 2.15, -0.72);
        r.rightForearm.rotation.x = THREE.MathUtils.lerp(-0.48, -0.14, swing);
        r.weaponGroup.rotation.set(Math.PI * 0.56, 0, 0.5);
      } else {
        const spin = THREE.MathUtils.smoothstep(p, 0.1, 0.65);
        r.hips.rotation.y = spin * Math.PI * 2;
        r.torso.rotation.x = 0.3;
        r.leftShoulder.rotation.set(-0.55, 0.4, 0.65);
        r.rightShoulder.rotation.set(-1.28, 0.2, -1.15);
        r.rightForearm.rotation.x = -0.12;
        r.weaponGroup.rotation.set(Math.PI * 0.52, 0, 0.25);
      }
      r.cape.rotation.x = 0.62;
    } else if (this.state === PlayerState.HEAVY) {
      const p = Math.min(1, this.stateTime / 0.78);
      const windupEnd = this.isCriticalStrike ? 0.24 : this.isHeavyFinisher ? 0.34 : 0.4;
      if (p < windupEnd) {
        const w = p / windupEnd;
        r.hips.position.y = 0.92 + w * 0.14;
        r.torso.rotation.x = -0.3 * w;
        r.rightShoulder.rotation.set(-2.65 * w, 0, -0.15);
        r.rightForearm.rotation.x = -0.35 * w;
        r.leftShoulder.rotation.set(-2.15 * w, 0.3, 0.15);
        r.weaponGroup.rotation.set(Math.PI * 0.3, 0, 0);
        r.cape.rotation.x = 0.2;
      } else {
        const s = THREE.MathUtils.smoothstep(p, windupEnd, windupEnd + 0.24);
        r.hips.position.y = 0.8;
        r.torso.rotation.x = THREE.MathUtils.lerp(-0.3, this.isCriticalStrike ? 0.66 : 0.58, s);
        r.rightShoulder.rotation.set(THREE.MathUtils.lerp(-2.65, -0.14, s), 0, -0.15);
        r.rightForearm.rotation.x = THREE.MathUtils.lerp(-0.35, -0.06, s);
        r.leftShoulder.rotation.set(THREE.MathUtils.lerp(-2.15, -0.35, s), 0.2, 0.2);
        r.leftHip.group.rotation.x = -0.52;
        r.rightHip.group.rotation.x = 0.58;
        r.rightHip.shin.rotation.x = 0.52;
        r.cape.rotation.x = 0.78;
      }
    } else if (this.state === PlayerState.SKILL) {
      const p = Math.min(1, this.stateTime / 0.74);
      const spin = THREE.MathUtils.smoothstep(p, 0.12, 0.68);
      r.hips.position.y = 0.88;
      r.hips.rotation.y = spin * Math.PI * 2;
      r.torso.rotation.x = 0.28;
      r.leftShoulder.rotation.set(-0.65, 0.3, 0.75);
      r.rightShoulder.rotation.set(-1.35, 0, -1.28);
      r.rightForearm.rotation.x = -0.08;
      r.weaponGroup.rotation.set(Math.PI * 0.5, 0, 0);
      r.cape.rotation.x = 0.85;
    } else if (this.state === PlayerState.DODGE) {
      const p = Math.min(1, this.stateTime / 0.42);
      r.hips.position.y = 0.68;
      r.hips.rotation.x = p * Math.PI * 2;
      r.torso.rotation.x = 0.55;
      r.leftHip.group.rotation.x = -0.8;
      r.rightHip.group.rotation.x = -0.8;
      r.leftHip.shin.rotation.x = 1.1;
      r.rightHip.shin.rotation.x = 1.1;
      r.cape.rotation.x = 0.92;
    } else if (this.state === PlayerState.PARRY) {
      const brace = this.parryTriggered ? 1.18 : 1.0;
      const recoil = this.blockRecoilTimer > 0 ? Math.sin((this.blockRecoilTimer / 0.16) * Math.PI) * 0.18 : 0;
      r.hips.position.y = 0.88 - recoil * 0.15;
      r.torso.rotation.x = 0.12 - recoil;
      r.torso.rotation.y = -0.28 * brace;
      r.leftShoulder.rotation.set(-1.18, 0.58, 0.15);
      r.leftForearm.rotation.x = -0.98;
      r.rightShoulder.rotation.set(-0.88, -0.3, -0.35);
      r.rightForearm.rotation.x = -0.7;
      r.leftHip.group.rotation.x = -0.32;
      r.rightHip.group.rotation.x = 0.34;
      r.rightHip.shin.rotation.x = 0.32;
      r.cape.rotation.x = 0.28 + recoil * 0.5;
    } else if (this.state === PlayerState.HIT) {
      const p = Math.min(1, this.stateTime / 0.34);
      const recoil = Math.sin(p * Math.PI) * (1 - p * 0.25);
      r.hips.position.y = 0.94 - recoil * 0.08;
      r.torso.rotation.x = -0.38 * recoil;
      r.head.rotation.x = -0.3 * recoil;
      r.leftShoulder.rotation.z = 0.48 * recoil;
      r.rightShoulder.rotation.z = -0.48 * recoil;
    } else if (this.state === PlayerState.DEATH) {
      const p = Math.min(1, this.stateTime / 0.85);
      const ease = p * p * (3 - 2 * p);
      r.hips.position.y = THREE.MathUtils.lerp(0.96, 0.24, ease);
      r.hips.rotation.x = THREE.MathUtils.lerp(0, 1.38, ease);
      r.leftShoulder.rotation.x = -0.6 * ease;
      r.rightShoulder.rotation.x = -0.4 * ease;
      r.leftHip.shin.rotation.x = 0.65 * ease;
      r.rightHip.shin.rotation.x = 0.65 * ease;
    } else if (this.state === PlayerState.VICTORY) {
      const p = Math.min(1, this.stateTime / 0.8);
      this._resetPose(b);
      r.torso.rotation.x = -0.1 * p;
      r.rightShoulder.rotation.set(THREE.MathUtils.lerp(-0.35, -2.85, p), 0, -0.15);
      r.rightForearm.rotation.x = THREE.MathUtils.lerp(-0.55, -0.12, p);
      r.weaponGroup.rotation.set(0.25, 0, 0);
      r.cape.rotation.x = 0.2 + Math.sin(elapsed * 3) * 0.08;
    }
  }

  dispose() {
    this._clearVisual();
    this.trail?.dispose?.();
    if (this.contactAura) {
      this.root.remove(this.contactAura);
      this.contactAura.geometry?.dispose?.();
      this.contactAura.material?.dispose?.();
      this.contactAura = null;
    }
    if (this.auraRing) {
      this.root.remove(this.auraRing);
      this.auraRing.geometry?.dispose?.();
      this.auraRing.material?.dispose?.();
      this.auraRing = null;
    }
    if (this.swordEnergySprite) {
      this.scene.remove(this.swordEnergySprite);
      this.swordEnergySprite.material?.dispose?.();
      this.swordEnergySprite = null;
    }
    this.swordEnergyTex?.dispose?.();
    this.swordEnergyTex = null;
    this.scene.remove(this.root);
  }
}

function lerpAngle(a, b, t) {
  let diff = ((b - a + Math.PI) % (Math.PI * 2)) - Math.PI;
  if (diff < -Math.PI) diff += Math.PI * 2;
  return a + diff * t;
}
