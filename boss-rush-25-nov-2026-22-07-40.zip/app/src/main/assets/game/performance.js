// Adaptive Frame-Time & Dynamic Quality Scaler for mid-range Android WebView GPUs
// Monitors smoothed unpaused frame time and steps down/up dynamic resolution, VFX density, and extra lights/shadows with hysteresis.

export class AdaptiveQualityController {
  constructor(initialTier = 'MEDIUM', baseDevicePixelRatio = 1.5, onProfileChange = null) {
    this.baseTier = initialTier;
    this.baseDpr = Math.max(1, baseDevicePixelRatio || 1);
    this.onProfileChange = onProfileChange;

    this.stepLevel = 0; // 0 = full tier profile, 1 = balanced step-down, 2 = low/fallback step-down
    this.emaDt = 1 / 60;
    this.warmupFrames = 12;
    this.slowDuration = 0;
    this.fastDuration = 0;
  }

  setBaseTier(tier, baseDevicePixelRatio = this.baseDpr) {
    this.baseTier = tier;
    this.baseDpr = Math.max(1, baseDevicePixelRatio || 1);
    this.stepLevel = 0;
    this.emaDt = 1 / 60;
    this.warmupFrames = 10;
    this.slowDuration = 0;
    this.fastDuration = 0;
    const profile = this.getEffectiveProfile();
    this.onProfileChange?.(profile);
    return profile;
  }

  getEffectiveProfile() {
    if (this.baseTier === 'LOW') {
      const ratio = this.stepLevel >= 2 ? 0.85 : this.stepLevel === 1 ? 0.92 : Math.min(this.baseDpr, 1.0);
      return {
        pixelRatio: ratio,
        shadowsEnabled: false,
        shadowMapSize: 512,
        vfxScale: this.stepLevel >= 1 ? 0.75 : 1.0,
        arenaAdaptiveLevel: Math.max(1, this.stepLevel),
        stepLevel: this.stepLevel,
      };
    }

    if (this.baseTier === 'HIGH') {
      if (this.stepLevel === 0) {
        return {
          pixelRatio: Math.min(this.baseDpr, 2.0),
          shadowsEnabled: true,
          shadowMapSize: 2048,
          vfxScale: 1.0,
          arenaAdaptiveLevel: 0,
          stepLevel: 0,
        };
      }
      if (this.stepLevel === 1) {
        return {
          pixelRatio: Math.min(this.baseDpr, 1.35),
          shadowsEnabled: true,
          shadowMapSize: 1024,
          vfxScale: 0.8,
          arenaAdaptiveLevel: 1,
          stepLevel: 1,
        };
      }
      return {
        pixelRatio: Math.min(this.baseDpr, 1.0),
        shadowsEnabled: false,
        shadowMapSize: 512,
        vfxScale: 0.55,
        arenaAdaptiveLevel: 2,
        stepLevel: 2,
      };
    }

    // MEDIUM (Default)
    if (this.stepLevel === 0) {
      return {
        pixelRatio: Math.min(this.baseDpr, 1.4),
        shadowsEnabled: true,
        shadowMapSize: 1024,
        vfxScale: 1.0,
        arenaAdaptiveLevel: 0,
        stepLevel: 0,
      };
    }
    if (this.stepLevel === 1) {
      return {
        pixelRatio: Math.min(this.baseDpr, 1.12),
        shadowsEnabled: true,
        shadowMapSize: 512,
        vfxScale: 0.72,
        arenaAdaptiveLevel: 1,
        stepLevel: 1,
      };
    }
    return {
      pixelRatio: Math.min(this.baseDpr, 0.95),
      shadowsEnabled: false,
      shadowMapSize: 512,
      vfxScale: 0.5,
      arenaAdaptiveLevel: 2,
      stepLevel: 2,
    };
  }

  recordFrame(rawDt) {
    // Ignore clamped tab-resume spikes or invalid deltas
    if (!Number.isFinite(rawDt) || rawDt <= 0 || rawDt >= 0.049) return false;
    if (this.warmupFrames > 0) {
      this.warmupFrames--;
      return false;
    }

    this.emaDt = this.emaDt * 0.9 + rawDt * 0.1;

    // Sustained < ~36 FPS -> step down
    if (this.emaDt > 0.0275) {
      this.slowDuration += rawDt;
      this.fastDuration = 0;
      if (this.slowDuration >= 1.8 && this.stepLevel < 2) {
        this.stepLevel++;
        this.slowDuration = 0;
        this.onProfileChange?.(this.getEffectiveProfile());
        return true;
      }
    } else if (this.emaDt < 0.0185 && this.stepLevel > 0) {
      // Sustained > ~54 FPS -> step back up smoothly
      this.fastDuration += rawDt;
      this.slowDuration = 0;
      if (this.fastDuration >= 4.2) {
        this.stepLevel--;
        this.fastDuration = 0;
        this.onProfileChange?.(this.getEffectiveProfile());
        return true;
      }
    } else {
      this.slowDuration = Math.max(0, this.slowDuration - rawDt * 0.5);
      this.fastDuration = Math.max(0, this.fastDuration - rawDt * 0.5);
    }

    return false;
  }
}
