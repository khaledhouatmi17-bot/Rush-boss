import * as THREE from 'three';
import { CathedralArena } from './arena.js';
import { PlayerCharacter, PlayerState, PLAYER_GLB_PATHS } from './player.js';
import { AshenKnightBoss, BossState, BOSS_GLB_PATHS } from './boss.js';
import { MinionManager, MINION_GLB_URL } from './enemies.js';
import { VFXManager } from './vfx.js';
import { CombatCamera } from './camera.js';
import { InputController } from './controls.js';
import { SoundEngine } from './audio.js';
import { GLBModelLoader, GLBAnimationController, disposeObject3D } from './modelManager.js';
import { buildStylizedPlayerRig, buildStylizedBossRig, buildStylizedMinionRig, equipSkeletonGLBArmory } from './stylized.js';
import { AdaptiveQualityController } from './performance.js';

const GamePhase = {
  MENU: 'MENU',
  PREVIEW: 'PREVIEW',
  INTRO: 'INTRO',
  COMBAT: 'COMBAT',
  PHASE_2: 'PHASE_2',
  VICTORY: 'VICTORY',
  DEFEAT: 'DEFEAT',
};

class BossRushGame {
  constructor() {
    this.container = document.getElementById('game-container');
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.32;
    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(55, window.innerWidth / window.innerHeight, 0.1, 140);

    this.arena = new CathedralArena(this.scene);
    // Bake atmospheric moonlight & fiery ember IBL reflections for metallic PBR shaders
    this.scene.environment = this.arena.buildEnvironmentMap(this.renderer);

    this.player = new PlayerCharacter(this.scene);
    this.boss = new AshenKnightBoss(this.scene);
    this.minions = new MinionManager(this.scene);
    this.vfx = new VFXManager(this.scene, this.camera);
    this.camCtrl = new CombatCamera(this.camera);
    this.audio = new SoundEngine();
    this.glbLoader = new GLBModelLoader();

    // Load bundled free CC0 animated characters cleanly in background
    this.player.loadPresetGLB(this.glbLoader, 'vanguard').catch(() => {});
    this.minions.preloadDefaultGLB(this.glbLoader).catch(() => {});

    this.phase = GamePhase.MENU;
    this.paused = false;
    this.contextLost = false;
    this._renderErrorReported = false;
    this.elapsed = 0;
    this.introTimer = 0;
    this.endResultTimer = 0;
    this.resultNotified = false;
    this.hitStopTimer = 0;
    this.slowMoTimer = 0;
    this.slowMoScale = 1.0;
    this.combatDuration = 0;
    this.qualityTier = 'MEDIUM';
    this.cameraSensitivity = 1.0;
    this.invertCameraY = false;
    this.controlScale = 1.0;
    this.previewRequestId = 0;
    this.phase2BannerTimer = null;
    this.flashTimers = new Map();
    this._previewOrbitHandlers = [];
    this._zeroVec = new THREE.Vector3();

    this.perfController = new AdaptiveQualityController(
      this.qualityTier,
      window.devicePixelRatio || 1,
      (profile) => this._applyRenderProfile(profile)
    );
    this._applyRenderProfile(this.perfController.getEffectiveProfile());

    this.previewState = {
      role: 'player',
      isCustom: false,
      presetId: 'vanguard',
      url: null,
      label: 'Aegis Knight',
      root: null,
      ctrl: null,
      height: 1.9,
      meta: null,
    };

    this.stats = { damageDealt: 0, parries: 0, dodges: 0 };

    this._cacheHudDom();
    this.input = new InputController(
      {
        onAnyInput: () => this.audio.unlock(),
        onLight: () => this._handlePlayerLight(),
        onHeavy: () => this._handlePlayerHeavy(),
        onDodge: () => this._handlePlayerDodge(),
        onParry: () => this._handlePlayerParry(),
        onSkill: () => this._handlePlayerSkill(),
        onLockToggle: () => this._handleLockToggle(),
        onCameraOrbit: (dx, dy) => this._handleCameraOrbit(dx, dy),
      },
      this.renderer.domElement
    );

    this._bindPreviewOrbitDrag();
    this._onResize = () => this._handleResize();
    this._onVisibility = () => {
      if (document.hidden) {
        if (this._isPlayablePhase()) {
          this.setPaused(true);
        }
        this.audio.suspend();
      } else if (!this.paused && !this.contextLost) {
        this.audio.resumeIfNeeded();
      }
    };
    this._onContextLost = (e) => {
      e.preventDefault?.();
      this.contextLost = true;
      if (this.rafId != null) {
        cancelAnimationFrame(this.rafId);
        this.rafId = null;
      }
      if (this._isPlayablePhase() && !this.paused) {
        this.setPaused(true);
      }
      this._reportError('WEBGL_CONTEXT_LOST', 'Graphics context paused. Tap Reload Arena if the screen remains black.', true);
    };
    this._onContextRestored = () => {
      this.contextLost = false;
      this._renderErrorReported = false;
      this.scene.environment = this.arena.buildEnvironmentMap(this.renderer);
      this._reportError('', '', true);
      if (!this.paused) {
        this._scheduleFrame();
      }
    };
    this._onWindowError = (event) => {
      const msg = event?.message || event?.error?.message || 'Unexpected rendering error';
      this._reportError('JS_RUNTIME_ERROR', msg, true);
    };
    this._onUnhandledRejection = (event) => {
      const msg = event?.reason?.message || String(event?.reason || 'Async operation failed');
      this._reportError('PROMISE_REJECTION', msg, true);
    };

    window.addEventListener('resize', this._onResize);
    document.addEventListener('visibilitychange', this._onVisibility);
    this.renderer.domElement.addEventListener('webglcontextlost', this._onContextLost);
    this.renderer.domElement.addEventListener('webglcontextrestored', this._onContextRestored);
    window.addEventListener('error', this._onWindowError);
    window.addEventListener('unhandledrejection', this._onUnhandledRejection);

    this.lastFrame = performance.now();
    this._notifyBridge();
    // Keep the render loop dormant while paused. This avoids spending CPU/GPU
    // time rendering an unchanged frame in the Android WebView.
    this.rafId = null;
    this._loop = (now) => {
      this.rafId = null;
      if (this.paused || this.contextLost) return;
      this._tick(now);
      if (!this.paused && !this.contextLost) {
        this.rafId = requestAnimationFrame(this._loop);
      }
    };
    this._scheduleFrame();
  }

  _cacheHudDom() {
    this.dom = {
      combatHud: document.getElementById('combat-hud'),
      introBanner: document.getElementById('intro-banner'),
      introBossTitle: document.getElementById('intro-boss-title'),
      phase2Banner: document.getElementById('phase2-banner'),
      bossHudName: document.getElementById('boss-hud-name'),
      playerHudName: document.getElementById('player-hud-name'),
      bossHpFill: document.getElementById('boss-hp-fill'),
      bossHpTrail: document.getElementById('boss-hp-trail'),
      bossPoiseFill: document.getElementById('boss-poise-fill'),
      bossPhaseBadge: document.getElementById('boss-phase-badge'),
      bossStaggerPill: document.getElementById('boss-stagger-pill'),
      playerHpFill: document.getElementById('player-hp-fill'),
      playerHpTrail: document.getElementById('player-hp-trail'),
      playerHpText: document.getElementById('player-hp-text'),
      playerStaminaFill: document.getElementById('player-stamina-fill'),
      comboPill: document.getElementById('combo-pill'),
      counterPill: document.getElementById('counter-pill'),
      parryHintPill: document.getElementById('parry-hint-pill'),
      minionPill: document.getElementById('minion-pill'),
      btnHeavy: document.getElementById('btn-heavy'),
      btnParry: document.getElementById('btn-parry'),
      btnSkill: document.getElementById('btn-skill'),
      btnLock: document.getElementById('btn-lock'),
      lockLabel: document.getElementById('lock-label'),
      skillCdRing: document.getElementById('skill-cd-ring'),
      skillCdText: document.getElementById('skill-cd-text'),
      pips: [document.getElementById('pip-1'), document.getElementById('pip-2'), document.getElementById('pip-3')],
      screenFlash: document.getElementById('screen-flash'),
      parryFlash: document.getElementById('parry-flash'),
      realmFlash: document.getElementById('realm-flash'),
    };
  }

  _bindPreviewOrbitDrag() {
    let dragPointer = null;
    let lastX = 0;
    const canvas = this.renderer.domElement;
    const onDown = (e) => {
      if (this.phase !== GamePhase.PREVIEW) return;
      dragPointer = e.pointerId;
      lastX = e.clientX;
      this.camCtrl.previewDragging = true;
    };
    const onMove = (e) => {
      if (this.phase !== GamePhase.PREVIEW || e.pointerId !== dragPointer) return;
      const dx = e.clientX - lastX;
      lastX = e.clientX;
      this.camCtrl.rotatePreview(-dx * 0.012);
    };
    const endDrag = (e) => {
      if (e.pointerId === dragPointer) {
        dragPointer = null;
        this.camCtrl.previewDragging = false;
      }
    };
    const listen = (target, type, fn) => {
      target.addEventListener(type, fn);
      this._previewOrbitHandlers.push({ target, type, fn });
    };
    listen(canvas, 'pointerdown', onDown);
    listen(window, 'pointermove', onMove);
    listen(window, 'pointerup', endDrag);
    listen(window, 'pointercancel', endDrag);
  }

  _handleResize() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  }

  _isPlayablePhase() {
    return this.phase === GamePhase.COMBAT || this.phase === GamePhase.PHASE_2;
  }

  _triggerSlowMo(scale, duration) {
    this.slowMoScale = Math.min(this.slowMoScale, scale);
    this.slowMoTimer = Math.max(this.slowMoTimer, duration);
  }

  _syncHudNames() {
    const pName = this.player.isCustomModel
      ? 'CUSTOM WARRIOR'
      : this.player.presetId === 'crimson_paladin'
      ? 'BARBARIAN WARLORD'
      : 'AEGIS KNIGHT';
    const bName = this.boss.isCustomModel
      ? 'CHALLENGER COLOSSUS'
      : this.boss.presetId === 'void_colossus'
      ? 'VOID COLOSSUS'
      : this.boss.presetId === 'skeleton_warlord'
      ? 'SKELETON WARLORD'
      : 'THE ASHEN BEHEMOTH';

    if (this.dom.playerHudName) this.dom.playerHudName.textContent = pName;
    if (this.dom.bossHudName) this.dom.bossHudName.textContent = bName;
    if (this.dom.introBossTitle) this.dom.introBossTitle.textContent = bName;
  }

  // --- Combat Input Handlers ---
  _handleCameraOrbit(dx, dy) {
    if (!this._isPlayablePhase() || this.paused) return;
    const sens = this.cameraSensitivity;
    const ySign = this.invertCameraY ? -1 : 1;
    this.camCtrl.orbitCombat(-dx * 0.0065 * sens, dy * 0.0042 * sens * ySign);
  }

  _handleLockToggle() {
    if (!this._isPlayablePhase() || this.paused) return;
    const locked = this.camCtrl.toggleLockOn();
    this.dom.btnLock?.classList.toggle('locked', locked);
    if (this.dom.lockLabel) this.dom.lockLabel.textContent = locked ? 'LOCK' : 'FREE';
    this.vfx.spawnFloatingText(this.player.root.position, locked ? 'TARGET LOCKED' : 'FREE CAMERA', 'realm');
  }

  _getActionTargetPos() {
    if (!this.camCtrl.lockedOn) {
      const mv = this.input.getMoveVector(this.camera);
      if (mv.lengthSq() > 0.04) {
        return {
          x: this.player.root.position.x + mv.x * 4,
          z: this.player.root.position.z + mv.z * 4,
        };
      }
    }
    return this._nearestEnemyPos();
  }

  _clearTransientInput() {
    if (!this.input) return;
    if (typeof this.input.clearTransient === 'function') {
      this.input.clearTransient();
      return;
    }
    this.input.keys?.clear?.();
    this.input.joyPointerId = null;
    this.input.camPointerId = null;
    if (this.input.joyVector) {
      this.input.joyVector.x = 0;
      this.input.joyVector.y = 0;
    }
    if (this.input.joystickKnob) {
      this.input.joystickKnob.style.transform = 'translate3d(0px, 0px, 0)';
    }
  }

  _handlePlayerLight() {
    if (!this._isPlayablePhase() || this.paused) return;
    if (this.player.triggerLightAttack(this._getActionTargetPos())) {
      this.audio.playLightAttack(this.player.comboStep);
    }
  }

  _handlePlayerHeavy() {
    if (!this._isPlayablePhase() || this.paused) return;
    const critReady = this.boss.canReceiveCriticalStrike(this.player.root.position, 4.9);
    const targetPos = critReady ? this.boss.root.position : this._getActionTargetPos();
    if (this.player.triggerHeavyAttack(targetPos, { isCritical: critReady })) {
      this.audio.playHeavyAttack(this.player.isHeavyFinisher || this.player.isCriticalStrike);
    }
  }

  _handlePlayerSkill() {
    if (!this._isPlayablePhase() || this.paused) return;
    if (this.player.triggerSkill(this._getActionTargetPos())) {
      this.audio.playSkill();
      this.camCtrl.addShake(0.14);
      this.camCtrl.pulseFov(4.5, 0.35);
    }
  }

  _handlePlayerDodge() {
    if (!this._isPlayablePhase() || this.paused) return;
    const moveVec = this.input.getMoveVector(this.camera);
    if (this.player.triggerDodge(moveVec, this.vfx)) {
      this.stats.dodges++;
      this.audio.playDodge();
      this.camCtrl.pulseFov(4.0, 0.22);
      this.vfx.spawnSparks({ x: this.player.root.position.x, y: 0.55, z: this.player.root.position.z }, 10, 0x8ea4c8, 4.5, 6);
    }
  }

  _handlePlayerParry() {
    if (!this._isPlayablePhase() || this.paused) return;
    if (this.player.triggerParry(this._getActionTargetPos(), this.vfx)) {
      this.audio.playSwordUnsheathe();
    }
  }

  _nearestEnemyPos() {
    let best = this.boss.root.position;
    let bestDistSq = this.player.root.position.distanceToSquared(best);
    for (const m of this.minions.minions) {
      if (m.state === 'DEAD') continue;
      const dSq = this.player.root.position.distanceToSquared(m.root.position);
      if (dSq < bestDistSq) {
        bestDistSq = dSq;
        best = m.root.position;
      }
    }
    return best;
  }

  // --- Game Flow ---
  startIntro() {
    this.audio.unlock();
    this._clearPreviewActor();
    this.arena.setPreviewMode(false);
    this.player.root.visible = true;
    this.boss.root.visible = true;
    this._resetEntities();
    this._syncHudNames();
    this.phase = GamePhase.INTRO;
    this.introTimer = 0;
    this.paused = false;
    this._clearTransientInput();
    this._scheduleFrame();
    this.dom.combatHud.classList.add('hidden');
    this.dom.introBanner.classList.remove('hidden');
    document.body.classList.add('cinematic-active');
    this.vfx.spawnSparks({ x: this.boss.root.position.x, y: 1.6, z: this.boss.root.position.z }, 34, 0xff6a22, 8.5, 4);
    this.boss.glbCtrl?.playState('ENRAGED', true, 1.0, 0.12);
    this.audio.playBossRoar(false);
    this.audio.setMusicState(1);
    this._notifyBridge();
  }

  skipIntro() {
    if (this.phase !== GamePhase.INTRO) return;
    this._enterCombat();
  }

  retry() {
    this.audio.unlock();
    this._resetEntities();
    this._syncHudNames();
    this._enterCombat();
  }

  returnToMenu() {
    this._clearPreviewActor();
    this.arena.setPreviewMode(false);
    this.player.root.visible = true;
    this.boss.root.visible = true;
    this._resetEntities();
    this.phase = GamePhase.MENU;
    this.paused = false;
    this._clearTransientInput();
    this._scheduleFrame();
    document.body.classList.remove('cinematic-active');
    this.dom.combatHud.classList.add('hidden');
    this.dom.introBanner.classList.add('hidden');
    this.dom.phase2Banner.classList.add('hidden');
    this.audio.setMusicState(0);
    this._notifyBridge();
  }

  _scheduleFrame() {
    if (this.rafId == null && !this.paused && !this.contextLost) {
      this.lastFrame = performance.now();
      this.rafId = requestAnimationFrame(this._loop);
    }
  }

  setPaused(paused) {
    const nextPaused = !!paused;
    if (this.paused === nextPaused) return;
    this.paused = nextPaused;

    if (this.paused) {
      this._clearTransientInput();
      if (this.rafId != null) {
        cancelAnimationFrame(this.rafId);
        this.rafId = null;
      }
      this.audio.setMusicState(0);
    } else {
      const musicState = this.phase === GamePhase.PHASE_2 ? 2 : this._isPlayablePhase() || this.phase === GamePhase.INTRO ? 1 : 0;
      this.audio.resumeIfNeeded();
      this.audio.setMusicState(musicState);
      this._scheduleFrame();
    }
    this._notifyBridge();
  }

  // --- Settings API ---
  setMuted(muted) { this.audio.setMuted(muted); }
  setMasterVolume(v) { this.audio.setMasterVolume(v); }
  setMusicVolume(v) { this.audio.setMusicVolume(v); }
  setSfxVolume(v) { this.audio.setSfxVolume(v); }
  setCameraSensitivity(v) {
    const n = Number(v);
    this.cameraSensitivity = Number.isFinite(n) ? Math.max(0.4, Math.min(2.2, n)) : 1.0;
  }
  setInvertCameraY(inv) { this.invertCameraY = !!inv; }
  setControlScale(scale) {
    const n = Number(scale);
    this.controlScale = Number.isFinite(n) ? Math.max(0.75, Math.min(1.3, n)) : 1.0;
    if (typeof document !== 'undefined' && document.documentElement?.style) {
      document.documentElement.style.setProperty('--hud-scale', String(this.controlScale));
    }
  }
  async selectBossPreset(presetId) {
    await this.boss.loadPresetGLB(this.glbLoader, presetId || 'ashen_behemoth');
    this._syncHudNames();
  }
  async selectPlayerPreset(presetId) {
    await this.player.loadPresetGLB(this.glbLoader, presetId || 'vanguard');
    this._syncHudNames();
  }
  _applyRenderProfile(profile) {
    if (!profile) return;
    this.renderer.setPixelRatio(profile.pixelRatio);
    this.renderer.shadowMap.enabled = !!profile.shadowsEnabled;
    this.arena.applyRenderQuality(profile);
    this.vfx.setAdaptiveScale(profile.vfxScale);
  }
  setQuality(tier) {
    this.qualityTier = tier;
    this.vfx.setQualityTier(tier);
    this.perfController.setBaseTier(tier, window.devicePixelRatio || 1);
  }

  // --- 3D Model Armory & GLB Import / Preview API ---
  async previewPreset(role, presetId, label) {
    this._enterPreviewStage(role);
    this._clearPreviewActor();
    const reqId = ++this.previewRequestId;
    const targetHeight = role === 'boss' ? 3.65 : role === 'minion' ? 1.65 : 1.9;

    const glbUrl =
      role === 'player'
        ? PLAYER_GLB_PATHS[presetId]
        : role === 'boss'
        ? BOSS_GLB_PATHS[presetId]
        : MINION_GLB_URL;

    if (glbUrl) {
      try {
        const loaded = await this.glbLoader.loadAsync(glbUrl, targetHeight, {
          stylizeToon: false,
          addOutlines: false,
          enhancePBR: true,
          hideSpareWeapons: true,
          rimColor: role === 'boss' ? 0xff6a24 : role === 'minion' ? 0xff7a2b : 0x6ce5ff,
          rimStrength: 0.5,
        });
        if (reqId !== this.previewRequestId || this.phase !== GamePhase.PREVIEW) {
          disposeObject3D(loaded.scene);
          return;
        }
        if (role === 'boss') {
          equipSkeletonGLBArmory(loaded.scene, 'boss');
        } else if (role === 'minion') {
          equipSkeletonGLBArmory(loaded.scene, presetId);
        }
        loaded.scene.position.y += 0.34;
        this.scene.add(loaded.scene);
        const ctrl = new GLBAnimationController(loaded.scene, loaded.animations);
        ctrl.playState('IDLE');
        this.previewState = {
          role,
          isCustom: false,
          presetId,
          url: glbUrl,
          label,
          root: loaded.scene,
          ctrl,
          height: targetHeight,
          meta: loaded.meta,
          animations: loaded.animations,
        };
        this._notifyPreviewMeta(null);
        return;
      } catch (_) {
        // Fall through cleanly to procedural PBR preset rig
      }
    }

    if (reqId !== this.previewRequestId || this.phase !== GamePhase.PREVIEW) return;
    let built = null;
    if (role === 'player') built = buildStylizedPlayerRig(presetId).root;
    else if (role === 'boss') built = buildStylizedBossRig(presetId).root;
    else built = buildStylizedMinionRig(presetId).root;

    built.position.set(0, 0.34, 0);
    this.scene.add(built);
    this.previewState = {
      role,
      isCustom: false,
      presetId,
      url: null,
      label,
      root: built,
      ctrl: null,
      height: targetHeight,
      meta: { meshCount: 14, hasRig: true, animationNames: ['Procedural Combat Rig'] },
    };
    this._notifyPreviewMeta(null);
  }

  async previewGLB(role, url, label) {
    this._enterPreviewStage(role);
    this._clearPreviewActor();
    const reqId = ++this.previewRequestId;
    const targetHeight = role === 'boss' ? 3.65 : role === 'minion' ? 1.65 : 1.9;
    try {
      const loaded = await this.glbLoader.loadAsync(url, targetHeight, {
        stylizeToon: false,
        addOutlines: false,
        enhancePBR: true,
        preservePBRMaterials: true,
      });
      if (reqId !== this.previewRequestId || this.phase !== GamePhase.PREVIEW) {
        disposeObject3D(loaded.scene);
        return;
      }
      loaded.scene.position.y += 0.34;
      this.scene.add(loaded.scene);
      const ctrl = new GLBAnimationController(loaded.scene, loaded.animations);
      ctrl.playState('IDLE');

      this.previewState = {
        role,
        isCustom: true,
        presetId: null,
        url,
        label,
        root: loaded.scene,
        ctrl,
        height: targetHeight,
        meta: loaded.meta,
        animations: loaded.animations,
      };
      this._notifyPreviewMeta(null);
    } catch (err) {
      this._notifyPreviewMeta(err?.message || 'Failed to parse GLB/GLTF file');
    }
  }

  playPreviewClip(clipName) {
    this.previewState.ctrl?.playClipByName(clipName);
  }

  async confirmPreview(finalUrlIfCustom) {
    const p = this.previewState;
    try {
      if (p.isCustom) {
        const targetUrl = finalUrlIfCustom || p.url;
        await this.applySavedGLB(p.role, targetUrl);
      } else {
        if (p.role === 'player') await this.player.loadPresetGLB(this.glbLoader, p.presetId);
        else if (p.role === 'boss') await this.boss.loadPresetGLB(this.glbLoader, p.presetId);
        else if (p.role === 'minion') this.minions.setCustomTemplate(null, []);
      }
    } finally {
      this.exitPreview();
    }
  }

  async applySavedGLB(role, url) {
    const targetHeight = role === 'boss' ? 3.65 : role === 'minion' ? 1.65 : 1.9;
    let reqId = 0;
    if (role === 'player') reqId = ++this.player.modelRequestId;
    else if (role === 'boss') reqId = ++this.boss.modelRequestId;
    else if (role === 'minion') reqId = ++this.minions.customRequestId;

    const loaded = await this.glbLoader.loadAsync(url, targetHeight, {
      stylizeToon: false,
      addOutlines: false,
      enhancePBR: true,
      preservePBRMaterials: true,
    });
    if (role === 'player') {
      if (reqId !== this.player.modelRequestId) {
        disposeObject3D(loaded.scene);
        return;
      }
      this.player.applyLoadedGLB(loaded, true);
    } else if (role === 'boss') {
      if (reqId !== this.boss.modelRequestId) {
        disposeObject3D(loaded.scene);
        return;
      }
      this.boss.applyCustomGLB(loaded.scene, loaded.animations, loaded.swordBaseMarker, loaded.swordTipMarker, loaded.trackedMaterials);
    } else if (role === 'minion') {
      if (reqId !== this.minions.customRequestId) {
        disposeObject3D(loaded.scene);
        return;
      }
      this.minions.setCustomTemplate(loaded.scene, loaded.animations);
    }
  }

  resetModelToDefault(role, presetId) {
    if (role === 'player') this.player.loadPresetGLB(this.glbLoader, presetId || 'vanguard');
    else if (role === 'boss') this.boss.loadPresetGLB(this.glbLoader, presetId || 'ashen_behemoth');
    else if (role === 'minion') this.minions.setCustomTemplate(null, []);
  }

  exitPreview() {
    this.previewRequestId++;
    this._clearPreviewActor();
    this.arena.setPreviewMode(false);
    this.player.root.visible = true;
    this.boss.root.visible = true;
    this.phase = GamePhase.MENU;
    this._notifyBridge();
  }

  _enterPreviewStage(role) {
    this.phase = GamePhase.PREVIEW;
    this.paused = false;
    this._scheduleFrame();
    this.dom.combatHud.classList.add('hidden');
    this.player.root.visible = false;
    if (this.player.swordEnergySprite) this.player.swordEnergySprite.visible = false;
    this.boss.root.visible = false;
    this.minions.clear();
    this.vfx.clearAll();
    this.arena.setPreviewMode(true);
    this.camCtrl.previewYaw = 0.35;
    this._notifyBridge();
  }

  _clearPreviewActor() {
    if (this.previewState.ctrl) {
      this.previewState.ctrl.dispose();
      this.previewState.ctrl = null;
    }
    if (this.previewState.root) {
      this.scene.remove(this.previewState.root);
      disposeObject3D(this.previewState.root);
      this.previewState.root = null;
    }
  }

  _notifyPreviewMeta(errorMsg) {
    const payload = JSON.stringify({
      role: this.previewState.role,
      label: this.previewState.label,
      isCustom: this.previewState.isCustom,
      error: errorMsg || '',
      meshCount: this.previewState.meta?.meshCount || 0,
      hasRig: !!this.previewState.meta?.hasRig,
      animations: this.previewState.meta?.animationNames || [],
    });
    try {
      window.AndroidBridge?.onPreviewMeta?.(payload);
    } catch (_) {}
  }

  _resetEntities() {
    if (this.phase2BannerTimer) {
      clearTimeout(this.phase2BannerTimer);
      this.phase2BannerTimer = null;
    }
    this._clearFlashTimers();
    this.player.reset();
    this.boss.reset();
    this.minions.clear();
    this.arena.setPhase2Intensity(false);
    this.vfx.clearAll();
    this.combatDuration = 0;
    this.endResultTimer = 0;
    this.resultNotified = false;
    this.hitStopTimer = 0;
    this.slowMoTimer = 0;
    this.slowMoScale = 1.0;
    this.stats = { damageDealt: 0, parries: 0, dodges: 0 };
    this.camCtrl.shakeTrauma = 0;
    this.camCtrl.targetFovOffset = 0;
    this.camCtrl.fovPulseTimer = 0;
    if (this.dom.screenFlash) this.dom.screenFlash.style.opacity = '0';
    if (this.dom.parryFlash) this.dom.parryFlash.style.opacity = '0';
    if (this.dom.realmFlash) this.dom.realmFlash.style.opacity = '0';
    this.dom.bossPhaseBadge.textContent = 'PHASE I';
    this.dom.bossPhaseBadge.classList.remove('enraged');
    this.dom.phase2Banner.classList.add('hidden');
    this.dom.counterPill?.classList.add('hidden');
    this.dom.comboPill?.classList.remove('finisher-cue');
    this.dom.btnHeavy?.classList.remove('crit-ready');
    this.camCtrl.setLockedOn(true);
    this.dom.btnLock?.classList.add('locked');
    if (this.dom.lockLabel) this.dom.lockLabel.textContent = 'LOCK';
  }

  _enterCombat() {
    this.phase = GamePhase.COMBAT;
    this.paused = false;
    this._clearTransientInput();
    this._scheduleFrame();
    document.body.classList.remove('cinematic-active');
    this.dom.introBanner.classList.add('hidden');
    this.dom.combatHud.classList.remove('hidden');
    this._syncHudNames();
    this.boss.startCombat();
    this.camCtrl.snapToCombat(this.player.root.position, this.boss.root.position);
    this.audio.playSwordUnsheathe();
    this.audio.setMusicState(1);
    this._notifyBridge();
  }

  _clearFlashTimers() {
    for (const [el, timerId] of this.flashTimers.entries()) {
      clearTimeout(timerId);
      if (el) el.style.opacity = '0';
    }
    this.flashTimers.clear();
  }

  _triggerScreenFlash(el) {
    if (!el) return;
    const prev = this.flashTimers.get(el);
    if (prev) clearTimeout(prev);
    el.style.opacity = '1';
    const tid = setTimeout(() => {
      this.flashTimers.delete(el);
      el.style.opacity = '0';
    }, 140);
    this.flashTimers.set(el, tid);
  }

  _renderSafe() {
    if (this.contextLost) return;
    try {
      this.renderer.render(this.scene, this.camera);
    } catch (err) {
      if (!this._renderErrorReported) {
        this._renderErrorReported = true;
        this._reportError('WEBGL_RENDER_ERROR', err?.message || '3D render failure occurred.', true);
      }
    }
  }

  _tick(now) {
    const rawDt = Math.min(0.05, Math.max(0.001, (now - this.lastFrame) / 1000));
    this.lastFrame = now;

    if (this.paused) {
      this._renderSafe();
      return;
    }

    if (this.hitStopTimer > 0) {
      this.hitStopTimer -= rawDt;
      this.camCtrl.update(rawDt * 0.15, this.elapsed, this.phase, this.introTimer, this.player.root.position, this.boss.root.position, this.arena, this.previewState.height);
      this._renderSafe();
      return;
    }

    if (this._isPlayablePhase() || this.phase === GamePhase.MENU) {
      this.perfController.recordFrame(rawDt);
    }

    if (this.slowMoTimer > 0) {
      this.slowMoTimer -= rawDt;
      if (this.slowMoTimer <= 0) this.slowMoScale = 1.0;
    } else {
      this.slowMoScale += (1.0 - this.slowMoScale) * Math.min(1, rawDt * 8);
    }

    const dt = rawDt * this.slowMoScale;
    this.elapsed += dt;

    if (this.phase === GamePhase.PREVIEW) {
      this.previewState.ctrl?.update(rawDt, 'IDLE', this.elapsed, false);
      this.arena.update(rawDt, this.elapsed);
      this.camCtrl.update(rawDt, this.elapsed, this.phase, 0, this.player.root.position, this.boss.root.position, this.arena, this.previewState.height);
      this._renderSafe();
      return;
    }

    if (this.phase === GamePhase.INTRO) {
      this.introTimer += rawDt;
      if (this.introTimer >= 3.2) {
        this._enterCombat();
      }
    }

    const moveVec = this._isPlayablePhase() ? this.input.getMoveVector(this.camera) : this._zeroVec;
    const lockTarget = this._nearestEnemyPos();

    this.arena.update(dt, this.elapsed);
    this.player.update(dt, this.elapsed, moveVec, lockTarget, this.arena, this._isPlayablePhase(), {
      onFootstep: (isSprint) => {
        this.audio.playFootstep(false);
        if (isSprint) this.vfx.spawnDust(this.player.root.position, 2);
      },
      onComboSwing: (step = 0) => this.audio.playLightAttack(step),
      onHeavySwing: (isFinisher = false, isCrit = false) => this.audio.playHeavyAttack(isFinisher || isCrit),
      onSkillCast: () => {
        this.audio.playSkill();
        this.camCtrl.addShake(0.14);
        this.camCtrl.pulseFov(4.5, 0.35);
      },
      onSkillUnleash: (yaw) => {
        const skillColor = this.player.presetId === 'crimson_paladin' ? 0xff9a33 : 0xff7b29;
        this.vfx.spawnSkillWhirlwind(this.player.root.position, yaw, skillColor);
        this.camCtrl.addShake(0.24);
        this.camCtrl.addImpactKick(Math.sin(yaw), Math.cos(yaw), 0.24);
      },
      onSlashArc: (yaw, tilt, scale, isSkill, isComboFinisher = false) => {
        const col = isSkill
          ? 0xff7b29
          : isComboFinisher
          ? 0xffc857
          : this.player.presetId === 'crimson_paladin'
          ? 0xffbe55
          : 0x62e2ff;
        this.vfx.spawnSlashArc(this.player.root.position, yaw, tilt, col, scale);
        if (isComboFinisher) {
          this.vfx.spawnSlashArc(this.player.root.position, yaw, -tilt * 1.15, 0xff7b29, scale * 0.92);
        }
      },
      onHeavySlam: (yaw, isFinisher = false, isCrit = false) => {
        const impactPos = {
          x: this.player.root.position.x + Math.sin(yaw) * 1.55,
          y: 0.15,
          z: this.player.root.position.z + Math.cos(yaw) * 1.55,
        };
        this.audio.playShockwave();
        this.vfx.spawnShockwave(impactPos, isCrit ? 7.2 : isFinisher ? 6.2 : 5.4, 14.2, isCrit ? 0xffd266 : 0xffb347, false, 0);
        this.vfx.spawnSparks(impactPos, isCrit || isFinisher ? 28 : 22, 0xffb347, 9.4, 14);
        this.vfx.spawnSmoke(impactPos, 4, 0x453b42);
        this.vfx.spawnGroundCrater(impactPos, isCrit ? 3.0 : isFinisher ? 2.6 : 2.3, 0xffb347);
        this.vfx.spawnHitFlash(impactPos, 0xffe066, isCrit ? 3.1 : 2.4);
        this.camCtrl.addShake(isCrit ? 0.38 : 0.32);
        this.camCtrl.addImpactKick(Math.sin(yaw), Math.cos(yaw), isCrit ? 0.34 : 0.28);
      },
    });

    if (this._isPlayablePhase()) {
      this.combatDuration += rawDt;
      this.boss.update(dt, this.elapsed, this.player.root.position, this.arena, this.vfx, this.audio, {
        onHeavyImpact: (shake) => {
          this.camCtrl.addShake(shake);
          this.camCtrl.addImpactKick(
            this.player.root.position.x - this.boss.root.position.x,
            this.player.root.position.z - this.boss.root.position.z,
            shake * 0.45
          );
        },
        onBossMeleeHit: (dmg, parryable, attackerPos) => this._resolveMeleeOnPlayer(dmg, parryable, attackerPos, true),
      });

      if (!this.minions.wave1Spawned && this.boss.hp <= this.boss.maxHp * 0.78) {
        this.minions.wave1Spawned = true;
        this.minions.spawnReinforcements(['cinder_imp'], this.boss.root.position, this.vfx, this.audio);
      }
      if (!this.minions.wave2Spawned && this.boss.hp <= this.boss.maxHp * 0.42) {
        this.minions.wave2Spawned = true;
        this.minions.spawnReinforcements(['cinder_imp', 'obsidian_sentinel'], this.boss.root.position, this.vfx, this.audio);
      }

      this.minions.update(dt, this.elapsed, this.player.root.position, this.arena, (dmg, pos) => {
        this._resolveMeleeOnPlayer(dmg, true, pos, false);
      });

      this._resolvePlayerAttacks();
    } else if (this.phase === GamePhase.INTRO) {
      this.boss.animatePose(dt, this.elapsed, 1.0);
      if (this.boss.rig && this.introTimer > 0.45 && this.introTimer < 2.2) {
        const raise = Math.min(1, (this.introTimer - 0.45) / 0.75);
        this.boss.rig.torso.rotation.x = -0.24 * raise;
        this.boss.rig.rightShoulder.rotation.set(-2.35 * raise, 0, -0.35 * raise);
        this.boss.rig.leftShoulder.rotation.set(-0.6 * raise, 0, 0.45 * raise);
      }
    } else {
      this.boss.animatePose(dt, this.elapsed, 1.0);
    }

    this.vfx.update(
      dt,
      (sw) => this._resolveShockwaveOnPlayer(sw),
      (px, pz, rad) => this._resolvePillarOnPlayer(px, pz, rad)
    );

    if (this.phase === GamePhase.VICTORY || this.phase === GamePhase.DEFEAT) {
      this.endResultTimer += rawDt;
      if (!this.resultNotified && this.endResultTimer >= 1.65) {
        this.resultNotified = true;
        this._notifyBridge();
      }
    }

    this.camCtrl.update(
      rawDt,
      this.elapsed,
      this.phase,
      this.introTimer,
      this.player.root.position,
      this.boss.root.position,
      this.arena,
      this.previewState.height
    );
    this._updateHud();
    this._renderSafe();
  }

  _resolvePlayerAttacks() {
    const atk = this.player.getActiveAttackInfo();
    if (!atk) return;

    const fx = Math.sin(this.player.facingYaw);
    const fz = Math.cos(this.player.facingYaw);
    const counterActive = this.player.counterBuffTimer > 0;
    const damageMult = counterActive ? 1.35 : 1.0;
    const isFinisherHit = !!(atk.isComboFinisher || atk.isHeavyFinisher);
    let hitAnyUnblocked = false;
    let usedCounterBuff = false;

    for (const m of this.minions.minions) {
      if (m.state === 'DEAD' || this.player.hasHitTarget(m)) continue;
      const dx = m.root.position.x - this.player.root.position.x;
      const dz = m.root.position.z - this.player.root.position.z;
      const dist = Math.hypot(dx, dz);
      if (dist <= atk.range + m.radius) {
        const dot = dist > 0.001 ? (fx * dx + fz * dz) / dist : 1;
        const inArc = atk.isSkill
          ? true
          : atk.heavy
          ? dot >= -0.05 || dist <= 2.4
          : dot >= 0.08 || dist <= 1.35;
        if (inArc) {
          this.player.markTargetHit(m);
          const dealt = m.takeDamage(
            Math.round(atk.damage * damageMult),
            this.player.root.position,
            atk.heavy || atk.isSkill,
            this.vfx,
            this.audio,
            this.arena
          );
          if (dealt > 0) {
            this.stats.damageDealt += dealt;
            this.player.comboHitCount++;
            if (counterActive) usedCounterBuff = true;
            if (!m.lastHitGuarded) {
              hitAnyUnblocked = true;
              const minionHitPos = { x: m.root.position.x, y: 1.05, z: m.root.position.z };
              this.vfx.spawnSparks(minionHitPos, isFinisherHit ? 18 : 14, counterActive ? 0x7ae8ff : 0xffc866, 8.2, 12);
              this.vfx.spawnDirectionalSparks(minionHitPos, this.player.facingYaw, 10, 0xffe075, 8.8, 13);
              this.vfx.spawnDirectionalHitFlash(
                minionHitPos,
                this.player.facingYaw,
                atk.heavy ? -0.35 : 0.28,
                atk.isSkill ? 0xff8a30 : counterActive ? 0x84ecff : 0xffe699,
                atk.heavy ? 2.4 : 1.7
              );
              this.vfx.spawnHitFlash(
                minionHitPos,
                atk.isSkill ? 0xff7b29 : counterActive ? 0x84ecff : 0xffe082,
                atk.heavy ? 2.2 : 1.5
              );
              this.vfx.spawnFloatingText(
                m.root.position,
                counterActive ? `COUNTER -${dealt}` : `-${dealt}`,
                atk.heavy || counterActive ? 'crit' : 'normal'
              );
            }
          }
        }
      }
    }

    if (hitAnyUnblocked) {
      this.audio.playImpact(atk.heavy, false);
      this.hitStopTimer = Math.min(0.085, Math.max(this.hitStopTimer, atk.heavy ? 0.034 : 0.018));
      this.camCtrl.addShake(atk.heavy ? 0.2 : 0.1);
    }

    if (this.boss.state !== BossState.DEFEATED && !this.player.hasHitTarget(this.boss)) {
      const dx = this.boss.root.position.x - this.player.root.position.x;
      const dz = this.boss.root.position.z - this.player.root.position.z;
      const dist = Math.hypot(dx, dz);
      if (dist <= atk.range + this.boss.radius * 0.6) {
        const dot = dist > 0.001 ? (fx * dx + fz * dz) / dist : 1;
        const bossInArc = atk.isSkill
          ? true
          : atk.heavy
          ? dot >= -0.05 || dist <= 2.7
          : dot >= 0.12 || dist <= 2.0;
        if (bossInArc) {
          this.player.markTargetHit(this.boss);
          const canCrit =
            (atk.isCriticalStrike || atk.heavy) &&
            this.boss.canReceiveCriticalStrike(this.player.root.position, atk.range + this.boss.radius * 0.65);
          const executeCrit = canCrit && this.boss.consumeCriticalStrike();
          const finalAttackDamage = Math.round(atk.damage * damageMult * (executeCrit && !atk.isCriticalStrike ? 1.35 : 1.0));
          const res = this.boss.takeDamage(finalAttackDamage, atk.poise, atk.isSkill, atk.heavy || executeCrit);

          if (res.damage > 0) {
            this.stats.damageDealt += res.damage;
            this.player.comboHitCount++;
            if (counterActive) usedCounterBuff = true;

            const hitPos = {
              x: (this.player.root.position.x + this.boss.root.position.x) * 0.5,
              y: 1.65,
              z: (this.player.root.position.z + this.boss.root.position.z) * 0.5,
            };

            if (executeCrit) {
              this.audio.playCriticalAttack();
              this.hitStopTimer = 0.08;
              this.camCtrl.pulseFov(-6.5, 0.42);
              this.camCtrl.addShake(0.48);
              this.camCtrl.addImpactKick(fx, fz, 0.36);
              this.vfx.spawnCriticalStrikeBurst(hitPos, this.player.facingYaw);
              this.vfx.spawnFloatingText(this.boss.root.position, `CRITICAL -${res.damage}!`, 'critical');
            } else {
              this.audio.playBossHit(atk.heavy || atk.isSkill);
              const stopDur = atk.heavy ? 0.052 : isFinisherHit ? 0.04 : 0.022;
              this.hitStopTimer = Math.min(0.085, Math.max(this.hitStopTimer, stopDur));
              this.camCtrl.addShake(atk.heavy ? 0.34 : 0.16);
              if (atk.heavy || atk.isSkill || isFinisherHit) {
                this.camCtrl.addImpactKick(fx, fz, atk.heavy ? 0.24 : 0.16);
              }

              const sparkHex = counterActive ? 0x7ae8ff : atk.isSkill ? 0xff7722 : 0xffe075;
              const isCrit = this.boss.state === BossState.STUNNED || atk.heavy || atk.isSkill;
              this.vfx.spawnSparks(hitPos, atk.heavy ? 24 : 14, sparkHex, atk.heavy ? 10 : 7, 14);
              this.vfx.spawnDirectionalSparks(hitPos, this.player.facingYaw, atk.heavy ? 18 : 10, sparkHex, atk.heavy ? 10.5 : 8.0, 14);
              if (isFinisherHit && !atk.isSkill) {
                this.vfx.spawnComboFinisherBurst(hitPos, this.player.facingYaw, !!atk.isHeavyFinisher);
              } else if (isCrit) {
                this.vfx.spawnCritImpact(hitPos, this.player.facingYaw, atk.isSkill);
              } else {
                this.vfx.spawnDirectionalHitFlash(
                  hitPos,
                  this.player.facingYaw,
                  this.player.comboStep % 2 === 0 ? 0.25 : -0.32,
                  counterActive ? 0x84ecff : 0xffe699,
                  2.2
                );
                this.vfx.spawnHitFlash(hitPos, counterActive ? 0x84ecff : 0xffe082, 1.9);
              }
              const dmgLabel = counterActive
                ? `COUNTER -${res.damage}`
                : this.boss.state === BossState.STUNNED
                ? `CRIT -${res.damage}`
                : `-${res.damage}`;
              this.vfx.spawnFloatingText(
                this.boss.root.position,
                dmgLabel,
                this.boss.state === BossState.STUNNED || atk.heavy || counterActive ? 'crit' : 'normal'
              );
            }

            if (res.staggered) {
              this.vfx.hideTelegraphs();
              this.audio.playStagger();
              this._triggerSlowMo(0.32, 0.35);
              this.camCtrl.pulseFov(-5.0, 0.42);
              this.vfx.spawnHitFlash({ x: this.boss.root.position.x, y: 1.9, z: this.boss.root.position.z }, 0xffe082, 3.6);
              this.vfx.spawnFloatingText(this.boss.root.position, 'STAGGERED!', 'parry');
              this.camCtrl.addShake(0.42);
              this.camCtrl.addImpactKick(fx, fz, 0.34);
            }

            if (res.triggeredPhase2) {
              this.vfx.hideTelegraphs();
              this.phase = GamePhase.PHASE_2;
              this.arena.setPhase2Intensity(true);
              this.arena.triggerBossAttackGlow(1.55);
              this.audio.setMusicState(2);
              this._triggerSlowMo(0.35, 0.55);
              this.camCtrl.pulseFov(6.0, 0.55);
              this.dom.bossPhaseBadge.textContent = 'PHASE II — ENRAGED';
              this.dom.bossPhaseBadge.classList.add('enraged');
              this.dom.phase2Banner.classList.remove('hidden');
              if (this.phase2BannerTimer) clearTimeout(this.phase2BannerTimer);
              this.phase2BannerTimer = setTimeout(() => {
                this.phase2BannerTimer = null;
                this.dom.phase2Banner.classList.add('hidden');
              }, 2300);
              this._notifyBridge();
            }

            if (res.defeated) {
              this._onBossDefeated();
            }
          }
        }
      }
    }

    if (usedCounterBuff) {
      this.player.consumeCounterBuff();
    }
  }

  _resolveMeleeOnPlayer(damage, parryable, attackerPos, isBoss) {
    if (this.player.state === PlayerState.DEATH) return;

    if (this.player.state === PlayerState.PARRY) {
      const dx = attackerPos.x - this.player.root.position.x;
      const dz = attackerPos.z - this.player.root.position.z;
      const dist = Math.max(0.01, Math.hypot(dx, dz));
      const pfx = Math.sin(this.player.facingYaw);
      const pfz = Math.cos(this.player.facingYaw);
      const dot = (pfx * dx + pfz * dz) / dist;

      if (dot > -0.15) {
        const clashPos = {
          x: (this.player.root.position.x + attackerPos.x) * 0.5,
          y: 1.5,
          z: (this.player.root.position.z + attackerPos.z) * 0.5,
        };
        if (parryable && this.player.isPerfectParrying()) {
          this.stats.parries++;
          this.player.onParrySuccess();
          if (isBoss && this.boss.staggerFromParry()) {
            this.audio.playStagger();
          }
          this.audio.playPerfectParry();
          this.hitStopTimer = 0.08;
          this._triggerSlowMo(0.24, 0.38);
          this.camCtrl.pulseFov(-5.8, 0.42);
          this.camCtrl.addShake(0.46);
          this.camCtrl.addImpactKick(-pfx, -pfz, 0.32);
          this._triggerScreenFlash(this.dom.parryFlash);
          this.vfx.spawnPerfectParryBurst(clashPos, this.player.facingYaw);
          this.vfx.spawnFloatingText(this.player.root.position, 'PERFECT PARRY!', 'perfect-parry');
          return;
        }
        if (this.player.isBlocking() || !parryable) {
          const chip = Math.max(1, Math.round(damage * 0.25));
          this.player.onBlockSuccess(attackerPos, this.arena);
          this.player.takeBlockedDamage(chip);
          this.audio.playShieldClash();
          this.hitStopTimer = 0.032;
          this.camCtrl.addShake(0.2);
          this.camCtrl.addImpactKick(-pfx, -pfz, 0.16);
          this.vfx.spawnBlockBurst(clashPos, this.player.facingYaw);
          this.vfx.spawnFloatingText(this.player.root.position, `BLOCKED -${chip}`, 'block');
          if (this.player.hp <= 0) this._onPlayerDefeated();
          return;
        }
      }
    }

    if (this.player.isInvulnerable()) {
      if (this.player.isPerfectDodgeWindow()) {
        this.player.onPerfectDodge();
        this.audio.playPerfectDodge();
        this._triggerSlowMo(0.28, 0.34);
        this._triggerScreenFlash(this.dom.realmFlash);
        this.vfx.spawnPerfectDodgeTrail(this.player.root.position, this.player.facingYaw);
        this.vfx.spawnFloatingText(this.player.root.position, 'PERFECT DODGE!', 'perfect-dodge');
      }
      return;
    }

    if (this.player.takeDamage(damage, attackerPos, this.arena)) {
      this._onPlayerDamaged(damage);
    }
  }

  _resolveShockwaveOnPlayer(sw) {
    if (!this._isPlayablePhase() || this.player.state === PlayerState.DEATH) return false;
    const dist = Math.hypot(this.player.root.position.x - sw.mesh.position.x, this.player.root.position.z - sw.mesh.position.z);
    if (Math.abs(dist - sw.radius) < 1.05) {
      if (this.player.isInvulnerable()) {
        if (this.player.isPerfectDodgeWindow()) {
          this.player.onPerfectDodge();
          this.audio.playPerfectDodge();
          this._triggerSlowMo(0.3, 0.3);
          this._triggerScreenFlash(this.dom.realmFlash);
          this.vfx.spawnPerfectDodgeTrail(this.player.root.position, this.player.facingYaw);
          this.vfx.spawnFloatingText(this.player.root.position, 'PERFECT DODGE!', 'perfect-dodge');
        }
        return true;
      }
      if (this.player.takeDamage(sw.damage, sw.mesh.position, this.arena)) {
        this._onPlayerDamaged(sw.damage);
      }
      return true;
    }
    return false;
  }

  _resolvePillarOnPlayer(px, pz, rad) {
    if (!this._isPlayablePhase() || this.player.state === PlayerState.DEATH) return false;
    const dist = Math.hypot(this.player.root.position.x - px, this.player.root.position.z - pz);
    if (dist <= rad) {
      if (this.player.isInvulnerable()) return true;
      if (this.player.takeDamage(170, { x: px, z: pz }, this.arena)) {
        this._onPlayerDamaged(170);
      }
      return true;
    }
    return false;
  }

  _onPlayerDamaged(damage) {
    this.audio.playPlayerDamage();
    this.camCtrl.addShake(0.38);
    this.camCtrl.addImpactKick(-Math.sin(this.player.facingYaw), -Math.cos(this.player.facingYaw), 0.24);
    this.hitStopTimer = 0.04;
    this._triggerScreenFlash(this.dom.screenFlash);
    this.vfx.spawnSparks({ x: this.player.root.position.x, y: 1.25, z: this.player.root.position.z }, 16, 0xff4422, 7.5, 12);
    this.vfx.spawnHitFlash({ x: this.player.root.position.x, y: 1.25, z: this.player.root.position.z }, 0xff4422, 2.0);
    this.vfx.spawnFloatingText(this.player.root.position, `-${damage}`, 'player-hit');
    if (this.player.hp <= 0) this._onPlayerDefeated();
  }

  _onBossDefeated() {
    this.phase = GamePhase.VICTORY;
    this.endResultTimer = 0;
    this.resultNotified = false;
    this.minions.clear();
    this.player.setVictory();
    this.vfx.hideTelegraphs();
    this.vfx.spawnPhase2ArenaPulse(this.boss.root.position);
    this.vfx.spawnSmoke(this.boss.root.position, 8, 0x3b2f35);
    this._triggerSlowMo(0.22, 0.85);
    this.audio.playBossRoar(true);
    this.audio.playVictory();
    this.audio.setMusicState(0);
    document.body.classList.add('cinematic-active');
    this.dom.combatHud.classList.add('hidden');
  }

  _onPlayerDefeated() {
    this.phase = GamePhase.DEFEAT;
    this.endResultTimer = 0;
    this.resultNotified = false;
    this.boss.clearTransientEffects();
    this.vfx.hideTelegraphs();
    this.audio.playDefeat();
    this.audio.setMusicState(0);
    this.dom.combatHud.classList.add('hidden');
  }

  _updateHud() {
    if (!this._isPlayablePhase()) return;

    const bossPct = (this.boss.hp / this.boss.maxHp) * 100;
    this.dom.bossHpFill.style.width = `${bossPct.toFixed(1)}%`;
    this.dom.bossHpTrail.style.width = `${bossPct.toFixed(1)}%`;

    const poisePct = this.boss.state === BossState.STUNNED ? 100 : (this.boss.poise / this.boss.maxPoise) * 100;
    this.dom.bossPoiseFill.style.width = `${poisePct.toFixed(1)}%`;
    const isStaggered = this.boss.state === BossState.STUNNED;
    const critOpportunity = this.boss.canReceiveCriticalStrike(this.player.root.position, 4.9);
    this.dom.bossStaggerPill.classList.toggle('hidden', !isStaggered);
    if (isStaggered) {
      this.dom.bossStaggerPill.textContent = critOpportunity
        ? 'CRITICAL OPPORTUNITY — PRESS HEAVY!'
        : this.boss.criticalAvailable
        ? 'STAGGERED — MOVE IN FOR CRITICAL!'
        : 'STAGGERED — STRIKE NOW!';
    }
    this.dom.btnHeavy?.classList.toggle('crit-ready', critOpportunity);

    const pHpPct = (this.player.hp / this.player.maxHp) * 100;
    this.dom.playerHpFill.style.width = `${pHpPct.toFixed(1)}%`;
    this.dom.playerHpTrail.style.width = `${pHpPct.toFixed(1)}%`;
    this.dom.playerHpText.textContent = `${Math.ceil(this.player.hp)} / ${this.player.maxHp}`;

    const stamPct = (this.player.stamina / this.player.maxStamina) * 100;
    this.dom.playerStaminaFill.style.width = `${stamPct.toFixed(1)}%`;

    const activeCombo =
      this.player.state === PlayerState.ATTACK
        ? this.player.comboStep + 1
        : this.player.comboResetTimer > 0
        ? this.player.comboStep + 1
        : 0;
    const isHeavyChain = this.player.state === PlayerState.HEAVY && this.player.isHeavyFinisher;
    this.dom.pips.forEach((pip, i) => pip.classList.toggle('active', i < activeCombo));
    const showComboPill = activeCombo > 0 || isHeavyChain;
    this.dom.comboPill.classList.toggle('hidden', !showComboPill);
    this.dom.comboPill.classList.toggle('finisher-cue', activeCombo === 3 || isHeavyChain);
    if (isHeavyChain) {
      this.dom.comboPill.textContent = 'HEAVY FINISHER!';
    } else if (activeCombo > 0) {
      this.dom.comboPill.textContent =
        activeCombo === 3 ? 'COMBO x3 — FINISHER' : `COMBO x${activeCombo}`;
    }

    this.dom.counterPill?.classList.toggle('hidden', this.player.counterBuffTimer <= 0);

    const showParryCue = this.boss.isTelegraphingParryCue() || this.boss.isParryableNow();
    this.dom.parryHintPill.classList.toggle('hidden', !showParryCue);
    this.dom.btnParry.classList.toggle('cue-active', showParryCue);

    let aliveMinions = 0;
    const minionList = this.minions.minions;
    for (let i = 0; i < minionList.length; i++) {
      if (minionList[i].state !== 'DEAD') aliveMinions++;
    }
    this.dom.minionPill.classList.toggle('hidden', aliveMinions === 0);
    if (aliveMinions > 0) this.dom.minionPill.textContent = `MINIONS x${aliveMinions}`;

    const cd = this.player.skillCooldown;
    const cdMax = this.player.skillCooldownMax;
    const onCd = cd > 0.01;
    this.dom.btnSkill.classList.toggle('on-cooldown', onCd);
    this.dom.skillCdText.classList.toggle('hidden', !onCd);
    if (onCd) {
      this.dom.skillCdText.textContent = cd.toFixed(1);
      this.dom.skillCdRing.style.strokeDashoffset = (176 * (cd / cdMax)).toFixed(1);
    } else {
      this.dom.skillCdRing.style.strokeDashoffset = '0';
    }
  }

  _notifyBridge() {
    const payload = JSON.stringify({
      phase: this.phase,
      paused: this.paused,
      resultReady: this.resultNotified,
      timeSeconds: Math.round(this.combatDuration),
      damageDealt: this.stats.damageDealt,
      parries: this.stats.parries,
      dodges: this.stats.dodges,
    });
    try {
      window.AndroidBridge?.onStateChange?.(payload);
    } catch (_) {}
  }

  _reportError(code, message, recoverable = true) {
    try {
      window.AndroidBridge?.onGameError?.(JSON.stringify({ code, message, recoverable }));
    } catch (_) {}
  }

  dispose() {
    if (this.phase2BannerTimer) {
      clearTimeout(this.phase2BannerTimer);
      this.phase2BannerTimer = null;
    }
    this._clearFlashTimers();
    if (this.rafId != null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    for (const h of this._previewOrbitHandlers) {
      h.target.removeEventListener(h.type, h.fn);
    }
    this._previewOrbitHandlers = [];
    window.removeEventListener('resize', this._onResize);
    document.removeEventListener('visibilitychange', this._onVisibility);
    this.renderer.domElement.removeEventListener('webglcontextlost', this._onContextLost);
    this.renderer.domElement.removeEventListener('webglcontextrestored', this._onContextRestored);
    window.removeEventListener('error', this._onWindowError);
    window.removeEventListener('unhandledrejection', this._onUnhandledRejection);
    this._clearPreviewActor();
    this.vfx.dispose();
    this.player.dispose();
    this.boss.dispose();
    this.minions.dispose();
    this.arena.dispose();
    this.glbLoader.clearCache();
    this.input.dispose();
    this.audio.dispose();
    this.renderer.dispose();
  }
}

const game = new BossRushGame();
window.GameAPI = {
  startIntro: () => game.startIntro(),
  skipIntro: () => game.skipIntro(),
  retry: () => game.retry(),
  returnToMenu: () => game.returnToMenu(),
  setPaused: (p) => game.setPaused(p),
  setMuted: (m) => game.setMuted(m),
  setMasterVolume: (v) => game.setMasterVolume(v),
  setMusicVolume: (v) => game.setMusicVolume(v),
  setSfxVolume: (v) => game.setSfxVolume(v),
  setQuality: (t) => game.setQuality(t),
  setCameraSensitivity: (v) => game.setCameraSensitivity(v),
  setInvertCameraY: (inv) => game.setInvertCameraY(inv),
  setControlScale: (s) => game.setControlScale(s),
  selectBossPreset: (presetId) => game.selectBossPreset(presetId),
  selectPlayerPreset: (presetId) => game.selectPlayerPreset(presetId),
  previewPreset: (role, presetId, label) => game.previewPreset(role, presetId, label),
  previewGLB: (role, url, label) => game.previewGLB(role, url, label),
  playPreviewClip: (name) => game.playPreviewClip(name),
  confirmPreview: (finalUrl) => game.confirmPreview(finalUrl),
  applySavedGLB: (role, url) => game.applySavedGLB(role, url),
  resetModelToDefault: (role, presetId) => game.resetModelToDefault(role, presetId),
  exitPreview: () => game.exitPreview(),
};
window.addEventListener('beforeunload', () => game.dispose());
