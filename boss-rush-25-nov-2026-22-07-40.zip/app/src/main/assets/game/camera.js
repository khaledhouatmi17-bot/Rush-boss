import * as THREE from 'three';
import { ARENA_RADIUS } from './arena.js';

// God-of-War inspired over-the-shoulder third-person combat camera with Lock-On & Touch-Drag Orbit
export class CombatCamera {
  constructor(camera) {
    this.camera = camera;
    this.currentPos = new THREE.Vector3(0, 2.5, 15.0);
    this.currentLook = new THREE.Vector3(0, 1.5, -3.0);
    this.desiredPos = new THREE.Vector3();
    this.desiredLook = new THREE.Vector3();
    this.shakeTrauma = 0;

    this.combatYaw = Math.PI;
    this.combatPitch = 0.22; // slight downward over-the-shoulder pitch
    this.lockedOn = true;
    this.orbitIdleTimer = 0;

    this.previewYaw = 0.35;
    this.previewDragging = false;

    this.baseFov = 55;
    this.currentFov = 55;
    this.targetFovOffset = 0;
    this.fovPulseTimer = 0;
    this.impactOffset = new THREE.Vector3();
  }

  addShake(amount) {
    this.shakeTrauma = Math.min(0.95, this.shakeTrauma + amount * 0.88);
  }

  addImpactKick(dirX = 0, dirZ = 0, strength = 0.25) {
    const len = Math.hypot(dirX, dirZ);
    const nx = len > 0.001 ? dirX / len : 0;
    const nz = len > 0.001 ? dirZ / len : 1;
    const mag = THREE.MathUtils.clamp(strength, 0, 0.42);
    this.impactOffset.x = THREE.MathUtils.clamp(this.impactOffset.x + nx * mag, -0.45, 0.45);
    this.impactOffset.y = THREE.MathUtils.clamp(this.impactOffset.y + mag * 0.22, -0.2, 0.22);
    this.impactOffset.z = THREE.MathUtils.clamp(this.impactOffset.z + nz * mag, -0.45, 0.45);
  }

  pulseFov(offsetDeg, duration = 0.28) {
    this.targetFovOffset = offsetDeg;
    this.fovPulseTimer = duration;
  }

  toggleLockOn() {
    this.lockedOn = !this.lockedOn;
    return this.lockedOn;
  }

  setLockedOn(val) {
    this.lockedOn = !!val;
  }

  rotatePreview(deltaYaw) {
    this.previewYaw += deltaYaw;
  }

  orbitCombat(deltaYaw, deltaPitch = 0) {
    this.combatYaw += deltaYaw;
    this.combatPitch = THREE.MathUtils.clamp(this.combatPitch + deltaPitch, 0.05, 0.62);
    this.orbitIdleTimer = 1.6;
  }

  snapToCombat(playerPos, bossPos) {
    const dx = bossPos.x - playerPos.x;
    const dz = bossPos.z - playerPos.z;
    this.combatYaw = Math.atan2(dx, dz);
    this.combatPitch = 0.2;
    this.lockedOn = true;
    this.orbitIdleTimer = 0;
    this.impactOffset.set(0, 0, 0);

    const fx = Math.sin(this.combatYaw);
    const fz = Math.cos(this.combatYaw);
    const rx = fz;
    const rz = -fx;

    // Over-the-right-shoulder hero framing right behind the warrior
    this.currentPos.set(
      playerPos.x - fx * 5.2 + rx * 0.85,
      2.45,
      playerPos.z - fz * 5.2 + rz * 0.85
    );
    this.currentLook.set(
      THREE.MathUtils.lerp(playerPos.x, bossPos.x, 0.35),
      1.68,
      THREE.MathUtils.lerp(playerPos.z, bossPos.z, 0.35)
    );
    this.camera.position.copy(this.currentPos);
    this.camera.lookAt(this.currentLook);
  }

  update(dt, elapsed, phase, introTimer, playerPos, lockTargetPos, arena, previewHeight = 2.0) {
    if (this.orbitIdleTimer > 0) {
      this.orbitIdleTimer = Math.max(0, this.orbitIdleTimer - dt);
    }

    if (phase === 'PREVIEW') {
      if (!this.previewDragging) {
        this.previewYaw += dt * 0.45;
      }
      const dist = Math.max(4.6, previewHeight * 2.25);
      this.desiredPos.set(
        Math.sin(this.previewYaw) * dist,
        Math.max(2.0, previewHeight * 0.88),
        Math.cos(this.previewYaw) * dist
      );
      const rightX = Math.cos(this.previewYaw);
      const rightZ = -Math.sin(this.previewYaw);
      this.desiredLook.set(-rightX * 1.15, previewHeight * 0.56, -rightZ * 1.15);
    } else if (phase === 'MENU') {
      const ang = elapsed * 0.16;
      this.desiredPos.set(Math.sin(ang) * 14.5, 4.4 + Math.sin(elapsed * 0.4) * 0.35, Math.cos(ang) * 14.5);
      this.desiredLook.set(0, 2.4, -5.5);
    } else if (phase === 'INTRO') {
      if (introTimer < 1.8) {
        const p = introTimer / 1.8;
        const ang = THREE.MathUtils.lerp(-0.95, 0.35, p);
        this.desiredPos.set(
          lockTargetPos.x + Math.sin(ang) * 7.2,
          THREE.MathUtils.lerp(2.1, 3.6, p),
          lockTargetPos.z + Math.cos(ang) * 7.2
        );
        this.desiredLook.set(lockTargetPos.x, 2.75, lockTargetPos.z);
      } else {
        const p = Math.min(1, (introTimer - 1.8) / 1.4);
        const dx = lockTargetPos.x - playerPos.x;
        const dz = lockTargetPos.z - playerPos.z;
        this.combatYaw = Math.atan2(dx, dz);
        const fx = Math.sin(this.combatYaw);
        const fz = Math.cos(this.combatYaw);
        const rx = fz;
        const rz = -fx;
        const endPosX = playerPos.x - fx * 5.2 + rx * 0.85;
        const endPosZ = playerPos.z - fz * 5.2 + rz * 0.85;
        this.desiredPos.set(
          THREE.MathUtils.lerp(this.desiredPos.x, endPosX, p),
          THREE.MathUtils.lerp(3.6, 2.45, p),
          THREE.MathUtils.lerp(this.desiredPos.z, endPosZ, p)
        );
        this.desiredLook.set(
          THREE.MathUtils.lerp(lockTargetPos.x, THREE.MathUtils.lerp(playerPos.x, lockTargetPos.x, 0.35), p),
          THREE.MathUtils.lerp(2.75, 1.68, p),
          THREE.MathUtils.lerp(lockTargetPos.z, THREE.MathUtils.lerp(playerPos.z, lockTargetPos.z, 0.35), p)
        );
      }
    } else if (phase === 'VICTORY') {
      const ang = elapsed * 0.45;
      this.desiredPos.set(playerPos.x + Math.sin(ang) * 4.8, 2.2, playerPos.z + Math.cos(ang) * 4.8);
      this.desiredLook.set(playerPos.x, 1.35, playerPos.z);
    } else if (phase === 'DEFEAT') {
      this.desiredPos.set(playerPos.x + 3.2, 3.8, playerPos.z + 4.8);
      this.desiredLook.set(playerPos.x, 0.65, playerPos.z);
    } else {
      // God-of-War over-the-shoulder behind-player combat camera
      const dx = lockTargetPos.x - playerPos.x;
      const dz = lockTargetPos.z - playerPos.z;
      const targetDist = Math.hypot(dx, dz);

      if (this.lockedOn && this.orbitIdleTimer <= 0.15) {
        const targetYaw = Math.atan2(dx, dz);
        this.combatYaw = lerpAngle(this.combatYaw, targetYaw, Math.min(1, dt * 4.6));
      }

      const cosP = Math.cos(this.combatPitch);
      const sinP = Math.sin(this.combatPitch);
      // Slight dynamic pullback when far from the boss so both remain crisp
      const followRadius = this.lockedOn
        ? THREE.MathUtils.clamp(5.05 + targetDist * 0.08, 5.15, 6.45)
        : 5.35;

      const fx = Math.sin(this.combatYaw);
      const fz = Math.cos(this.combatYaw);
      const rx = fz;
      const rz = -fx;

      const shoulderOffset = 0.85;
      const camBack = followRadius * cosP;
      const camHeight = 1.68 + followRadius * sinP;

      this.desiredPos.set(
        playerPos.x - fx * camBack + rx * shoulderOffset,
        camHeight,
        playerPos.z - fz * camBack + rz * shoulderOffset
      );

      if (this.lockedOn) {
        const targetWeight = THREE.MathUtils.clamp(0.32 + targetDist * 0.01, 0.28, 0.45);
        this.desiredLook.set(
          THREE.MathUtils.lerp(playerPos.x, lockTargetPos.x, targetWeight) + rx * 0.25,
          1.62 + (targetDist > 8 ? 0.18 : 0),
          THREE.MathUtils.lerp(playerPos.z, lockTargetPos.z, targetWeight) + rz * 0.25
        );
      } else {
        this.desiredLook.set(
          playerPos.x + fx * 6.5 + rx * 0.45,
          1.55 - this.combatPitch * 1.4,
          playerPos.z + fz * 6.5 + rz * 0.45
        );
      }
    }

    // Wall / arena boundary & ground clearance anti-clipping
    const camR = Math.hypot(this.desiredPos.x, this.desiredPos.z);
    const maxCamR = ARENA_RADIUS - 0.65;
    if (camR > maxCamR) {
      const s = maxCamR / camR;
      this.desiredPos.x *= s;
      this.desiredPos.z *= s;
      this.desiredPos.y = Math.max(this.desiredPos.y, 3.3);
    }
    this.desiredPos.y = Math.max(1.22, this.desiredPos.y);

    // Push camera smoothly clear of interior cover pillars & braziers
    if (arena && arena.obstacles) {
      for (const ob of arena.obstacles) {
        const ox = this.desiredPos.x - ob.x;
        const oz = this.desiredPos.z - ob.z;
        const minD = ob.radius + 0.9;
        if (ox * ox + oz * oz < minD * minD) {
          const d = Math.max(0.01, Math.hypot(ox, oz));
          this.desiredPos.x = ob.x + (ox / d) * minD;
          this.desiredPos.z = ob.z + (oz / d) * minD;
        }
      }
    }

    // Dynamic combat FOV pulses (dodge/skill speed or parry/stagger zoom)
    if (this.fovPulseTimer > 0) {
      this.fovPulseTimer -= dt;
      if (this.fovPulseTimer <= 0) this.targetFovOffset = 0;
    }
    const desiredFov = this.baseFov + this.targetFovOffset;
    if (Math.abs(desiredFov - this.currentFov) > 0.05) {
      this.currentFov = THREE.MathUtils.lerp(this.currentFov, desiredFov, Math.min(1, dt * 10));
      this.camera.fov = this.currentFov;
      this.camera.updateProjectionMatrix();
    }

    const followRate = phase === 'INTRO' ? 3.8 : 9.2;
    this.currentPos.lerp(this.desiredPos, Math.min(1, dt * followRate));
    this.currentLook.lerp(this.desiredLook, Math.min(1, dt * 11.5));

    this.camera.position.copy(this.currentPos);

    if (this.impactOffset.lengthSq() > 0.00001) {
      this.camera.position.add(this.impactOffset);
      this.camera.position.y = Math.max(1.2, this.camera.position.y);
      const decay = Math.exp(-dt * 14);
      this.impactOffset.multiplyScalar(decay);
      if (this.impactOffset.lengthSq() < 0.00001) this.impactOffset.set(0, 0, 0);
    }

    let rollKick = 0;
    if (this.shakeTrauma > 0.001) {
      const mag = Math.min(0.42, this.shakeTrauma * this.shakeTrauma * 0.46);
      const t = elapsed * 42;
      this.camera.position.x += (Math.sin(t) * 0.65 + (Math.random() - 0.5) * 0.35) * mag;
      this.camera.position.y += (Math.cos(t * 1.37) * 0.55 + (Math.random() - 0.5) * 0.3) * mag * 0.72;
      this.camera.position.z += (Math.sin(t * 0.83) * 0.5 + (Math.random() - 0.5) * 0.3) * mag;
      rollKick = Math.sin(t * 1.15) * mag * 0.048;
      this.shakeTrauma = Math.max(0, this.shakeTrauma - dt * 2.45);
    }

    this.camera.lookAt(this.currentLook);
    if (rollKick !== 0) {
      this.camera.rotateZ(rollKick);
    }
  }
}

function lerpAngle(a, b, t) {
  let diff = ((b - a + Math.PI) % (Math.PI * 2)) - Math.PI;
  if (diff < -Math.PI) diff += Math.PI * 2;
  return a + diff * t;
}
