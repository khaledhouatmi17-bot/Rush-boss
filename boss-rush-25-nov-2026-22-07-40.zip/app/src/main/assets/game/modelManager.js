import * as THREE from 'three';
import { GLTFLoader } from '/vendor/addons/loaders/GLTFLoader.js';
import * as SkeletonUtils from '/vendor/addons/utils/SkeletonUtils.js';
import { getCartoonGradientMap, applyStylizedRimShader } from './stylized.js';

// Ordered from most-specific to broadest so KayKit, Mixamo, and custom user GLBs all map cleanly
const CLIP_MATCHERS = {
  IDLE: ['idle_combat', 'idle', 'stand', 'breath', 'wait'],
  WALK: ['walking_a', 'walking_b', 'walk', 'patrol', 'march'],
  RUN: ['running_a', 'running_b', 'run', 'sprint', 'jog'],
  MOVE: ['running_a', 'walking_a', 'run', 'walk', 'sprint', 'move'],
  ATTACK_1: ['1h_melee_attack_slice_horizontal', 'attack_1', 'attack1', 'slash_1', 'combo_1'],
  ATTACK_2: ['1h_melee_attack_slice_diagonal', 'attack_2', 'attack2', 'slash_2', 'combo_2'],
  ATTACK_3: ['1h_melee_attack_jump_chop', '1h_melee_attack_chop', 'attack_3', 'attack3', 'slash_3', 'combo_3'],
  ATTACK: ['1h_melee_attack_slice_horizontal', '1h_melee_attack_chop', 'attack', 'slash', 'swing', 'strike', 'combo'],
  HEAVY: ['2h_melee_attack_chop', '2h_melee_attack_slice', 'heavy', 'smash', 'slam', 'cleave', 'power'],
  SKILL: ['2h_melee_attack_spinning', '2h_melee_attack_spin', 'skill', 'spin', 'magic', 'whirl', 'special'],
  CAST: ['spellcast_raise', 'spellcast_summon', 'spellcasting', 'taunt_longer'],
  DODGE: ['dodge_forward', 'dodge', 'roll', 'dash', 'evade', 'jump_full_short'],
  DODGE_BACK: ['dodge_backward', 'dodge_forward', 'dodge'],
  DODGE_LEFT: ['dodge_left', 'dodge_forward', 'dodge'],
  DODGE_RIGHT: ['dodge_right', 'dodge_forward', 'dodge'],
  PARRY: ['blocking', 'block', 'parry', 'guard', 'shield', 'defend'],
  PARRY_HIT: ['block_hit', 'block_attack', 'blocking'],
  HIT: ['hit_a', 'hurt', 'damage', 'recoil', 'impact', 'flinch', 'hit_react'],
  DEATH: ['death_c_skeletons', 'death_a', 'death_b', 'death', 'die', 'dead', 'defeat', 'fall'],
  VICTORY: ['cheer', 'victory', 'win', 'celebrate', 'salute'],
  STUNNED: ['hit_b', 'lie_idle', 'stun', 'dizzy', 'kneel'],
  ENRAGED: ['taunt_longer', 'taunt', 'spellcast_raise', 'roar', 'rage', 'scream', 'enrage'],
};

const HIDE_DUPLICATE_NODES = new Set([
  '1H_Sword_Offhand',
  '2H_Sword',
  'Badge_Shield',
  'Rectangle_Shield',
  'Spike_Shield',
  '1H_Axe_Offhand',
  '2H_Axe',
  'Mug',
]);

export function disposeObject3D(obj, opts = {}) {
  if (!obj) return;
  const {
    disposeGeometries = true,
    disposeMaterials = true,
    disposeTextures = true,
    includeShared = false,
  } = opts;
  obj.traverse((child) => {
    if (disposeGeometries && child.geometry) {
      if (includeShared || !child.geometry.userData?.shared) {
        child.geometry.dispose();
      }
    }
    if (disposeMaterials && child.material) {
      const mats = Array.isArray(child.material) ? child.material : [child.material];
      for (const m of mats) {
        if (!m || (!includeShared && m.userData?.shared)) continue;
        if (disposeTextures) {
          for (const key of Object.keys(m)) {
            const val = m[key];
            if (
              val &&
              typeof val === 'object' &&
              typeof val.dispose === 'function' &&
              val.isTexture &&
              (includeShared || !val.userData?.shared)
            ) {
              val.dispose();
            }
          }
        }
        m.dispose();
      }
    }
  });
}

export function markSharedResources(obj) {
  if (!obj) return;
  obj.traverse((child) => {
    if (child.geometry) {
      child.geometry.userData = { ...(child.geometry.userData || {}), shared: true };
    }
    if (child.material) {
      const mats = Array.isArray(child.material) ? child.material : [child.material];
      for (const m of mats) {
        if (!m) continue;
        for (const key of Object.keys(m)) {
          const val = m[key];
          if (val && typeof val === 'object' && val.isTexture) {
            val.userData = { ...(val.userData || {}), shared: true };
          }
        }
      }
    }
  });
}

export function cloneInstanceMaterials(obj) {
  if (!obj) return [];
  const matCache = new Map();
  const tracked = [];
  const cloneOne = (m) => {
    if (!m) return m;
    if (matCache.has(m)) return matCache.get(m);
    const cloned = m.clone();
    cloned.userData = { ...(m.userData || {}) };
    if (m.userData?.hasStylizedRim) {
      // Retain stylized rim shader hooks when cloned from enhanced template materials
      cloned.userData.hasStylizedRim = false;
      applyStylizedRimShader(
        cloned,
        m.userData.rimColor ? m.userData.rimColor.getHex() : 0xff7a2b,
        m.userData.rimStrength ?? 0.45
      );
    }
    matCache.set(m, cloned);
    tracked.push(cloned);
    return cloned;
  };
  obj.traverse((child) => {
    if ((child.isMesh || child.isSkinnedMesh) && !child.name.endsWith('_outline') && child.material) {
      child.material = Array.isArray(child.material)
        ? child.material.map(cloneOne)
        : cloneOne(child.material);
    }
  });
  return tracked;
}

function isNodeHierarchyVisible(node) {
  let cur = node;
  while (cur) {
    if (cur.visible === false) return false;
    cur = cur.parent;
  }
  return true;
}

export function computeVisibleBoundingBox(root) {
  root.updateMatrixWorld(true);
  const box = new THREE.Box3();
  const childBox = new THREE.Box3();
  let foundVisible = false;
  root.traverse((node) => {
    if ((node.isMesh || node.isSkinnedMesh) && node.geometry && isNodeHierarchyVisible(node)) {
      if (!node.geometry.boundingBox) node.geometry.computeBoundingBox();
      if (node.geometry.boundingBox && !node.geometry.boundingBox.isEmpty()) {
        childBox.copy(node.geometry.boundingBox).applyMatrix4(node.matrixWorld);
        box.union(childBox);
        foundVisible = true;
      }
    }
  });
  if (!foundVisible) {
    box.setFromObject(root);
  }
  return box;
}

function attachCartoonOutline(mesh, thickness = 0.014, colorHex = 0x0b080e) {
  const srcGeo = mesh.geometry;
  if (!srcGeo || !srcGeo.attributes.position || !srcGeo.attributes.normal) return null;
  const srcMats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
  if (srcMats.some((m) => m && m.side === THREE.DoubleSide)) return null;

  const posAttr = srcGeo.attributes.position;
  const normAttr = srcGeo.attributes.normal;
  const extrudedGeo = srcGeo.clone();
  const outPos = extrudedGeo.attributes.position;

  for (let i = 0; i < posAttr.count; i++) {
    outPos.setXYZ(
      i,
      posAttr.getX(i) + normAttr.getX(i) * thickness,
      posAttr.getY(i) + normAttr.getY(i) * thickness,
      posAttr.getZ(i) + normAttr.getZ(i) * thickness
    );
  }
  outPos.needsUpdate = true;

  const outlineMat = new THREE.MeshBasicMaterial({
    color: colorHex,
    side: THREE.BackSide,
  });

  if (mesh.isSkinnedMesh && mesh.skeleton) {
    const outlineMesh = new THREE.SkinnedMesh(extrudedGeo, outlineMat);
    outlineMesh.name = `${mesh.name || 'mesh'}_outline`;
    outlineMesh.castShadow = false;
    outlineMesh.receiveShadow = false;
    outlineMesh.frustumCulled = false;
    outlineMesh.bind(mesh.skeleton, mesh.bindMatrix);
    if (mesh.parent) mesh.parent.add(outlineMesh);
    return outlineMesh;
  }

  const outlineMesh = new THREE.Mesh(extrudedGeo, outlineMat);
  outlineMesh.name = `${mesh.name || 'mesh'}_outline`;
  outlineMesh.castShadow = false;
  outlineMesh.receiveShadow = false;
  mesh.add(outlineMesh);
  return outlineMesh;
}

function convertToStylizedToonMaterial(mat) {
  if (!mat || mat.isMeshToonMaterial) return mat;
  const toon = new THREE.MeshToonMaterial({
    color: mat.color ? mat.color.clone() : new THREE.Color(0xffffff),
    gradientMap: getCartoonGradientMap(),
    map: mat.map || null,
    emissive: mat.emissive ? mat.emissive.clone() : new THREE.Color(0x000000),
    emissiveMap: mat.emissiveMap || null,
    emissiveIntensity: mat.emissiveIntensity ?? 1.0,
    side: mat.side ?? THREE.FrontSide,
    transparent: !!mat.transparent,
    opacity: mat.opacity ?? 1.0,
    vertexColors: !!mat.vertexColors,
  });
  toon.name = mat.name || '';
  return toon;
}

export class GLBModelLoader {
  constructor() {
    this.loader = new GLTFLoader();
    this._cache = new Map();
    this._inflight = new Map();
  }

  _shouldCacheUrl(url, opts = {}) {
    if (!url || opts.bypassCache) return false;
    // Custom user GLBs append ?t=timestamp for intentional reloads; cache built-in models by path
    return !String(url).includes('?t=');
  }

  async _loadRawGLTF(url, opts = {}) {
    const cacheable = this._shouldCacheUrl(url, opts);
    if (cacheable && this._cache.has(url)) {
      return this._cache.get(url);
    }
    if (cacheable && this._inflight.has(url)) {
      return this._inflight.get(url);
    }

    const promise = this.loader.loadAsync(url).then((gltf) => {
      if (cacheable && gltf?.scene) {
        markSharedResources(gltf.scene);
        this._cache.set(url, gltf);
      }
      return gltf;
    }).finally(() => {
      this._inflight.delete(url);
    });

    if (cacheable) {
      this._inflight.set(url, promise);
    }
    return promise;
  }

  clearCache() {
    for (const gltf of this._cache.values()) {
      if (gltf?.scene) {
        disposeObject3D(gltf.scene, { includeShared: true });
      }
    }
    this._cache.clear();
    this._inflight.clear();
  }

  async loadAsync(url, targetHeight = 1.85, opts = {}) {
    const {
      stylizeToon = false,
      addOutlines = false,
      outlineThickness = 0.012,
      enhancePBR = true,
      preservePBRMaterials = false,
      hideSpareWeapons = true,
      rimColor = 0x7ab8ff,
      rimStrength = 0.42,
    } = opts;

    const gltf = await this._loadRawGLTF(url, opts);
    if (!gltf?.scene) {
      throw new Error('GLB/GLTF file contains no scene');
    }
    const cloned = SkeletonUtils.clone(gltf.scene);
    // Always clone per-instance materials so shared cached geometries/textures never mutate or double-dispose
    cloneInstanceMaterials(cloned);

    // Hide duplicate offhand/alternate KayKit weapons so one clean loadout shows
    if (hideSpareWeapons) {
      cloned.traverse((node) => {
        if (HIDE_DUPLICATE_NODES.has(node.name)) {
          node.visible = false;
        }
      });
    }

    // Measure visible bounding box & auto-normalize scale and floor grounding
    const box = computeVisibleBoundingBox(cloned);
    const size = new THREE.Vector3();
    box.getSize(size);
    const rawHeight = Number.isFinite(size.y) && size.y > 0.01 ? size.y : 1.0;
    const scaleFactor = THREE.MathUtils.clamp(targetHeight / rawHeight, 0.01, 500);
    cloned.scale.multiplyScalar(scaleFactor);

    const scaledBox = computeVisibleBoundingBox(cloned);
    const center = new THREE.Vector3();
    scaledBox.getCenter(center);

    if (Number.isFinite(center.x)) cloned.position.x -= center.x;
    if (Number.isFinite(center.z)) cloned.position.z -= center.z;
    if (Number.isFinite(scaledBox.min.y)) cloned.position.y -= scaledBox.min.y;

    let meshCount = 0;
    let hasSkeleton = false;
    const meshesToOutline = [];
    const trackedMaterials = [];
    const seenMats = new Set();

    cloned.traverse((node) => {
      if (node.isMesh || node.isSkinnedMesh) {
        if (!isNodeHierarchyVisible(node)) return;
        meshCount++;
        node.castShadow = true;
        node.receiveShadow = true;
        node.frustumCulled = false;
        if (node.isSkinnedMesh) hasSkeleton = true;

        if (stylizeToon && node.material) {
          if (Array.isArray(node.material)) {
            node.material = node.material.map((m) => {
              const next = convertToStylizedToonMaterial(m);
              if (!seenMats.has(next)) {
                seenMats.add(next);
                trackedMaterials.push(next);
              }
              return next;
            });
          } else {
            const next = convertToStylizedToonMaterial(node.material);
            if (!seenMats.has(next)) {
              seenMats.add(next);
              trackedMaterials.push(next);
            }
            node.material = next;
          }
        } else if (node.material) {
          const mats = Array.isArray(node.material) ? node.material : [node.material];
          for (const m of mats) {
            if (!m) continue;
            if (enhancePBR && m.isMeshStandardMaterial) {
              if (preservePBRMaterials) {
                // Respect custom user GLB PBR metallic/roughness calibration while enriching IBL reflections & rim readability
                m.envMapIntensity = Math.max(m.envMapIntensity ?? 1.0, 1.35);
                if (rimStrength > 0 && (m.emissiveIntensity ?? 0) <= 1.0) {
                  applyStylizedRimShader(m, rimColor, Math.min(0.28, rimStrength * 0.55));
                }
              } else {
                // Sharpen built-in stylized PBR highlights & apply crisp dark-fantasy rim-lighting against scene IBL
                m.envMapIntensity = Math.max(m.envMapIntensity ?? 1.0, 1.65);
                if (m.metalness === 0) m.metalness = 0.24;
                m.roughness = Math.min(m.roughness ?? 0.5, 0.38);
                if (rimStrength > 0 && (m.emissiveIntensity ?? 0) <= 1.0) {
                  applyStylizedRimShader(m, rimColor, rimStrength);
                }
              }
              m.needsUpdate = true;
            }
            if (!seenMats.has(m)) {
              seenMats.add(m);
              trackedMaterials.push(m);
            }
          }
        }

        if (addOutlines && !node.name.endsWith('_outline')) {
          meshesToOutline.push(node);
        }
      }
    });

    if (meshCount === 0) {
      disposeObject3D(cloned);
      throw new Error('Model contains no visible meshes');
    }

    if (addOutlines) {
      for (const m of meshesToOutline) {
        attachCartoonOutline(m, outlineThickness / Math.max(0.5, scaleFactor));
      }
    }

    // Attach or locate sword trail markers cleanly on held weapons
    let swordBaseMarker = cloned.getObjectByName('SwordBase') || null;
    let swordTipMarker = cloned.getObjectByName('SwordTip') || null;
    if (!swordBaseMarker || !swordTipMarker) {
      const weaponNode =
        cloned.getObjectByName('1H_Sword') ||
        cloned.getObjectByName('1H_Axe') ||
        cloned.getObjectByName('handslot.r') ||
        null;
      if (weaponNode) {
        swordBaseMarker = new THREE.Object3D();
        swordBaseMarker.name = 'SwordBase';
        swordBaseMarker.position.set(0, 0.16, 0);
        weaponNode.add(swordBaseMarker);

        swordTipMarker = new THREE.Object3D();
        swordTipMarker.name = 'SwordTip';
        swordTipMarker.position.set(0, 1.36, 0);
        weaponNode.add(swordTipMarker);
      }
    }

    const animations = gltf.animations || [];
    const animationNames = animations.map((c, idx) => c.name || `Clip_${idx + 1}`);

    return {
      scene: cloned,
      animations,
      swordBaseMarker,
      swordTipMarker,
      trackedMaterials,
      meta: {
        meshCount,
        hasRig: hasSkeleton || animations.length > 0,
        animationNames,
      },
    };
  }
}

export class GLBAnimationController {
  constructor(modelRoot, animations = []) {
    this.root = modelRoot;
    this.basePositionY = modelRoot?.position?.y ?? 0;
    this.baseRotationX = modelRoot?.rotation?.x ?? 0;
    this.baseRotationZ = modelRoot?.rotation?.z ?? 0;
    this._hasProceduralTransform = false;
    this.mixer = new THREE.AnimationMixer(modelRoot);
    this.actions = new Map();
    this.stateClips = new Map();
    this.currentAction = null;
    this.currentStateKey = null;

    animations.forEach((clip, idx) => {
      const name = clip.name || `Clip_${idx + 1}`;
      const action = this.mixer.clipAction(clip);
      this.actions.set(name, action);
    });

    for (const [stateKey, keywords] of Object.entries(CLIP_MATCHERS)) {
      let matched = null;
      for (const kw of keywords) {
        // Exact lowercase match first, then substring match
        matched =
          animations.find((c) => (c.name || '').toLowerCase() === kw) ||
          animations.find((c) => (c.name || '').toLowerCase().includes(kw));
        if (matched) break;
      }
      if (matched) {
        const matchedIdx = animations.indexOf(matched);
        const keyName = matched.name || `Clip_${matchedIdx + 1}`;
        const act = this.actions.get(keyName);
        if (act) this.stateClips.set(stateKey, act);
      }
    }

    if (!this.stateClips.has('MOVE')) {
      const mv = this.stateClips.get('RUN') || this.stateClips.get('WALK');
      if (mv) this.stateClips.set('MOVE', mv);
    }
    if (!this.stateClips.has('RUN')) {
      const mv = this.stateClips.get('MOVE') || this.stateClips.get('WALK');
      if (mv) this.stateClips.set('RUN', mv);
    }
    if (!this.stateClips.has('WALK')) {
      const mv = this.stateClips.get('MOVE') || this.stateClips.get('RUN');
      if (mv) this.stateClips.set('WALK', mv);
    }

    if (!this.stateClips.has('IDLE') && animations.length > 0) {
      const firstName = animations[0].name || 'Clip_1';
      this.stateClips.set('IDLE', this.actions.get(firstName));
    }
  }

  playState(stateKey, loopOnce = false, speed = 1.0, fadeSec = 0.12) {
    if (
      this.currentStateKey === stateKey &&
      !loopOnce &&
      this.currentAction &&
      this.currentAction.loop === THREE.LoopRepeat &&
      !this.currentAction.clampWhenFinished &&
      this.currentAction.isRunning()
    ) {
      this.currentAction.setEffectiveTimeScale(speed);
      return;
    }

    let action = this.stateClips.get(stateKey);
    if (!action && (stateKey === 'ATTACK_1' || stateKey === 'ATTACK_2' || stateKey === 'ATTACK_3')) {
      action = this.stateClips.get('ATTACK');
    }
    if (!action && stateKey.startsWith('DODGE')) {
      action = this.stateClips.get('DODGE');
    }
    if (!action) {
      action = this.stateClips.get('IDLE');
    }

    if (!action) {
      this.currentStateKey = stateKey;
      return;
    }

    if (this.currentAction === action && !loopOnce) {
      // Restore repeating playback cleanly if this shared clip was previously clamped as LoopOnce (e.g. missing DEATH/HIT fallback)
      if (action.loop !== THREE.LoopRepeat || action.clampWhenFinished || !action.isRunning()) {
        action.enabled = true;
        action.paused = false;
        action.clampWhenFinished = false;
        action.setLoop(THREE.LoopRepeat, Infinity);
        action.setEffectiveWeight(1);
        action.reset();
        action.play();
      }
      action.setEffectiveTimeScale(speed);
      this.currentStateKey = stateKey;
      return;
    }

    action.enabled = true;
    action.paused = false;
    action.reset();
    action.setEffectiveWeight(1);
    action.setEffectiveTimeScale(speed);
    action.setLoop(loopOnce ? THREE.LoopOnce : THREE.LoopRepeat, loopOnce ? 1 : Infinity);
    action.clampWhenFinished = loopOnce;
    action.play();

    if (this.currentAction && this.currentAction !== action) {
      this.currentAction.crossFadeTo(action, fadeSec, false);
    }
    this.currentAction = action;
    this.currentStateKey = stateKey;
  }

  playClipByName(name) {
    const action = this.actions.get(name);
    if (!action) return;
    action.enabled = true;
    action.paused = false;
    action.reset();
    action.setEffectiveWeight(1);
    action.setEffectiveTimeScale(1);
    action.setLoop(THREE.LoopRepeat, Infinity);
    action.clampWhenFinished = false;
    action.play();
    if (this.currentAction && this.currentAction !== action) {
      this.currentAction.crossFadeTo(action, 0.15, false);
    }
    this.currentAction = action;
    this.currentStateKey = name;
  }

  resetTransform() {
    if (!this.root) return;
    this.root.position.y = this.basePositionY;
    this.root.rotation.x = this.baseRotationX;
    this.root.rotation.z = this.baseRotationZ;
    this._hasProceduralTransform = false;
  }

  update(dt, stateKey, elapsed, isMoving) {
    this.mixer.update(dt);

    const hasSpecific =
      this.stateClips.has(stateKey) ||
      ((stateKey === 'ATTACK_1' || stateKey === 'ATTACK_2' || stateKey === 'ATTACK_3') && this.stateClips.has('ATTACK')) ||
      (stateKey.startsWith('DODGE') && this.stateClips.has('DODGE')) ||
      (stateKey === 'DEFEATED' && this.stateClips.has('DEATH'));

    const smooth = Math.min(1, dt * 12);

    if (hasSpecific) {
      if (this._hasProceduralTransform) {
        this.root.position.y = THREE.MathUtils.lerp(this.root.position.y, this.basePositionY, smooth);
        this.root.rotation.x = THREE.MathUtils.lerp(this.root.rotation.x, this.baseRotationX, smooth);
        this.root.rotation.z = THREE.MathUtils.lerp(this.root.rotation.z, this.baseRotationZ, smooth);
        if (
          Math.abs(this.root.position.y - this.basePositionY) < 0.0005 &&
          Math.abs(this.root.rotation.x - this.baseRotationX) < 0.0005 &&
          Math.abs(this.root.rotation.z - this.baseRotationZ) < 0.0005
        ) {
          this.root.position.y = this.basePositionY;
          this.root.rotation.x = this.baseRotationX;
          this.root.rotation.z = this.baseRotationZ;
          this._hasProceduralTransform = false;
        }
      }
      return;
    }

    this._hasProceduralTransform = true;

    if (stateKey === 'MOVE' || stateKey === 'WALK' || stateKey === 'RUN' || isMoving) {
      const targetY = this.basePositionY + Math.abs(Math.sin(elapsed * 10)) * 0.12;
      const targetRotZ = this.baseRotationZ + Math.sin(elapsed * 10) * 0.06;
      this.root.position.y = THREE.MathUtils.lerp(this.root.position.y, targetY, Math.min(1, dt * 18));
      this.root.rotation.x = THREE.MathUtils.lerp(this.root.rotation.x, this.baseRotationX, smooth);
      this.root.rotation.z = THREE.MathUtils.lerp(this.root.rotation.z, targetRotZ, Math.min(1, dt * 18));
    } else if (stateKey.startsWith('ATTACK') || stateKey === 'HEAVY' || stateKey === 'SKILL') {
      this.root.position.y = THREE.MathUtils.lerp(this.root.position.y, this.basePositionY, smooth);
      this.root.rotation.x = THREE.MathUtils.lerp(this.root.rotation.x, this.baseRotationX + 0.18, Math.min(1, dt * 16));
      this.root.rotation.z = THREE.MathUtils.lerp(this.root.rotation.z, this.baseRotationZ, smooth);
    } else if (stateKey === 'HIT') {
      this.root.position.y = THREE.MathUtils.lerp(this.root.position.y, this.basePositionY, smooth);
      this.root.rotation.x = THREE.MathUtils.lerp(this.root.rotation.x, this.baseRotationX - 0.16, Math.min(1, dt * 16));
      this.root.rotation.z = THREE.MathUtils.lerp(this.root.rotation.z, this.baseRotationZ, smooth);
    } else if (stateKey === 'STUNNED') {
      this.root.position.y = THREE.MathUtils.lerp(this.root.position.y, this.basePositionY, smooth);
      this.root.rotation.x = THREE.MathUtils.lerp(this.root.rotation.x, this.baseRotationX, smooth);
      this.root.rotation.z = THREE.MathUtils.lerp(this.root.rotation.z, this.baseRotationZ + Math.sin(elapsed * 7) * 0.035, smooth);
    } else if (stateKey === 'DEATH' || stateKey === 'DEFEATED') {
      this.root.position.y = THREE.MathUtils.lerp(this.root.position.y, this.basePositionY, smooth);
      this.root.rotation.x = THREE.MathUtils.lerp(this.root.rotation.x, this.baseRotationX + 1.35, Math.min(1, dt * 6));
      this.root.rotation.z = THREE.MathUtils.lerp(this.root.rotation.z, this.baseRotationZ, smooth);
    } else {
      const idleBreath = this.actions.size === 0 ? Math.sin(elapsed * 2.2) * 0.025 : 0;
      this.root.position.y = THREE.MathUtils.lerp(this.root.position.y, this.basePositionY, smooth);
      this.root.rotation.x = THREE.MathUtils.lerp(this.root.rotation.x, this.baseRotationX + idleBreath, smooth);
      this.root.rotation.z = THREE.MathUtils.lerp(this.root.rotation.z, this.baseRotationZ, smooth);
    }
  }

  dispose() {
    this.mixer.stopAllAction();
    this.mixer.uncacheRoot(this.root);
    this.actions.clear();
    this.stateClips.clear();
  }
}
