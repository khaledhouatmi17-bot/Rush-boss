import * as THREE from 'three';

function createRadialGlowTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 128;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;
  const g = ctx.createRadialGradient(size / 2, size / 2, 2, size / 2, size / 2, size / 2);
  g.addColorStop(0, 'rgba(255, 255, 255, 1.0)');
  g.addColorStop(0.28, 'rgba(255, 230, 180, 0.72)');
  g.addColorStop(0.62, 'rgba(255, 140, 60, 0.22)');
  g.addColorStop(1, 'rgba(255, 80, 20, 0.0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createStarFlashTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 128;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  const half = size / 2;
  const g = ctx.createRadialGradient(half, half, 1, half, half, half);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.25, 'rgba(255,245,210,0.85)');
  g.addColorStop(0.6, 'rgba(255,175,90,0.2)');
  g.addColorStop(1, 'rgba(255,100,30,0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);

  // Crisp cartoon anime-style 4-point impact flare rays + hot white core
  ctx.save();
  ctx.translate(half, half);
  ctx.fillStyle = 'rgba(255,255,255,0.96)';
  for (let i = 0; i < 2; i++) {
    ctx.beginPath();
    ctx.ellipse(0, 0, half * 0.96, 3.6, (i * Math.PI) / 2, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.fillStyle = 'rgba(255,250,230,0.65)';
  ctx.beginPath();
  ctx.arc(0, 0, half * 0.22, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createDangerRingTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 128;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  const half = size / 2;
  const g = ctx.createRadialGradient(half, half, 6, half, half, half);
  g.addColorStop(0.0, 'rgba(255, 60, 24, 0.08)');
  g.addColorStop(0.68, 'rgba(255, 70, 28, 0.28)');
  g.addColorStop(0.88, 'rgba(255, 130, 50, 0.85)');
  g.addColorStop(1.0, 'rgba(255, 60, 24, 0.0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);

  ctx.strokeStyle = 'rgba(255, 220, 140, 0.85)';
  ctx.lineWidth = 2.0;
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(half + Math.cos(a) * 46, half + Math.sin(a) * 46);
    ctx.lineTo(half + Math.cos(a) * 57, half + Math.sin(a) * 57);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createSlashStreakTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 128;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  const half = size / 2;
  const g = ctx.createRadialGradient(half, half, 2, half, half, half);
  g.addColorStop(0.0, 'rgba(255, 255, 255, 1.0)');
  g.addColorStop(0.28, 'rgba(255, 232, 170, 0.82)');
  g.addColorStop(0.65, 'rgba(255, 145, 60, 0.25)');
  g.addColorStop(1.0, 'rgba(255, 90, 20, 0.0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);

  ctx.save();
  ctx.translate(half, half);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.98)';
  ctx.beginPath();
  ctx.ellipse(0, 0, half * 0.96, 6.5, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createCraterRingTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 128;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  const half = size / 2;
  const g = ctx.createRadialGradient(half, half, 4, half, half, half);
  g.addColorStop(0.0, 'rgba(12, 8, 12, 0.85)');
  g.addColorStop(0.42, 'rgba(255, 110, 35, 0.65)');
  g.addColorStop(0.68, 'rgba(18, 10, 14, 0.45)');
  g.addColorStop(1.0, 'rgba(0, 0, 0, 0.0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);

  ctx.strokeStyle = 'rgba(255, 180, 90, 0.85)';
  ctx.lineWidth = 2.2;
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2 + 0.15;
    ctx.beginPath();
    ctx.moveTo(half + Math.cos(a) * 10, half + Math.sin(a) * 10);
    ctx.lineTo(half + Math.cos(a + 0.12) * 32, half + Math.sin(a + 0.12) * 32);
    ctx.lineTo(half + Math.cos(a - 0.08) * 52, half + Math.sin(a - 0.08) * 52);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createSegmentedDangerTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 128;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  const half = size / 2;
  ctx.clearRect(0, 0, size, size);

  const g = ctx.createRadialGradient(half, half, 36, half, half, half);
  g.addColorStop(0.0, 'rgba(255, 110, 36, 0.0)');
  g.addColorStop(0.7, 'rgba(255, 120, 40, 0.25)');
  g.addColorStop(0.88, 'rgba(255, 220, 140, 0.85)');
  g.addColorStop(1.0, 'rgba(255, 90, 24, 0.0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);

  // Segmented outer warning arcs (16 segments around circumference)
  ctx.strokeStyle = 'rgba(255, 240, 190, 0.95)';
  ctx.lineWidth = 3.2;
  for (let i = 0; i < 16; i++) {
    const start = (i / 16) * Math.PI * 2 + 0.04;
    const end = ((i + 0.62) / 16) * Math.PI * 2;
    ctx.beginPath();
    ctx.arc(half, half, 55, start, end);
    ctx.stroke();
  }

  // Inner calibrated tick notches
  ctx.strokeStyle = 'rgba(255, 185, 95, 0.8)';
  ctx.lineWidth = 1.8;
  for (let i = 0; i < 24; i++) {
    const a = (i / 24) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(half + Math.cos(a) * 44, half + Math.sin(a) * 44);
    ctx.lineTo(half + Math.cos(a) * 51, half + Math.sin(a) * 51);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createLaneProjectionTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 128;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  ctx.clearRect(0, 0, size, size);
  if (typeof ctx.createLinearGradient === 'function') {
    const gx = ctx.createLinearGradient(0, 0, size, 0);
    gx.addColorStop(0.0, 'rgba(255, 70, 24, 0.0)');
    gx.addColorStop(0.14, 'rgba(255, 110, 42, 0.78)');
    gx.addColorStop(0.5, 'rgba(255, 190, 95, 0.92)');
    gx.addColorStop(0.86, 'rgba(255, 110, 42, 0.78)');
    gx.addColorStop(1.0, 'rgba(255, 70, 24, 0.0)');
    ctx.fillStyle = gx;
    ctx.fillRect(0, 0, size, size);
  } else {
    ctx.fillStyle = 'rgba(255, 130, 50, 0.7)';
    ctx.fillRect(12, 0, size - 24, size);
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createShockwaveRingTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 128;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  const half = size / 2;
  ctx.clearRect(0, 0, size, size);
  const g = ctx.createRadialGradient(half, half, 24, half, half, half);
  g.addColorStop(0.0, 'rgba(255, 255, 255, 0.0)');
  g.addColorStop(0.45, 'rgba(255, 140, 55, 0.24)');
  g.addColorStop(0.76, 'rgba(255, 210, 120, 0.85)');
  g.addColorStop(0.92, 'rgba(255, 255, 240, 0.98)');
  g.addColorStop(1.0, 'rgba(255, 120, 40, 0.0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createTrailTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 64;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  ctx.clearRect(0, 0, size, size);
  if (typeof ctx.createLinearGradient === 'function') {
    // v=0 (hilt/base) -> v=1 (razor tip) soft transverse feather + hot blade edge
    const gy = ctx.createLinearGradient(0, 0, 0, size);
    gy.addColorStop(0.0, 'rgba(255, 255, 255, 0.08)');
    gy.addColorStop(0.45, 'rgba(255, 255, 255, 0.52)');
    gy.addColorStop(0.86, 'rgba(255, 255, 255, 1.0)');
    gy.addColorStop(1.0, 'rgba(255, 255, 255, 0.0)');
    ctx.fillStyle = gy;
    ctx.fillRect(0, 0, size, size);
  } else {
    ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
    ctx.fillRect(0, 8, size, size - 16);
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

let sharedTrailTex = null;
let sharedTrailTexRefs = 0;

function acquireTrailTexture() {
  if (!sharedTrailTex) {
    sharedTrailTex = createTrailTexture();
  }
  if (sharedTrailTex) {
    sharedTrailTexRefs++;
  }
  return sharedTrailTex;
}

function releaseTrailTexture() {
  if (sharedTrailTexRefs > 0) {
    sharedTrailTexRefs--;
    if (sharedTrailTexRefs === 0 && sharedTrailTex) {
      sharedTrailTex.dispose?.();
      sharedTrailTex = null;
    }
  }
}

export class VFXManager {
  constructor(scene, camera) {
    this.scene = scene;
    this.camera = camera;
    this.floatingLayer = document.getElementById('floating-text-layer');
    this.qualityScale = 1.0; // 0.45 LOW, 1.0 MED, 1.4 HIGH
    this.adaptiveScale = 1.0; // 0.5..1.0 dynamic GPU load scale
    this.glowTex = createRadialGlowTexture();
    this.starTex = createStarFlashTexture();
    this.craterTex = createCraterRingTexture();
    this.dangerTex = createDangerRingTexture();
    this.streakTex = createSlashStreakTexture();
    this.segDangerTex = createSegmentedDangerTexture();
    this.laneProjTex = createLaneProjectionTexture();
    this.shockwaveTex = createShockwaveRingTexture();
    this._tmpColor = new THREE.Color();

    this._initParticlePool();
    this._initSmokePool();
    this._initSlashArcPool();
    this._initHitFlashPool();
    this._initDirectionalFlashPool();
    this._initGroundCraterPool();
    this._initShieldWardPool();
    this._initMagicBurstPool();
    this._initShockwavePool();
    this._initTelegraphs();
    this._initEruptionPillars();
    this._initPhase2ColumnPool();

    this.tmpProj = new THREE.Vector3();
    this.floatingPool = [];
    if (this.floatingLayer) {
      for (let i = 0; i < 20; i++) {
        const el = document.createElement('div');
        el.className = 'float-dmg hidden';
        this.floatingLayer.appendChild(el);
        this.floatingPool.push({ el, active: false, life: 0, maxLife: 0.85, worldPos: new THREE.Vector3(), vy: 1.5 });
      }
    }
  }

  setQualityTier(tier) {
    this.qualityScale = tier === 'LOW' ? 0.45 : tier === 'HIGH' ? 1.4 : 1.0;
  }

  setAdaptiveScale(scale) {
    this.adaptiveScale = Math.max(0.35, Math.min(1.0, Number(scale) || 1.0));
  }

  _getEffectiveDensity() {
    return this.qualityScale * this.adaptiveScale;
  }

  _acquireSlot(pool, fallbackFirst = true) {
    for (let i = 0; i < pool.length; i++) {
      if (!pool[i].active) return pool[i];
    }
    return fallbackFirst && pool.length > 0 ? pool[0] : null;
  }

  _initParticlePool() {
    this.maxParticles = 540;
    this.pPositions = new Float32Array(this.maxParticles * 3);
    this.pColors = new Float32Array(this.maxParticles * 3);
    this.pVel = new Float32Array(this.maxParticles * 3);
    this.pLife = new Float32Array(this.maxParticles);
    this.pGravity = new Float32Array(this.maxParticles);
    this.pCursor = 0;

    for (let i = 0; i < this.maxParticles; i++) {
      this.pPositions[i * 3 + 1] = -999;
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(this.pPositions, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(this.pColors, 3));

    const mat = new THREE.PointsMaterial({
      size: 0.3,
      map: this.glowTex,
      vertexColors: true,
      transparent: true,
      opacity: 0.96,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    this.particleSystem = new THREE.Points(geo, mat);
    this.particleSystem.frustumCulled = false;
    this.scene.add(this.particleSystem);
  }

  _initSmokePool() {
    this.smokes = [];
    const geo = new THREE.SphereGeometry(0.42, 7, 6);
    for (let i = 0; i < 24; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0x3b323d,
        transparent: true,
        opacity: 0,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.smokes.push({ mesh, mat, active: false, life: 0, maxLife: 0.65, vx: 0, vy: 1.2, vz: 0, startScale: 0.55 });
    }
  }

  spawnSmoke(pos, count = 4, colorHex = 0x3d333d, startScale = 0.6) {
    const scaled = Math.max(1, Math.round(count * this._getEffectiveDensity()));
    for (let i = 0; i < scaled; i++) {
      const s = this._acquireSlot(this.smokes, false);
      if (!s) break;
      s.active = true;
      s.life = 0;
      s.maxLife = 0.48 + Math.random() * 0.35;
      s.vx = (Math.random() - 0.5) * 2.4;
      s.vy = 0.9 + Math.random() * 1.4;
      s.vz = (Math.random() - 0.5) * 2.4;
      s.startScale = startScale;
      s.mat.color.setHex(colorHex);
      s.mat.opacity = 0.52;
      s.mesh.position.set(pos.x + (Math.random() - 0.5) * 0.45, (pos.y ?? 0.25) + 0.22, pos.z + (Math.random() - 0.5) * 0.45);
      s.mesh.scale.setScalar(startScale);
      s.mesh.visible = true;
    }
  }

  spawnDust(pos, count = 3) {
    this.spawnSmoke({ x: pos.x, y: 0.08, z: pos.z }, count, 0x5c535e, 0.38);
  }

  _initSlashArcPool() {
    this.slashArcs = [];
    const arcGeo = new THREE.RingGeometry(1.15, 1.9, 22, 1, -Math.PI * 0.5, Math.PI);
    arcGeo.rotateX(-Math.PI / 2);
    for (let i = 0; i < 8; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0x6ce5ff,
        transparent: true,
        opacity: 0,
        side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(arcGeo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.slashArcs.push({
        mesh,
        mat,
        active: false,
        life: 0,
        maxLife: 0.24,
        baseScale: 1.2,
        spinSpeed: 4.5,
      });
    }
  }

  spawnSlashArc(pos, yaw, tiltZ = 0.25, colorHex = 0x6ce5ff, scale = 1.25) {
    const arc = this._acquireSlot(this.slashArcs, true);
    arc.active = true;
    arc.life = 0;
    arc.maxLife = 0.24;
    arc.baseScale = scale;
    arc.spinSpeed = tiltZ >= 0 ? 5.8 : -5.8;
    arc.mat.color.setHex(colorHex);
    arc.mat.opacity = 0.94;
    arc.mesh.position.set(pos.x, (pos.y || 0) + 1.15, pos.z);
    arc.mesh.rotation.set(0, yaw - Math.PI * 0.5, tiltZ);
    arc.mesh.scale.setScalar(scale * 0.85);
    arc.mesh.visible = true;
  }

  _initHitFlashPool() {
    this.hitFlashes = [];
    for (let i = 0; i < 8; i++) {
      const mat = new THREE.SpriteMaterial({
        map: this.starTex || this.glowTex,
        color: 0xffe082,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const sprite = new THREE.Sprite(mat);
      sprite.visible = false;
      this.scene.add(sprite);
      this.hitFlashes.push({ sprite, mat, active: false, life: 0, maxLife: 0.14, baseScale: 2.2 });
    }
  }

  spawnHitFlash(pos, colorHex = 0xffe082, scale = 2.2) {
    const slot = this._acquireSlot(this.hitFlashes, true);
    slot.active = true;
    slot.life = 0;
    slot.maxLife = 0.14;
    slot.baseScale = scale;
    slot.mat.color.setHex(colorHex);
    slot.mat.opacity = 1.0;
    slot.mat.rotation = Math.random() * Math.PI;
    slot.sprite.position.set(pos.x, pos.y ?? 1.35, pos.z);
    slot.sprite.scale.setScalar(scale * 0.55);
    slot.sprite.visible = true;
  }

  _initDirectionalFlashPool() {
    this.directionalFlashes = [];
    const geo = new THREE.PlaneGeometry(1.8, 0.45);
    for (let i = 0; i < 10; i++) {
      const mat = new THREE.MeshBasicMaterial({
        map: this.streakTex || this.glowTex,
        color: 0xffe699,
        transparent: true,
        opacity: 0,
        side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.directionalFlashes.push({
        mesh,
        mat,
        active: false,
        life: 0,
        maxLife: 0.16,
        baseScale: 2.2,
      });
    }
  }

  spawnDirectionalHitFlash(pos, yaw = 0, tilt = 0.25, colorHex = 0xffe699, scale = 2.4) {
    const slot = this._acquireSlot(this.directionalFlashes, true);
    slot.active = true;
    slot.life = 0;
    slot.maxLife = 0.16;
    slot.baseScale = scale;
    slot.mat.color.setHex(colorHex);
    slot.mat.opacity = 0.98;
    slot.mesh.position.set(pos.x, pos.y ?? 1.35, pos.z);
    slot.mesh.rotation.set(0, yaw, tilt);
    slot.mesh.scale.set(scale * 0.6, scale * 0.45, 1);
    slot.mesh.visible = true;
  }

  _initGroundCraterPool() {
    this.craters = [];
    const geo = new THREE.PlaneGeometry(2.0, 2.0);
    geo.rotateX(-Math.PI / 2);
    for (let i = 0; i < 6; i++) {
      const mat = new THREE.MeshBasicMaterial({
        map: this.craterTex,
        color: 0xff8a30,
        transparent: true,
        opacity: 0,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.visible = false;
      this.scene.add(mesh);
      this.craters.push({ mesh, mat, active: false, life: 0, maxLife: 0.9, radius: 2.0 });
    }
  }

  spawnGroundCrater(pos, radius = 2.2, colorHex = 0xff8a30) {
    if (this._getEffectiveDensity() < 0.45) return;
    const c = this._acquireSlot(this.craters, true);
    c.active = true;
    c.life = 0;
    c.maxLife = 0.9;
    c.radius = radius;
    c.mat.color.setHex(colorHex);
    c.mat.opacity = 0.86;
    c.mesh.position.set(pos.x, 0.04, pos.z);
    c.mesh.rotation.y = Math.random() * Math.PI * 2;
    c.mesh.scale.setScalar(radius);
    c.mesh.visible = true;
  }

  _initShieldWardPool() {
    this.wards = [];
    const wardGeo = new THREE.RingGeometry(0.55, 0.85, 6);
    const coreGeo = new THREE.CircleGeometry(0.58, 6);
    for (let i = 0; i < 4; i++) {
      const group = new THREE.Group();
      const mat = new THREE.MeshBasicMaterial({
        color: 0xffd56b,
        transparent: true,
        opacity: 0,
        side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const ring = new THREE.Mesh(wardGeo, mat);
      const fillMat = mat.clone();
      fillMat.opacity = 0;
      const core = new THREE.Mesh(coreGeo, fillMat);
      group.add(ring);
      group.add(core);
      group.visible = false;
      this.scene.add(group);
      this.wards.push({ group, mat, fillMat, active: false, life: 0, maxLife: 0.36 });
    }
  }

  spawnShieldWard(pos, yaw, colorHex = 0xffe07d) {
    const w = this._acquireSlot(this.wards, true);
    w.active = true;
    w.life = 0;
    w.maxLife = 0.36;
    w.mat.color.setHex(colorHex);
    w.fillMat.color.setHex(colorHex);
    w.mat.opacity = 0.95;
    w.fillMat.opacity = 0.28;
    w.group.position.set(
      pos.x + Math.sin(yaw) * 0.72,
      (pos.y || 0) + 1.15,
      pos.z + Math.cos(yaw) * 0.72
    );
    w.group.rotation.set(0, yaw, 0);
    w.group.scale.setScalar(0.7);
    w.group.visible = true;
  }

  _initMagicBurstPool() {
    this.magicBursts = [];
    const sphereGeo = new THREE.IcosahedronGeometry(1.0, 1);
    for (let i = 0; i < 6; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xff8c2b,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(sphereGeo, mat);
      const spriteMat = new THREE.SpriteMaterial({
        map: this.glowTex,
        color: 0xff8c2b,
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const glowSprite = new THREE.Sprite(spriteMat);
      mesh.add(glowSprite);
      mesh.visible = false;
      this.scene.add(mesh);
      this.magicBursts.push({ mesh, mat, spriteMat, active: false, life: 0, maxLife: 0.42, maxScale: 4.5 });
    }
  }

  spawnMagicBurst(pos, colorHex = 0xff7b29, maxScale = 4.6) {
    const b = this._acquireSlot(this.magicBursts, true);
    b.active = true;
    b.life = 0;
    b.maxLife = 0.42;
    b.maxScale = maxScale;
    b.mat.color.setHex(colorHex);
    b.mat.opacity = 0.85;
    b.spriteMat.color.setHex(colorHex);
    b.spriteMat.opacity = 0.9;
    b.mesh.position.set(pos.x, (pos.y || 0) + 1.0, pos.z);
    b.mesh.scale.setScalar(0.35);
    b.mesh.visible = true;

    this.spawnSparks({ x: pos.x, y: 1.0, z: pos.z }, 28, colorHex, 10.5, 6);
    this.spawnShockwave(pos, maxScale * 1.4, 15, colorHex, false, 0);
    this.spawnSmoke(pos, 4, 0x452d36);
  }

  spawnSkillWhirlwind(pos, yaw, colorHex = 0xff7b29) {
    // Signature Whirlwind Cleave: dual crossing slash arcs + arcane core burst + crater + vortex embers
    this.spawnMagicBurst(pos, colorHex, 5.2);
    this.spawnSlashArc(pos, yaw, 0.14, colorHex, 1.9);
    this.spawnSlashArc(pos, yaw + Math.PI, -0.18, 0xffd266, 2.05);
    this.spawnShockwave(pos, 6.2, 18.0, 0xffd266, false, 0);
    this.spawnGroundCrater(pos, 2.6, colorHex);
    this.spawnHitFlash({ x: pos.x, y: 1.25, z: pos.z }, 0xffb347, 3.2);
  }

  spawnPhase2ArenaPulse(pos) {
    this.spawnMagicBurst(pos, 0xff8c2b, 6.6);
    this.spawnShockwave(pos, 18.5, 14.5, 0xffaa33, false, 0);
    this.spawnShockwave(pos, 14.0, 12.0, 0xff4418, false, 0);
    this.spawnShockwave(pos, 9.5, 9.2, 0xffdf8a, false, 0);
    this.spawnGroundCrater(pos, 4.4, 0xff5a18);
    this.spawnHitFlash({ x: pos.x, y: 2.2, z: pos.z }, 0xffbe55, 4.6);
    this._spawnPhase2Column(pos, 0, 1.0);
    this._spawnPhase2Column(pos, Math.PI * 0.25, 1.18);
  }

  spawnParryBurst(pos, yaw = 0) {
    this.spawnPerfectParryBurst(pos, yaw);
  }

  spawnPerfectParryBurst(pos, yaw = 0) {
    this.spawnShieldWard(pos, yaw, 0xb8f3ff);
    this.spawnDirectionalHitFlash({ x: pos.x, y: (pos.y ?? 0) + 1.45, z: pos.z }, yaw, 0.38, 0xe8fbff, 3.3);
    this.spawnDirectionalHitFlash({ x: pos.x, y: (pos.y ?? 0) + 1.45, z: pos.z }, yaw, -0.46, 0x70dcff, 2.9);
    this.spawnHitFlash({ x: pos.x, y: (pos.y ?? 0) + 1.45, z: pos.z }, 0xd8f8ff, 4.1);
    this.spawnShockwave(pos, 7.6, 18.5, 0x8be9ff, false, 0);
    this.spawnSparks({ x: pos.x, y: (pos.y ?? 0) + 1.4, z: pos.z }, 28, 0x99ecff, 11.8, 10);
    this.spawnDirectionalSparks({ x: pos.x, y: (pos.y ?? 0) + 1.4, z: pos.z }, yaw, 16, 0xffffff, 11.0, 9);
  }

  spawnBlockBurst(pos, yaw = 0) {
    this.spawnShieldWard(pos, yaw, 0x9ab8d9);
    this.spawnHitFlash({ x: pos.x, y: (pos.y ?? 0) + 1.35, z: pos.z }, 0xc2d8ee, 2.3);
    this.spawnShockwave(pos, 3.6, 13.0, 0x8cb4db, false, 0);
    this.spawnDirectionalSparks({ x: pos.x, y: (pos.y ?? 0) + 1.3, z: pos.z }, yaw, 10, 0xd9ecff, 8.0, 12);
  }

  spawnPerfectDodgeTrail(pos, yaw = 0) {
    this.spawnHitFlash({ x: pos.x, y: (pos.y ?? 0) + 1.05, z: pos.z }, 0x84ecff, 2.5);
    this.spawnDirectionalHitFlash({ x: pos.x, y: (pos.y ?? 0) + 1.05, z: pos.z }, yaw, 0.08, 0x72e2ff, 2.8);
    this.spawnDirectionalSparks({ x: pos.x, y: (pos.y ?? 0) + 1.0, z: pos.z }, yaw + Math.PI, 16, 0x84ecff, 7.2, 6);
  }

  spawnComboFinisherBurst(pos, yaw = 0, isHeavyFinisher = false) {
    const primary = isHeavyFinisher ? 0xffb84d : 0xffd266;
    const secondary = isHeavyFinisher ? 0xff5e2b : 0xffffff;
    this.spawnDirectionalHitFlash(pos, yaw, 0.28, primary, isHeavyFinisher ? 3.2 : 2.7);
    this.spawnDirectionalHitFlash(pos, yaw, -0.36, secondary, isHeavyFinisher ? 2.8 : 2.3);
    this.spawnHitFlash(pos, primary, isHeavyFinisher ? 3.2 : 2.7);
    this.spawnShockwave({ x: pos.x, y: 0, z: pos.z }, isHeavyFinisher ? 4.8 : 3.8, 15.0, primary, false, 0);
    this.spawnDirectionalSparks(pos, yaw, isHeavyFinisher ? 20 : 14, primary, 11.2, 13);
  }

  spawnCriticalStrikeBurst(pos, yaw = 0) {
    this.spawnCritImpact(pos, yaw, true);
    this.spawnShockwave({ x: pos.x, y: 0, z: pos.z }, 8.6, 18.0, 0xffc857, false, 0);
    this.spawnGroundCrater({ x: pos.x, z: pos.z }, 3.1, 0xff7b29);
    this.spawnSparks(pos, 32, 0xffe082, 12.2, 12);
    this.spawnDirectionalSparks(pos, yaw, 20, 0xffffff, 13.0, 11);
  }

  spawnCritImpact(pos, yaw = 0, isSkill = false) {
    const primaryHex = isSkill ? 0xff9233 : 0xfff099;
    const secondaryHex = isSkill ? 0xffe082 : 0xffffff;
    this.spawnDirectionalHitFlash(pos, yaw, 0.32, primaryHex, isSkill ? 3.2 : 2.8);
    this.spawnDirectionalHitFlash(pos, yaw, -0.32, secondaryHex, isSkill ? 2.8 : 2.4);
    this.spawnHitFlash(pos, primaryHex, isSkill ? 3.4 : 2.9);
    this.spawnDirectionalSparks(pos, yaw, 14, secondaryHex, 11.0, 12);
  }

  spawnSparks(pos, count = 18, hexColor = 0xffaa44, speed = 7.5, gravity = 14) {
    const scaled = Math.max(1, Math.round(count * this._getEffectiveDensity()));
    this._tmpColor.setHex(hexColor);
    const r = this._tmpColor.r;
    const g = this._tmpColor.g;
    const b = this._tmpColor.b;
    for (let i = 0; i < scaled; i++) {
      const idx = this.pCursor;
      this.pCursor = (this.pCursor + 1) % this.maxParticles;

      const theta = Math.random() * Math.PI * 2;
      const up = 0.2 + Math.random() * 0.95;
      const spd = speed * (0.45 + Math.random() * 0.85);

      this.pPositions[idx * 3] = pos.x + (Math.random() - 0.5) * 0.35;
      this.pPositions[idx * 3 + 1] = (pos.y ?? 1.0) + (Math.random() - 0.5) * 0.35;
      this.pPositions[idx * 3 + 2] = pos.z + (Math.random() - 0.5) * 0.35;

      this.pVel[idx * 3] = Math.cos(theta) * spd;
      this.pVel[idx * 3 + 1] = up * spd;
      this.pVel[idx * 3 + 2] = Math.sin(theta) * spd;

      // ~30% hot white-gold core sparks for brighter impact pop
      const hotCore = i % 3 === 0;
      this.pColors[idx * 3] = hotCore ? THREE.MathUtils.lerp(r, 1.0, 0.72) : r;
      this.pColors[idx * 3 + 1] = hotCore ? THREE.MathUtils.lerp(g, 0.96, 0.72) : g;
      this.pColors[idx * 3 + 2] = hotCore ? THREE.MathUtils.lerp(b, 0.84, 0.72) : b;

      this.pLife[idx] = 0.28 + Math.random() * 0.42;
      this.pGravity[idx] = gravity;
    }
  }

  spawnDirectionalSparks(pos, dirYaw, count = 14, hexColor = 0xffe075, speed = 9.0, gravity = 13) {
    const scaled = Math.max(1, Math.round(count * this._getEffectiveDensity()));
    this._tmpColor.setHex(hexColor);
    const r = this._tmpColor.r;
    const g = this._tmpColor.g;
    const b = this._tmpColor.b;
    for (let i = 0; i < scaled; i++) {
      const idx = this.pCursor;
      this.pCursor = (this.pCursor + 1) % this.maxParticles;

      const spread = (Math.random() - 0.5) * 1.15;
      const ang = dirYaw + spread;
      const spd = speed * (0.6 + Math.random() * 0.7);

      this.pPositions[idx * 3] = pos.x + (Math.random() - 0.5) * 0.25;
      this.pPositions[idx * 3 + 1] = (pos.y ?? 1.25) + (Math.random() - 0.5) * 0.28;
      this.pPositions[idx * 3 + 2] = pos.z + (Math.random() - 0.5) * 0.25;

      this.pVel[idx * 3] = Math.sin(ang) * spd;
      this.pVel[idx * 3 + 1] = (0.15 + Math.random() * 0.65) * spd;
      this.pVel[idx * 3 + 2] = Math.cos(ang) * spd;

      const hotCore = i % 3 === 0;
      this.pColors[idx * 3] = hotCore ? THREE.MathUtils.lerp(r, 1.0, 0.72) : r;
      this.pColors[idx * 3 + 1] = hotCore ? THREE.MathUtils.lerp(g, 0.96, 0.72) : g;
      this.pColors[idx * 3 + 2] = hotCore ? THREE.MathUtils.lerp(b, 0.84, 0.72) : b;

      this.pLife[idx] = 0.22 + Math.random() * 0.32;
      this.pGravity[idx] = gravity;
    }
  }

  _initShockwavePool() {
    this.shockwaves = [];
    const ringGeo = new THREE.RingGeometry(0.76, 1.0, 48);
    ringGeo.rotateX(-Math.PI / 2);
    const innerGeo = new THREE.RingGeometry(0.54, 0.82, 48);
    innerGeo.rotateX(-Math.PI / 2);

    for (let i = 0; i < 8; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xff5a20,
        transparent: true,
        opacity: 0,
        side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(ringGeo, mat);

      const innerMat = new THREE.MeshBasicMaterial({
        map: this.shockwaveTex || null,
        color: 0xffb866,
        transparent: true,
        opacity: 0,
        side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const innerMesh = new THREE.Mesh(innerGeo, innerMat);
      innerMesh.position.y = 0.015;
      mesh.add(innerMesh);

      mesh.visible = false;
      this.scene.add(mesh);
      this.shockwaves.push({
        mesh,
        mat,
        innerMat,
        active: false,
        radius: 0.5,
        maxRadius: 12,
        speed: 10,
        damage: 0,
        hitPlayer: false,
        isHostile: true,
      });
    }
  }

  spawnShockwave(pos, maxRadius = 13, speed = 11, color = 0xff5a20, isHostile = true, damage = 210) {
    const sw = this._acquireSlot(this.shockwaves, true);
    sw.active = true;
    sw.radius = 0.85;
    sw.maxRadius = maxRadius;
    sw.speed = speed;
    sw.damage = damage;
    sw.hitPlayer = false;
    sw.isHostile = isHostile;
    sw.mat.color.setHex(color);
    sw.mat.opacity = 0.92;
    sw.innerMat.color.setHex(color);
    sw.innerMat.opacity = 0.68;
    sw.mesh.position.set(pos.x, 0.08, pos.z);
    sw.mesh.scale.setScalar(sw.radius);
    sw.mesh.visible = true;
    return sw;
  }

  _initTelegraphs() {
    this.circleTelegraph = new THREE.Group();
    const outerGeo = new THREE.RingGeometry(0.18, 1.0, 44);
    outerGeo.rotateX(-Math.PI / 2);
    this.circleTelegraphMat = new THREE.MeshBasicMaterial({
      map: this.dangerTex || null,
      color: 0xff3b1f,
      transparent: true,
      opacity: 0.0,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.circleOuterRing = new THREE.Mesh(outerGeo, this.circleTelegraphMat);

    const midGeo = new THREE.RingGeometry(0.76, 1.02, 44);
    midGeo.rotateX(-Math.PI / 2);
    this.circleMidMat = new THREE.MeshBasicMaterial({
      map: this.segDangerTex || this.dangerTex || null,
      color: 0xffc66e,
      transparent: true,
      opacity: 0.0,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.circleMidRing = new THREE.Mesh(midGeo, this.circleMidMat);
    this.circleMidRing.position.y = 0.008;

    const innerGeo = new THREE.CircleGeometry(1.0, 40);
    innerGeo.rotateX(-Math.PI / 2);
    this.circleFillMat = new THREE.MeshBasicMaterial({
      color: 0xff7a2e,
      transparent: true,
      opacity: 0.0,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.circleFillMesh = new THREE.Mesh(innerGeo, this.circleFillMat);
    this.circleFillMesh.position.y = 0.004;

    this.circleTelegraph.add(this.circleOuterRing);
    this.circleTelegraph.add(this.circleMidRing);
    this.circleTelegraph.add(this.circleFillMesh);
    this.circleTelegraph.position.y = 0.05;
    this.circleTelegraph.visible = false;
    this.scene.add(this.circleTelegraph);

    this.laneTelegraph = new THREE.Group();
    const laneGeo = new THREE.PlaneGeometry(2.4, 1.0);
    laneGeo.rotateX(-Math.PI / 2);
    laneGeo.translate(0, 0, 0.5);
    this.laneTelegraphMat = new THREE.MeshBasicMaterial({
      map: this.laneProjTex || null,
      color: 0xff4422,
      transparent: true,
      opacity: 0,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const laneBody = new THREE.Mesh(laneGeo, this.laneTelegraphMat);
    this.laneTelegraph.add(laneBody);

    const railGeo = new THREE.PlaneGeometry(0.18, 1.0);
    railGeo.rotateX(-Math.PI / 2);
    railGeo.translate(0, 0.004, 0.5);
    this.laneRailMat = new THREE.MeshBasicMaterial({
      map: this.laneProjTex || null,
      color: 0xffc65e,
      transparent: true,
      opacity: 0,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const leftRail = new THREE.Mesh(railGeo, this.laneRailMat);
    leftRail.position.x = -1.16;
    const rightRail = new THREE.Mesh(railGeo, this.laneRailMat);
    rightRail.position.x = 1.16;
    this.laneTelegraph.add(leftRail);
    this.laneTelegraph.add(rightRail);

    const chargeGeo = new THREE.PlaneGeometry(2.2, 1.0);
    chargeGeo.rotateX(-Math.PI / 2);
    chargeGeo.translate(0, 0.003, 0.5);
    this.laneChargeMesh = new THREE.Mesh(chargeGeo, this.laneRailMat);
    this.laneTelegraph.add(this.laneChargeMesh);

    this.laneTelegraph.position.y = 0.06;
    this.laneTelegraph.visible = false;
    this.scene.add(this.laneTelegraph);
  }

  showCircleTelegraph(x, z, radius, progress = 0.5, color = 0xff3b1f) {
    const p = Math.max(0, Math.min(1, progress));
    this.circleTelegraph.visible = true;
    this.circleTelegraph.position.set(x, 0.055, z);
    this.circleTelegraph.scale.setScalar(radius);
    this.circleTelegraphMat.color.setHex(color);
    this.circleTelegraphMat.opacity = 0.28 + p * 0.54;
    this.circleOuterRing.rotation.y = p * Math.PI * 0.85;
    this.circleMidMat.color.setHex(p > 0.72 ? 0xffe082 : color);
    this.circleMidMat.opacity = Math.min(0.98, 0.36 + p * 0.56 + Math.sin(p * Math.PI * 6) * 0.1);
    this.circleMidRing.rotation.y = -p * Math.PI * 1.4;
    this.circleFillMat.color.setHex(color);
    this.circleFillMat.opacity = 0.14 + p * 0.32;
    this.circleFillMesh.scale.setScalar(0.12 + p * 0.88);
  }

  showDashTelegraph(originX, originZ, angleY, length, progress = 0.5) {
    const p = Math.max(0, Math.min(1, progress));
    this.laneTelegraph.visible = true;
    this.laneTelegraph.position.set(originX, 0.06, originZ);
    this.laneTelegraph.rotation.y = angleY;
    this.laneTelegraph.scale.set(1, 1, length);
    this.laneTelegraphMat.opacity = 0.24 + p * 0.38;
    this.laneRailMat.opacity = Math.min(0.98, 0.4 + p * 0.54 + Math.sin(p * Math.PI * 6) * 0.08);
    this.laneChargeMesh.scale.set(1, 1, Math.max(0.08, p));
  }

  hideTelegraphs() {
    this.circleTelegraph.visible = false;
    this.laneTelegraph.visible = false;
  }

  _initEruptionPillars() {
    this.pillars = [];
    const ringGeo = new THREE.RingGeometry(0.2, 1.85, 24);
    ringGeo.rotateX(-Math.PI / 2);
    const colGeo = new THREE.CylinderGeometry(1.1, 1.55, 7.5, 12);
    colGeo.translate(0, 3.75, 0);

    for (let i = 0; i < 6; i++) {
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0xff4818,
        transparent: true,
        opacity: 0.7,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.visible = false;
      this.scene.add(ring);

      const colMat = new THREE.MeshBasicMaterial({
        color: 0xff8a30,
        transparent: true,
        opacity: 0.85,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const col = new THREE.Mesh(colGeo, colMat);
      col.visible = false;
      this.scene.add(col);

      this.pillars.push({
        ring,
        ringMat,
        col,
        colMat,
        active: false,
        x: 0,
        z: 0,
        timer: 0,
        fuse: 0.75,
        detonated: false,
        hitPlayer: false,
      });
    }
  }

  spawnEruptionPillar(x, z, fuse = 0.78) {
    const p = this._acquireSlot(this.pillars, false);
    if (!p) return;
    p.active = true;
    p.x = x;
    p.z = z;
    p.timer = 0;
    p.fuse = fuse;
    p.detonated = false;
    p.hitPlayer = false;
    p.ring.position.set(x, 0.06, z);
    p.ring.scale.setScalar(0.3);
    p.ring.visible = true;
    p.ringMat.opacity = 0.75;
    p.col.position.set(x, 0, z);
    p.col.visible = false;
  }

  _initPhase2ColumnPool() {
    this.phase2Columns = [];
    const outerGeo = new THREE.CylinderGeometry(1.35, 2.35, 16, 14, 1, true);
    outerGeo.translate(0, 8, 0);
    const innerGeo = new THREE.CylinderGeometry(0.55, 1.05, 16, 12, 1, true);
    innerGeo.translate(0, 8, 0);
    for (let i = 0; i < 2; i++) {
      const group = new THREE.Group();
      const outerMat = new THREE.MeshBasicMaterial({
        color: 0xff7824,
        transparent: true,
        opacity: 0,
        side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const innerMat = new THREE.MeshBasicMaterial({
        color: 0xffe49c,
        transparent: true,
        opacity: 0,
        side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      group.add(new THREE.Mesh(outerGeo, outerMat));
      group.add(new THREE.Mesh(innerGeo, innerMat));
      group.visible = false;
      this.scene.add(group);
      this.phase2Columns.push({ group, outerMat, innerMat, active: false, life: 0, maxLife: 0.78, spinDir: i % 2 === 0 ? 1 : -1 });
    }
  }

  _spawnPhase2Column(pos, yawOffset = 0, scaleMult = 1.0) {
    const slot = this._acquireSlot(this.phase2Columns, true);
    slot.active = true;
    slot.life = 0;
    slot.scaleMult = scaleMult;
    slot.outerMat.opacity = 0.72;
    slot.innerMat.opacity = 0.92;
    slot.group.position.set(pos.x, 0.05, pos.z);
    slot.group.rotation.y = yawOffset;
    slot.group.scale.set(0.5 * scaleMult, 0.25, 0.5 * scaleMult);
    slot.group.visible = true;
  }

  spawnFloatingText(worldPos, text, styleClass = 'normal') {
    if (this.floatingPool.length === 0) return;
    const slot = this._acquireSlot(this.floatingPool, true);
    slot.active = true;
    slot.life = 0;
    slot.maxLife = styleClass === 'parry' || styleClass === 'realm' ? 1.05 : 0.78;
    slot.worldPos.copy(worldPos);
    slot.worldPos.x += (Math.random() - 0.5) * 0.5;
    slot.worldPos.y += 1.75;
    slot.vy = styleClass === 'crit' ? 2.1 : 1.5;
    slot.el.textContent = text;
    slot.el.className = `float-dmg ${styleClass}`;
    slot.el.style.opacity = '1';
  }

  clearAll() {
    for (let i = 0; i < this.maxParticles; i++) {
      this.pLife[i] = 0;
      this.pPositions[i * 3 + 1] = -999;
    }
    this.pCursor = 0;
    const posAttr = this.particleSystem?.geometry?.getAttribute?.('position');
    if (posAttr) posAttr.needsUpdate = true;

    for (const sw of this.shockwaves) {
      sw.active = false;
      sw.mesh.visible = false;
    }
    for (const p of this.pillars) {
      p.active = false;
      p.ring.visible = false;
      p.col.visible = false;
    }
    for (const s of this.smokes) {
      s.active = false;
      s.mesh.visible = false;
    }
    for (const a of this.slashArcs) {
      a.active = false;
      a.mesh.visible = false;
    }
    for (const h of this.hitFlashes) {
      h.active = false;
      h.sprite.visible = false;
    }
    for (const d of this.directionalFlashes) {
      d.active = false;
      d.mesh.visible = false;
    }
    for (const c of this.craters) {
      c.active = false;
      c.mesh.visible = false;
    }
    for (const w of this.wards) {
      w.active = false;
      w.group.visible = false;
    }
    for (const b of this.magicBursts) {
      b.active = false;
      b.mesh.visible = false;
    }
    for (const col of this.phase2Columns) {
      col.active = false;
      col.group.visible = false;
    }
    for (const f of this.floatingPool) {
      f.active = false;
      f.el.className = 'float-dmg hidden';
    }
    this.hideTelegraphs();
  }

  dispose() {
    this.clearAll();
    if (this.particleSystem) {
      this.scene.remove(this.particleSystem);
      this.particleSystem.geometry.dispose();
      this.particleSystem.material.dispose();
    }
    const disposeList = (items, getGeo, getMats) => {
      const disposedGeos = new Set();
      for (const item of items) {
        const mesh = getGeo(item);
        if (mesh) {
          this.scene.remove(mesh);
          mesh.traverse((n) => {
            if (n.geometry && !disposedGeos.has(n.geometry)) {
              disposedGeos.add(n.geometry);
              n.geometry.dispose();
            }
          });
        }
        for (const m of getMats(item)) {
          m?.dispose?.();
        }
      }
    };
    disposeList(this.smokes, (i) => i.mesh, (i) => [i.mat]);
    disposeList(this.slashArcs, (i) => i.mesh, (i) => [i.mat]);
    disposeList(this.hitFlashes, (i) => i.sprite, (i) => [i.mat]);
    disposeList(this.directionalFlashes, (i) => i.mesh, (i) => [i.mat]);
    disposeList(this.craters, (i) => i.mesh, (i) => [i.mat]);
    disposeList(this.wards, (i) => i.group, (i) => [i.mat, i.fillMat]);
    disposeList(this.magicBursts, (i) => i.mesh, (i) => [i.mat, i.spriteMat]);
    disposeList(this.phase2Columns, (i) => i.group, (i) => [i.outerMat, i.innerMat]);
    disposeList(this.shockwaves, (i) => i.mesh, (i) => [i.mat, i.innerMat]);
    disposeList(this.pillars, (i) => i.ring, (i) => [i.ringMat]);
    disposeList(this.pillars, (i) => i.col, (i) => [i.colMat]);

    const disposeGroup = (grp) => {
      if (!grp) return;
      this.scene.remove(grp);
      const dGeos = new Set();
      const dMats = new Set();
      grp.traverse((n) => {
        if (n.geometry && !dGeos.has(n.geometry)) {
          dGeos.add(n.geometry);
          n.geometry.dispose();
        }
        if (n.material && !dMats.has(n.material)) {
          dMats.add(n.material);
          n.material.dispose();
        }
      });
    };
    disposeGroup(this.circleTelegraph);
    disposeGroup(this.laneTelegraph);
    for (const f of this.floatingPool) {
      f.el.remove?.();
    }
    this.floatingPool = [];
    this.glowTex?.dispose?.();
    this.starTex?.dispose?.();
    this.craterTex?.dispose?.();
    this.dangerTex?.dispose?.();
    this.streakTex?.dispose?.();
    this.segDangerTex?.dispose?.();
    this.laneProjTex?.dispose?.();
    this.shockwaveTex?.dispose?.();
  }

  update(dt, onShockwaveHitPlayer, onPillarHitPlayer) {
    const posAttr = this.particleSystem.geometry.getAttribute('position');
    let anyParticle = false;
    for (let i = 0; i < this.maxParticles; i++) {
      if (this.pLife[i] <= 0) continue;
      anyParticle = true;
      this.pLife[i] -= dt;
      if (this.pLife[i] <= 0) {
        this.pPositions[i * 3 + 1] = -999;
        continue;
      }
      this.pVel[i * 3 + 1] -= this.pGravity[i] * dt;
      this.pPositions[i * 3] += this.pVel[i * 3] * dt;
      this.pPositions[i * 3 + 1] += this.pVel[i * 3 + 1] * dt;
      this.pPositions[i * 3 + 2] += this.pVel[i * 3 + 2] * dt;
      if (this.pPositions[i * 3 + 1] < 0.04) {
        this.pPositions[i * 3 + 1] = 0.04;
        this.pVel[i * 3 + 1] *= -0.35;
      }
    }
    if (anyParticle) posAttr.needsUpdate = true;

    for (const s of this.smokes) {
      if (!s.active) continue;
      s.life += dt;
      const t = s.life / s.maxLife;
      if (t >= 1) {
        s.active = false;
        s.mesh.visible = false;
        continue;
      }
      s.mesh.position.x += s.vx * dt;
      s.mesh.position.y += s.vy * dt;
      s.mesh.position.z += s.vz * dt;
      s.mesh.scale.setScalar(s.startScale + t * 1.85);
      s.mat.opacity = 0.52 * (1 - t);
    }

    for (const a of this.slashArcs) {
      if (!a.active) continue;
      a.life += dt;
      const t = a.life / a.maxLife;
      if (t >= 1) {
        a.active = false;
        a.mesh.visible = false;
        continue;
      }
      a.mesh.rotation.y += a.spinSpeed * dt;
      a.mesh.scale.setScalar(a.baseScale * (0.85 + t * 0.58));
      a.mat.opacity = 0.94 * (1 - t * t);
    }

    for (const h of this.hitFlashes) {
      if (!h.active) continue;
      h.life += dt;
      const t = h.life / h.maxLife;
      if (t >= 1) {
        h.active = false;
        h.sprite.visible = false;
        continue;
      }
      const expand = t < 0.3 ? 0.55 + (t / 0.3) * 0.65 : 1.2 - (t - 0.3) * 0.5;
      h.sprite.scale.setScalar(h.baseScale * expand);
      h.mat.opacity = 1.0 - t * t;
    }

    for (const d of this.directionalFlashes) {
      if (!d.active) continue;
      d.life += dt;
      const t = d.life / d.maxLife;
      if (t >= 1) {
        d.active = false;
        d.mesh.visible = false;
        continue;
      }
      d.mesh.scale.set(d.baseScale * (0.65 + t * 1.15), d.baseScale * (0.45 - t * 0.25), 1);
      d.mat.opacity = 1.0 - t * t;
    }

    for (const col of this.phase2Columns) {
      if (!col.active) continue;
      col.life += dt;
      const t = col.life / col.maxLife;
      if (t >= 1) {
        col.active = false;
        col.group.visible = false;
        continue;
      }
      const rise = Math.min(1.15, t * 2.6);
      const shrink = (1.05 - t * 0.65) * (col.scaleMult || 1.0);
      col.group.scale.set(shrink, rise, shrink);
      col.group.rotation.y += dt * 3.5 * (col.spinDir || 1);
      col.outerMat.opacity = 0.72 * (1 - t);
      col.innerMat.opacity = 0.92 * (1 - t * t);
    }

    for (const c of this.craters) {
      if (!c.active) continue;
      c.life += dt;
      const t = c.life / c.maxLife;
      if (t >= 1) {
        c.active = false;
        c.mesh.visible = false;
        continue;
      }
      c.mat.opacity = 0.86 * (1 - Math.pow(t, 1.4));
    }

    for (const w of this.wards) {
      if (!w.active) continue;
      w.life += dt;
      const t = w.life / w.maxLife;
      if (t >= 1) {
        w.active = false;
        w.group.visible = false;
        continue;
      }
      w.group.scale.setScalar(0.7 + t * 0.65);
      w.mat.opacity = 0.95 * (1 - t);
      w.fillMat.opacity = 0.28 * (1 - t);
    }

    for (const b of this.magicBursts) {
      if (!b.active) continue;
      b.life += dt;
      const t = b.life / b.maxLife;
      if (t >= 1) {
        b.active = false;
        b.mesh.visible = false;
        continue;
      }
      b.mesh.scale.setScalar(0.35 + t * b.maxScale);
      b.mesh.rotation.y += dt * 4;
      b.mat.opacity = 0.85 * (1 - t * t);
      b.spriteMat.opacity = 0.9 * (1 - t);
    }

    for (const sw of this.shockwaves) {
      if (!sw.active) continue;
      sw.radius += sw.speed * dt;
      const t = sw.radius / sw.maxRadius;
      sw.mesh.scale.setScalar(sw.radius);
      const op = Math.max(0, 0.92 * (1 - t));
      sw.mat.opacity = op;
      if (sw.innerMat) sw.innerMat.opacity = op * 0.72;
      if (sw.isHostile && !sw.hitPlayer && onShockwaveHitPlayer) {
        if (onShockwaveHitPlayer(sw)) {
          sw.hitPlayer = true;
        }
      }
      if (sw.radius >= sw.maxRadius) {
        sw.active = false;
        sw.mesh.visible = false;
      }
    }

    for (const p of this.pillars) {
      if (!p.active) continue;
      p.timer += dt;
      if (!p.detonated) {
        const prog = Math.min(1, p.timer / p.fuse);
        p.ring.scale.setScalar(0.35 + prog * 0.65);
        p.ringMat.opacity = 0.4 + prog * 0.55;
        if (p.timer >= p.fuse) {
          p.detonated = true;
          p.timer = 0;
          p.col.visible = true;
          p.col.scale.set(1, 0.2, 1);
          p.colMat.opacity = 0.95;
          this.spawnSparks({ x: p.x, y: 0.4, z: p.z }, 24, 0xff8c33, 9.5, 10);
          this.spawnSmoke({ x: p.x, y: 0.4, z: p.z }, 4, 0x3b2c2a);
          this.spawnGroundCrater({ x: p.x, z: p.z }, 2.1, 0xff5a18);
          this.spawnHitFlash({ x: p.x, y: 1.4, z: p.z }, 0xffa638, 2.8);
        }
      } else {
        const dur = 0.48;
        const prog = p.timer / dur;
        p.col.scale.set(1 - prog * 0.35, Math.min(1.2, prog * 4.5), 1 - prog * 0.35);
        p.colMat.opacity = Math.max(0, 0.95 * (1 - prog));
        p.ringMat.opacity = Math.max(0, 0.8 * (1 - prog));
        if (!p.hitPlayer && prog < 0.55 && onPillarHitPlayer) {
          if (onPillarHitPlayer(p.x, p.z, 1.85)) {
            p.hitPlayer = true;
          }
        }
        if (p.timer >= dur) {
          p.active = false;
          p.ring.visible = false;
          p.col.visible = false;
        }
      }
    }

    if (this.floatingPool.length > 0 && typeof window !== 'undefined') {
      const w = window.innerWidth;
      const h = window.innerHeight;
      for (const f of this.floatingPool) {
        if (!f.active) continue;
        f.life += dt;
        if (f.life >= f.maxLife) {
          f.active = false;
          f.el.className = 'float-dmg hidden';
          continue;
        }
        f.worldPos.y += f.vy * dt;
        this.tmpProj.copy(f.worldPos).project(this.camera);
        if (this.tmpProj.z > 1) {
          f.el.style.opacity = '0';
          continue;
        }
        const sx = (this.tmpProj.x * 0.5 + 0.5) * w;
        const sy = (-this.tmpProj.y * 0.5 + 0.5) * h;
        const fade = 1 - Math.pow(f.life / f.maxLife, 2);
        f.el.style.left = `${sx.toFixed(1)}px`;
        f.el.style.top = `${sy.toFixed(1)}px`;
        f.el.style.opacity = fade.toFixed(2);
      }
    }
  }
}

export class SwordTrail {
  constructor(scene, segments = 16, colorHex = 0xffaa44) {
    this.segments = segments;
    this.positions = new Float32Array(segments * 2 * 3);
    this.colors = new Float32Array(segments * 2 * 3);
    this.uvs = new Float32Array(segments * 2 * 2);
    for (let i = 0; i < segments; i++) {
      const u = segments > 1 ? i / (segments - 1) : 0;
      const uvIdx = i * 4;
      this.uvs[uvIdx] = u;
      this.uvs[uvIdx + 1] = 0;
      this.uvs[uvIdx + 2] = u;
      this.uvs[uvIdx + 3] = 1;
    }
    this.indices = [];
    for (let i = 0; i < segments - 1; i++) {
      const a = i * 2;
      const b = a + 1;
      const c = a + 2;
      const d = a + 3;
      this.indices.push(a, b, c, b, d, c);
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(this.positions, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(this.colors, 3));
    geo.setAttribute('uv', new THREE.BufferAttribute(this.uvs, 2));
    geo.setIndex(this.indices);

    this.trailTex = acquireTrailTexture();
    this.baseColor = new THREE.Color(colorHex);
    this.mat = new THREE.MeshBasicMaterial({
      map: this.trailTex || null,
      vertexColors: true,
      transparent: true,
      opacity: 0.92,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    this.mesh = new THREE.Mesh(geo, this.mat);
    this.mesh.frustumCulled = false;
    this.mesh.visible = false;
    scene.add(this.mesh);
    this.active = false;
    this.initialized = false;
  }

  setColor(hex) {
    this.baseColor.setHex(hex);
  }

  update(active, basePos, tipPos) {
    if (!active) {
      if (this.active) {
        this.active = false;
        this.initialized = false;
        this.mesh.visible = false;
      }
      return;
    }

    this.active = true;
    this.mesh.visible = true;

    if (!this.initialized) {
      for (let i = 0; i < this.segments; i++) {
        this._writePair(i, basePos, tipPos);
      }
      this.initialized = true;
    } else {
      for (let i = this.segments - 1; i > 0; i--) {
        const dst = i * 6;
        const src = (i - 1) * 6;
        for (let k = 0; k < 6; k++) {
          this.positions[dst + k] = this.positions[src + k];
        }
      }
      this._writePair(0, basePos, tipPos);
    }

    const hotSegments = Math.max(2, Math.floor(this.segments * 0.26));
    for (let i = 0; i < this.segments; i++) {
      const fade = Math.pow(1 - i / (this.segments - 1), 1.3);
      const idx = i * 6;
      const heat = i < hotSegments ? 1 - i / hotSegments : 0;
      const r = THREE.MathUtils.lerp(this.baseColor.r, 1.0, heat * 0.68) * fade;
      const g = THREE.MathUtils.lerp(this.baseColor.g, 0.96, heat * 0.68) * fade;
      const b = THREE.MathUtils.lerp(this.baseColor.b, 0.88, heat * 0.58) * fade;
      this.colors[idx] = r * 0.35;
      this.colors[idx + 1] = g * 0.35;
      this.colors[idx + 2] = b * 0.35;
      this.colors[idx + 3] = r;
      this.colors[idx + 4] = g;
      this.colors[idx + 5] = b;
    }

    this.mesh.geometry.getAttribute('position').needsUpdate = true;
    this.mesh.geometry.getAttribute('color').needsUpdate = true;
  }

  _writePair(i, basePos, tipPos) {
    const idx = i * 6;
    this.positions[idx] = basePos.x;
    this.positions[idx + 1] = basePos.y;
    this.positions[idx + 2] = basePos.z;
    this.positions[idx + 3] = tipPos.x;
    this.positions[idx + 4] = tipPos.y;
    this.positions[idx + 5] = tipPos.z;
  }

  dispose() {
    this.mesh.parent?.remove(this.mesh);
    this.mesh.geometry.dispose();
    this.mat.dispose();
    if (this.trailTex) {
      this.trailTex = null;
      releaseTrailTexture();
    }
  }
}
