import * as THREE from 'three';
import { SwordTrail } from './vfx.js';
import {
  buildStylizedBossRig,
  equipSkeletonGLBArmory,
  createContactAuraMesh,
  createCharacterAuraRing,
  createDarkEnergyAuraMesh,
  updateRimShaderUniforms,
} from './stylized.js';
import { GLBAnimationController, disposeObject3D } from './modelManager.js';

export const BossState = {
  IDLE: 'IDLE',
  APPROACH: 'APPROACH',
  ATTACK_WINDUP: 'ATTACK_WINDUP',
  ATTACK: 'ATTACK',
  RECOVERY: 'RECOVERY',
  STUNNED: 'STUNNED',
  ENRAGED: 'ENRAGED',
  DEFEATED: 'DEFEATED',
};

export const BossAttackType = {
  BASIC_SWING: 'BASIC_SWING',
  HEAVY_OVERHEAD: 'HEAVY_OVERHEAD',
  GROUND_SHOCKWAVE: 'GROUND_SHOCKWAVE',
  FORWARD_DASH: 'FORWARD_DASH',
  PHASE2_ERUPTION: 'PHASE2_ERUPTION',
};

export const BOSS_GLB_PATHS = {
  skeleton_warlord: '/models/Skeleton_Warrior.glb',
};

const ATTACK_SPECS = {
  [BossAttackType.BASIC_SWING]: { windup: 0.68, active: 0.34, recovery: 0.62, damage: 145, range: 4.5, parryable: true, arcDeg: 160 },
  [BossAttackType.HEAVY_OVERHEAD]: { windup: 0.96, active: 0.32, recovery: 0.95, damage: 245, range: 4.9, parryable: true, arcDeg: 110 },
  [BossAttackType.GROUND_SHOCKWAVE]: { windup: 1.05, active: 0.36, recovery: 0.95, damage: 195, range: 4.2, parryable: false, arcDeg: 360 },
  [BossAttackType.FORWARD_DASH]: { windup: 0.85, active: 0.45, recovery: 0.85, damage: 190, range: 3.6, parryable: true, arcDeg: 140 },
  [BossAttackType.PHASE2_ERUPTION]: { windup: 0.95, active: 0.4, recovery: 1.05, damage: 215, range: 4.4, parryable: false, arcDeg: 360 },
};

export class AshenKnightBoss {
  constructor(scene) {
    this.scene = scene;
    this.root = new THREE.Group();
    this.root.position.set(0, 0, -7.5);
    this.root.rotation.y = 0;

    this.maxHp = 2600;
    this.hp = 2600;
    this.maxPoise = 100;
    this.poise = 0;

    this.phase = 1;
    this.state = BossState.IDLE;
    this.stateTime = 0;
    this.currentAttack = BossAttackType.BASIC_SWING;
    this.attackHasHit = false;
    this.shockwaveFired = false;
    this.comboFollowupPending = false;
    this.hitFlashTimer = 0;
    this.hitRecoilTimer = 0;
    this.hitRecoilDuration = 0.16;
    this.hitRecoilIntensity = 0;
    this.criticalAvailable = false;
    this.telegraphSparkTimer = 0;
    this.lastStepHalf = 0;

    this.facingYaw = 0;
    this.radius = 1.25;
    this.lastAttackIndex = -1;

    this.bladeBaseWorld = new THREE.Vector3();
    this.bladeTipWorld = new THREE.Vector3();
    this.tmpVec = new THREE.Vector3();

    this.presetId = 'ashen_behemoth';
    this.isCustomModel = false;
    this.modelRequestId = 0;
    this.rig = null;
    this.glbCtrl = null;
    this.visualGroup = null;
    this.glbSwordBase = null;
    this.glbSwordTip = null;
    this.glbRuneMat = null;
    this.trackedMaterials = [];

    // Shared boss aura point light for GLB presets
    this.auraLight = new THREE.PointLight(0xff5518, 3.6, 13, 1.5);
    this.auraLight.position.set(0, 2.2, 0.8);
    this.root.add(this.auraLight);

    this.contactAura = createContactAuraMesh(0xff5518, 1.85, 0.62);
    this.root.add(this.contactAura);

    this.bossAuraRing = createCharacterAuraRing(0xff5518, 1.48, 1.86, 0.44);
    this.root.add(this.bossAuraRing);

    this.darkEnergyAura = createDarkEnergyAuraMesh(2.25, 0.72);
    this.root.add(this.darkEnergyAura);

    this.phase2CrownRing = new THREE.Mesh(
      new THREE.TorusGeometry(1.15, 0.036, 6, 32),
      new THREE.MeshBasicMaterial({
        color: 0xffaa33,
        transparent: true,
        opacity: 0.86,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    this.phase2CrownRing.position.set(0, 2.65, -0.35);
    this.phase2CrownRing.visible = false;
    this.root.add(this.phase2CrownRing);

    this.emberTimer = 0;

    this.setPreset('ashen_behemoth');
    this.trail = new SwordTrail(scene, 14, 0xff4b1f);
    this.scene.add(this.root);
  }

  _clearVisual() {
    if (this.glbCtrl) {
      this.glbCtrl.dispose();
      this.glbCtrl = null;
    }
    if (this.visualGroup) {
      this.root.remove(this.visualGroup);
      disposeObject3D(this.visualGroup);
      this.visualGroup = null;
    }
    this.rig = null;
    this.glbSwordBase = null;
    this.glbSwordTip = null;
    this.glbRuneMat = null;
    this.trackedMaterials = [];
  }

  setPreset(presetId = 'ashen_behemoth') {
    this.presetId = presetId;
    this.isCustomModel = false;
    this._clearVisual();
    this.rig = buildStylizedBossRig(presetId);
    this.visualGroup = this.rig.root;
    this.root.add(this.visualGroup);
    this.auraLight.intensity = 0; // procedural rig already has internal bossLight
    this._applyPhaseVisuals(this.phase);
  }

  async loadPresetGLB(glbLoader, presetId = 'skeleton_warlord') {
    this.presetId = presetId;
    this.isCustomModel = false;
    const url = BOSS_GLB_PATHS[presetId];
    if (!url) {
      this.setPreset(presetId);
      return true;
    }
    const reqId = ++this.modelRequestId;
    try {
      const loaded = await glbLoader.loadAsync(url, 3.65, {
        stylizeToon: false,
        addOutlines: false,
        enhancePBR: true,
        hideSpareWeapons: true,
        rimColor: 0xff6a24,
        rimStrength: 0.56,
      });
      if (reqId !== this.modelRequestId || this.isCustomModel) {
        disposeObject3D(loaded.scene);
        return false;
      }
      const armory = equipSkeletonGLBArmory(loaded.scene, 'boss');
      this._applyGLBVisual(
        loaded.scene,
        loaded.animations,
        armory.swordBaseMarker || loaded.swordBaseMarker,
        armory.swordTipMarker || loaded.swordTipMarker,
        loaded.trackedMaterials || [],
        armory.runeMat,
        false
      );
      return true;
    } catch (_) {
      if (reqId === this.modelRequestId && !this.isCustomModel) {
        this.setPreset(presetId === 'skeleton_warlord' ? 'ashen_behemoth' : presetId);
      }
      return false;
    }
  }

  applyCustomGLB(clonedScene, animations, swordBase = null, swordTip = null, trackedMats = []) {
    this.modelRequestId++;
    this._applyGLBVisual(clonedScene, animations, swordBase, swordTip, trackedMats, null, true);
  }

  _applyGLBVisual(clonedScene, animations, swordBase, swordTip, trackedMats, runeMat = null, isCustom = false) {
    this._clearVisual();
    this.isCustomModel = isCustom;
    this.visualGroup = clonedScene;
    this.glbSwordBase = swordBase || clonedScene.getObjectByName('SwordBase') || null;
    this.glbSwordTip = swordTip || clonedScene.getObjectByName('SwordTip') || null;
    this.glbRuneMat = runeMat;
    this.trackedMaterials = trackedMats || [];
    if (this.trackedMaterials.length === 0) {
      clonedScene.traverse((n) => {
        if ((n.isMesh || n.isSkinnedMesh) && !n.name.endsWith('_outline') && n.material) {
          const mats = Array.isArray(n.material) ? n.material : [n.material];
          this.trackedMaterials.push(...mats);
        }
      });
    }
    this.root.add(this.visualGroup);
    this.glbCtrl = new GLBAnimationController(this.visualGroup, animations);
    this.glbCtrl.playState('IDLE');
    this._applyPhaseVisuals(this.phase);
  }

  reset() {
    this.hp = this.maxHp;
    this.poise = 0;
    this.phase = 1;
    this.state = BossState.IDLE;
    this.stateTime = 0;
    this.attackHasHit = false;
    this.shockwaveFired = false;
    this.comboFollowupPending = false;
    this.hitFlashTimer = 0;
    this.hitRecoilTimer = 0;
    this.hitRecoilDuration = 0.16;
    this.hitRecoilIntensity = 0;
    this.criticalAvailable = false;
    this.telegraphSparkTimer = 0;
    this.lastAttackIndex = -1;
    this.lastStepHalf = 0;
    this.root.position.set(0, 0, -7.5);
    this.facingYaw = 0;
    this.root.rotation.set(0, 0, 0);
    if (this.visualGroup && !this.rig) this.visualGroup.rotation.set(0, 0, 0);
    this._applyPhaseVisuals(1);
    this.trail.setColor(0xff4b1f);
    this.trail.update(false);
    if (this.rig) this._resetPose(1);
    this.glbCtrl?.resetTransform();
    this.glbCtrl?.playState('IDLE');
  }

  _applyPhaseVisuals(phase) {
    const isVoid = this.presetId === 'void_colossus';
    const auraColor = phase === 2
      ? (isVoid ? 0xd26bff : 0xffaa33)
      : (isVoid ? 0x9933ff : 0xff5518);
    if (this.contactAura) {
      this.contactAura.visible = this.state !== BossState.DEFEATED;
      this.contactAura.material.color.setHex(auraColor);
      this.contactAura.material.opacity = phase === 2 ? 0.78 : 0.6;
    }
    if (this.bossAuraRing) {
      this.bossAuraRing.visible = this.state !== BossState.DEFEATED;
      this.bossAuraRing.material.color.setHex(auraColor);
      this.bossAuraRing.material.opacity = phase === 2 ? 0.72 : 0.42;
    }
    if (this.darkEnergyAura) {
      this.darkEnergyAura.visible = this.state !== BossState.DEFEATED;
      this.darkEnergyAura.material.color.setHex(
        phase === 2 ? (isVoid ? 0xaa33ff : 0xff5a18) : (isVoid ? 0x6222aa : 0x5c2248)
      );
      this.darkEnergyAura.material.opacity = phase === 2 ? 0.86 : 0.72;
    }
    if (this.phase2CrownRing) {
      this.phase2CrownRing.visible = phase === 2 && this.state !== BossState.DEFEATED;
      this.phase2CrownRing.material.color.setHex(isVoid ? 0xd26bff : 0xffaa33);
    }
    if (this.rig) {
      if (phase === 2) {
        this.rig.materials.moltenMat.color.setHex(isVoid ? 0xe085ff : 0xffb347);
        this.rig.materials.moltenMat.emissive.setHex(isVoid ? 0xc24dff : 0xff7722);
        this.rig.materials.moltenMat.emissiveIntensity = 3.6;
        this.rig.bossLight.intensity = 7.5;
        this.trail?.setColor(isVoid ? 0xd26bff : 0xffa630);
      } else {
        this.rig.materials.moltenMat.color.setHex(isVoid ? 0xaa4dff : 0xff5a1f);
        this.rig.materials.moltenMat.emissive.setHex(isVoid ? 0x8f2eff : 0xff4510);
        this.rig.materials.moltenMat.emissiveIntensity = 2.2;
        this.rig.bossLight.intensity = 4.2;
        this.trail?.setColor(isVoid ? 0x9933ff : 0xff4b1f);
      }
      this.auraLight.intensity = 0;
    } else {
      this.auraLight.color.setHex(phase === 2 ? 0xff9a33 : 0xff5518);
      this.auraLight.intensity = phase === 2 ? 7.4 : 4.2;
      if (this.glbRuneMat) {
        this.glbRuneMat.emissiveIntensity = phase === 2 ? 3.8 : 2.4;
      }
      if (!this.isCustomModel && this.trackedMaterials.length > 0) {
        updateRimShaderUniforms(this.trackedMaterials, auraColor, phase === 2 ? 0.78 : 0.56);
      }
      this.trail?.setColor(phase === 2 ? 0xffa630 : 0xff4b1f);
    }
  }

  startCombat() {
    this.state = BossState.APPROACH;
    this.stateTime = 0;
    this.glbCtrl?.playState('MOVE');
  }

  takeDamage(amount, poiseDamage, isSkill = false, heavyHit = false) {
    if (this.state === BossState.DEFEATED || this.state === BossState.ENRAGED) {
      return { damage: 0, triggeredPhase2: false, staggered: false };
    }

    const multiplier = this.state === BossState.STUNNED ? 1.4 : 1.0;
    const finalDmg = Math.round(amount * multiplier);
    this.hp = Math.max(0, this.hp - finalDmg);
    this.hitFlashTimer = heavyHit || isSkill ? 0.18 : 0.13;
    this.hitRecoilDuration = heavyHit || isSkill ? 0.22 : 0.13;
    this.hitRecoilTimer = this.hitRecoilDuration;
    this.hitRecoilIntensity = heavyHit || isSkill ? 1.0 : 0.45;

    if (this.hp <= 0) {
      this.state = BossState.DEFEATED;
      this.stateTime = 0;
      this.criticalAvailable = false;
      this.hitRecoilTimer = 0;
      if (this.visualGroup && !this.rig) this.visualGroup.rotation.set(0, 0, 0);
      this.trail.update(false);
      this.auraLight.intensity = 0;
      if (this.contactAura) this.contactAura.visible = false;
      if (this.bossAuraRing) this.bossAuraRing.visible = false;
      if (this.darkEnergyAura) this.darkEnergyAura.visible = false;
      if (this.phase2CrownRing) this.phase2CrownRing.visible = false;
      this.glbCtrl?.playState('DEATH', true);
      return { damage: finalDmg, triggeredPhase2: false, staggered: false, defeated: true };
    }

    if (this.phase === 1 && this.hp <= this.maxHp * 0.5) {
      this.phase = 2;
      this.state = BossState.ENRAGED;
      this.stateTime = 0;
      this.poise = 0;
      this.criticalAvailable = false;
      this.shockwaveFired = false;
      this.attackHasHit = false;
      this.comboFollowupPending = false;
      this.trail.update(false);
      this.glbCtrl?.playState('ENRAGED', true);
      return { damage: finalDmg, triggeredPhase2: true, staggered: false, defeated: false };
    }

    let staggered = false;
    if (this.state !== BossState.STUNNED) {
      this.poise += poiseDamage + (isSkill ? 20 : 0);
      if (this.poise >= this.maxPoise) {
        this.poise = 0;
        this.state = BossState.STUNNED;
        this.stateTime = 0;
        this.criticalAvailable = true;
        this.shockwaveFired = false;
        this.attackHasHit = false;
        this.comboFollowupPending = false;
        this.trail.update(false);
        this.glbCtrl?.playState('STUNNED');
        staggered = true;
      }
    }

    return { damage: finalDmg, triggeredPhase2: false, staggered, defeated: false };
  }

  staggerFromParry() {
    if (this.state === BossState.DEFEATED || this.state === BossState.ENRAGED || this.state === BossState.STUNNED) {
      return false;
    }
    this.poise = 0;
    this.state = BossState.STUNNED;
    this.stateTime = 0;
    this.criticalAvailable = true;
    this.hitRecoilDuration = 0.24;
    this.hitRecoilTimer = 0.24;
    this.hitRecoilIntensity = 1.15;
    this.shockwaveFired = false;
    this.comboFollowupPending = false;
    this.attackHasHit = true;
    this.trail.update(false);
    this.glbCtrl?.playState('STUNNED');
    return true;
  }

  canReceiveCriticalStrike(playerPos, maxDist = 4.9) {
    if (this.state !== BossState.STUNNED || !this.criticalAvailable || !playerPos) return false;
    const dx = playerPos.x - this.root.position.x;
    const dz = playerPos.z - this.root.position.z;
    return Math.hypot(dx, dz) <= maxDist;
  }

  consumeCriticalStrike() {
    if (!this.criticalAvailable) return false;
    this.criticalAvailable = false;
    this.hitRecoilDuration = 0.28;
    this.hitRecoilTimer = 0.28;
    this.hitRecoilIntensity = 1.4;
    return true;
  }

  isParryableNow() {
    if (this.state !== BossState.ATTACK) return false;
    const spec = ATTACK_SPECS[this.currentAttack];
    return spec.parryable && !this.attackHasHit;
  }

  isTelegraphingParryCue() {
    if (this.state !== BossState.ATTACK_WINDUP) return false;
    const spec = ATTACK_SPECS[this.currentAttack];
    const speedScale = this.phase === 2 ? 1.28 : 1.0;
    const windup = spec.windup / speedScale;
    return spec.parryable && this.stateTime >= windup * 0.55;
  }

  update(dt, elapsed, playerPos, arena, vfx, audio, callbacks) {
    const speedScale = this.phase === 2 ? 1.28 : 1.0;
    this.stateTime += dt;

    if (this.hitFlashTimer > 0) this.hitFlashTimer -= dt;
    if (this.hitRecoilTimer > 0) this.hitRecoilTimer = Math.max(0, this.hitRecoilTimer - dt);
    if (this.rig) {
      if (this.hitFlashTimer > 0) {
        this.rig.materials.bodyArmorMat.emissive.setHex(0x882a10);
        this.rig.materials.bodyArmorMat.emissiveIntensity = 0.62;
      } else {
        this.rig.materials.bodyArmorMat.emissive.setHex(0x000000);
        this.rig.materials.bodyArmorMat.emissiveIntensity = 0;
      }
    } else if (this.trackedMaterials.length > 0) {
      for (const m of this.trackedMaterials) {
        if (!m || !m.emissive || m.name === 'Glow' || m.name === 'RuneGlowMat') continue;
        if (this.hitFlashTimer > 0) {
          m.emissive.setHex(0x992610);
          m.emissiveIntensity = 0.72;
        } else {
          m.emissive.setHex(0x000000);
          m.emissiveIntensity = 0;
        }
      }
    }

    const alive = this.state !== BossState.DEFEATED;
    if (this.contactAura) {
      this.contactAura.visible = alive;
      if (alive) {
        const pulse = 1 + Math.sin(elapsed * (this.phase === 2 ? 6.0 : 3.4)) * 0.06;
        const windupBoost = this.state === BossState.ATTACK_WINDUP ? 1.15 : 1.0;
        this.contactAura.scale.setScalar(pulse * windupBoost);
      }
    }
    if (this.bossAuraRing) {
      this.bossAuraRing.visible = alive;
      if (alive) {
        const windupBoost = this.state === BossState.ATTACK_WINDUP ? 1.18 : 1.0;
        const pulse = 1 + Math.sin(elapsed * (this.phase === 2 ? 6.4 : 3.6)) * 0.05;
        this.bossAuraRing.rotation.y += dt * (this.phase === 2 ? 1.85 : 0.85);
        this.bossAuraRing.scale.setScalar(pulse * windupBoost);
      }
    }
    if (this.darkEnergyAura) {
      this.darkEnergyAura.visible = alive;
      if (alive) {
        const windupBoost = this.state === BossState.ATTACK_WINDUP ? 1.14 : 1.0;
        const pulse = 1 + Math.sin(elapsed * (this.phase === 2 ? 5.4 : 2.8)) * 0.04;
        this.darkEnergyAura.rotation.y -= dt * (this.phase === 2 ? 0.95 : 0.45);
        this.darkEnergyAura.scale.setScalar(pulse * windupBoost);
      }
    }
    if (this.phase2CrownRing) {
      this.phase2CrownRing.visible = alive && this.phase === 2;
      if (this.phase2CrownRing.visible) {
        const pulse = 1 + Math.sin(elapsed * 5.2) * 0.04;
        this.phase2CrownRing.rotation.z += dt * 0.85;
        this.phase2CrownRing.scale.setScalar(pulse);
      }
    }
    if (alive) {
      const windupSurge = this.state === BossState.ATTACK_WINDUP ? 1.85 : 0;
      const baseIntensity = this.phase === 2 ? 7.4 : 4.2;
      if (this.rig?.bossLight) {
        this.rig.bossLight.intensity = baseIntensity + windupSurge;
      } else {
        this.auraLight.intensity = baseIntensity + windupSurge;
      }
    }

    if (this.state !== BossState.DEFEATED) {
      this.emberTimer += dt;
      const interval = this.phase === 2 ? 0.055 : 0.14;
      if (this.emberTimer >= interval) {
        this.emberTimer = 0;
        this.tmpVec.set(
          this.root.position.x + (Math.random() - 0.5) * 1.6,
          1.2 + Math.random() * 2.4,
          this.root.position.z + (Math.random() - 0.5) * 1.6
        );
        vfx.spawnSparks(this.tmpVec, 1, this.phase === 2 ? 0xffae38 : 0xff5a22, 1.8, -2.5);
      }
    }

    const dx = playerPos.x - this.root.position.x;
    const dz = playerPos.z - this.root.position.z;
    const dist = Math.hypot(dx, dz);
    const angleToPlayer = Math.atan2(dx, dz);

    if (this.state === BossState.APPROACH) {
      this.facingYaw = lerpAngle(this.facingYaw, angleToPlayer, Math.min(1, dt * 5.2 * speedScale));
      const moveSpd = this.phase === 2 ? 4.4 : 3.25;
      if (dist > 3.1) {
        this.root.position.x += Math.sin(this.facingYaw) * moveSpd * dt;
        this.root.position.z += Math.cos(this.facingYaw) * moveSpd * dt;
        this.glbCtrl?.playState('MOVE');

        const stepHalf = Math.floor((elapsed * 4.8 * speedScale) / Math.PI);
        if (stepHalf !== this.lastStepHalf) {
          this.lastStepHalf = stepHalf;
          audio.playFootstep(true);
        }
      } else {
        this.glbCtrl?.playState('IDLE');
      }

      if (this.stateTime > (this.phase === 2 ? 0.75 : 1.15) && (dist < 4.5 || this.stateTime > 2.2)) {
        this._chooseNextAttack(dist);
        this.state = BossState.ATTACK_WINDUP;
        this.stateTime = 0;
        this.attackHasHit = false;
        this.shockwaveFired = false;
        if (this.currentAttack === BossAttackType.BASIC_SWING && this.phase === 2) {
          this.comboFollowupPending = true;
        }
        if (this.currentAttack === BossAttackType.FORWARD_DASH) {
          this.glbCtrl?.playState('PARRY', true, 0.85 * speedScale, 0.1);
        } else if (this.currentAttack === BossAttackType.PHASE2_ERUPTION) {
          this.glbCtrl?.playState('CAST', true, 1.1 * speedScale, 0.1);
        } else if (
          this.currentAttack === BossAttackType.HEAVY_OVERHEAD ||
          this.currentAttack === BossAttackType.GROUND_SHOCKWAVE
        ) {
          const heavyClipSpeed =
            this.currentAttack === BossAttackType.HEAVY_OVERHEAD ? 1.28 * speedScale : 1.18 * speedScale;
          this.glbCtrl?.playState('HEAVY', true, heavyClipSpeed, 0.1);
        } else {
          this.glbCtrl?.playState('ATTACK', true, 1.05 * speedScale, 0.1);
        }
      }
    } else if (this.state === BossState.ATTACK_WINDUP) {
      const spec = ATTACK_SPECS[this.currentAttack];
      const windupDur = spec.windup / speedScale;
      const prog = Math.min(1, this.stateTime / windupDur);
      if (this.currentAttack !== BossAttackType.FORWARD_DASH || prog < 0.68) {
        const trackRate = this.currentAttack === BossAttackType.FORWARD_DASH ? 2.6 : 5.0;
        this.facingYaw = lerpAngle(this.facingYaw, angleToPlayer, Math.min(1, dt * trackRate));
      }

      if (this.currentAttack === BossAttackType.HEAVY_OVERHEAD) {
        vfx.showCircleTelegraph(
          this.root.position.x + Math.sin(this.facingYaw) * 2.2,
          this.root.position.z + Math.cos(this.facingYaw) * 2.2,
          3.4,
          prog,
          0xff3318
        );
        arena?.triggerBossAttackGlow?.(0.32 + prog * 0.42);
      } else if (this.currentAttack === BossAttackType.GROUND_SHOCKWAVE || this.currentAttack === BossAttackType.PHASE2_ERUPTION) {
        vfx.showCircleTelegraph(this.root.position.x, this.root.position.z, 4.4, prog, 0xff7a22);
        arena?.triggerBossAttackGlow?.(0.4 + prog * 0.55);
      } else if (this.currentAttack === BossAttackType.FORWARD_DASH) {
        vfx.showDashTelegraph(this.root.position.x, this.root.position.z, this.facingYaw, 10.2, prog);
        arena?.triggerBossAttackGlow?.(0.24 + prog * 0.3);
      }

      if (prog > 0.65) {
        this.telegraphSparkTimer += dt;
        if (this.telegraphSparkTimer >= 0.07) {
          this.telegraphSparkTimer = 0;
          this.tmpVec.set(
            this.root.position.x + (Math.random() - 0.5) * 1.4,
            2.1 + Math.random() * 1.3,
            this.root.position.z + (Math.random() - 0.5) * 1.4
          );
          const sparkHex = this.currentAttack === BossAttackType.BASIC_SWING ? 0xffaa44 : 0xff4c1e;
          vfx.spawnSparks(this.tmpVec, 2, sparkHex, 4.5, -2.0);
        }
      }

      if (this.stateTime >= windupDur) {
        vfx.hideTelegraphs();
        this.telegraphSparkTimer = 0;
        this.state = BossState.ATTACK;
        this.stateTime = 0;
        audio.playSwordSwing(true);
        if (this.currentAttack === BossAttackType.FORWARD_DASH) {
          this.glbCtrl?.playState('ATTACK', true, 2.0 * speedScale, 0.06);
        }
      }
    } else if (this.state === BossState.ATTACK) {
      const spec = ATTACK_SPECS[this.currentAttack];
      const activeDur = spec.active / speedScale;
      const prevX = this.root.position.x;
      const prevZ = this.root.position.z;

      if (this.currentAttack === BossAttackType.FORWARD_DASH) {
        const dashProg = Math.min(1, this.stateTime / activeDur);
        const dashMult = this.attackHasHit ? 0.35 : 1.0;
        const speed = 29.0 * speedScale * dashMult;
        this.root.position.x += Math.sin(this.facingYaw) * speed * dt * (1 - dashProg * 0.45);
        this.root.position.z += Math.cos(this.facingYaw) * speed * dt * (1 - dashProg * 0.45);
      } else if (this.currentAttack === BossAttackType.BASIC_SWING && this.stateTime < activeDur * 0.7) {
        this.root.position.x += Math.sin(this.facingYaw) * 3.2 * speedScale * dt;
        this.root.position.z += Math.cos(this.facingYaw) * 3.2 * speedScale * dt;
      }

      arena.resolveObstacleCollision(this.root.position, this.radius);

      if (this.currentAttack === BossAttackType.GROUND_SHOCKWAVE && !this.shockwaveFired && this.stateTime >= activeDur * 0.35) {
        this.shockwaveFired = true;
        audio.playShockwave();
        arena?.triggerBossAttackGlow?.(1.15);
        vfx.spawnShockwave(this.root.position, 15.5, this.phase === 2 ? 12.5 : 9.8, 0xff5a1f, true, spec.damage);
        vfx.spawnSparks(this.root.position, 28, 0xff7722, 10, 12);
        vfx.spawnSmoke(this.root.position, 5, 0x3b2c2a);
        vfx.spawnGroundCrater?.(this.root.position, 3.2, 0xff5a18);
        vfx.spawnHitFlash?.({ x: this.root.position.x, y: 0.7, z: this.root.position.z }, 0xff8a30, 3.4);
        callbacks.onHeavyImpact(0.45);
      }

      if (this.currentAttack === BossAttackType.PHASE2_ERUPTION && !this.shockwaveFired && this.stateTime >= activeDur * 0.35) {
        this.shockwaveFired = true;
        audio.playShockwave();
        audio.playFireBurst();
        arena?.triggerBossAttackGlow?.(1.35);
        vfx.spawnShockwave(this.root.position, 12.5, 11.2, 0xff9b33, true, 165);
        vfx.spawnGroundCrater?.(this.root.position, 3.5, 0xff8c2b);
        vfx.spawnHitFlash?.({ x: this.root.position.x, y: 1.5, z: this.root.position.z }, 0xffae38, 3.8);
        for (let k = 0; k < 3; k++) {
          const ang = (k / 3) * Math.PI * 2 + Math.random() * 0.6;
          const r = k === 0 ? 0.6 : 3.2;
          vfx.spawnEruptionPillar(playerPos.x + Math.cos(ang) * r, playerPos.z + Math.sin(ang) * r, 0.72 + k * 0.14);
        }
        callbacks.onHeavyImpact(0.5);
      }

      const hitStart = this.currentAttack === BossAttackType.FORWARD_DASH ? activeDur * 0.05 : activeDur * 0.18;
      const hitEnd = this.currentAttack === BossAttackType.FORWARD_DASH ? activeDur * 0.92 : activeDur * 0.88;
      if (!this.attackHasHit && this.stateTime >= hitStart && this.stateTime <= hitEnd) {
        const curDx = playerPos.x - this.root.position.x;
        const curDz = playerPos.z - this.root.position.z;
        const curDist = Math.hypot(curDx, curDz);
        const inRange = curDist <= spec.range;
        const bossForwardX = Math.sin(this.facingYaw);
        const bossForwardZ = Math.cos(this.facingYaw);
        const toPlayerX = curDist > 0.001 ? curDx / curDist : 0;
        const toPlayerZ = curDist > 0.001 ? curDz / curDist : 1;
        const dot = bossForwardX * toPlayerX + bossForwardZ * toPlayerZ;
        const cosHalfArc = Math.cos(((spec.arcDeg * 0.5) * Math.PI) / 180);

        let sweptDashHit = false;
        if (this.currentAttack === BossAttackType.FORWARD_DASH) {
          const sweptDistSq = pointToSegmentDistSq2D(
            playerPos.x,
            playerPos.z,
            prevX,
            prevZ,
            this.root.position.x,
            this.root.position.z
          );
          const dashHitRadius = this.radius + 0.92;
          sweptDashHit = sweptDistSq <= dashHitRadius * dashHitRadius;
        }

        if ((inRange && dot >= cosHalfArc) || sweptDashHit) {
          this.attackHasHit = true;
          callbacks.onBossMeleeHit(spec.damage, spec.parryable, this.root.position);
        }
      }

      if (this.currentAttack === BossAttackType.HEAVY_OVERHEAD && !this.shockwaveFired && this.stateTime >= activeDur * 0.52) {
        this.shockwaveFired = true;
        audio.playShockwave();
        arena?.triggerBossAttackGlow?.(1.0);
        const impactPos = {
          x: this.root.position.x + Math.sin(this.facingYaw) * 2.2,
          y: 0.2,
          z: this.root.position.z + Math.cos(this.facingYaw) * 2.2,
        };
        vfx.spawnSparks(impactPos, 24, 0xff6a22, 8.5, 12);
        vfx.spawnSmoke(impactPos, 4, 0x3b2c2a);
        vfx.spawnGroundCrater?.(impactPos, 2.5, 0xff6a22);
        vfx.spawnHitFlash?.(impactPos, 0xff9b33, 2.8);
        callbacks.onHeavyImpact(0.35);
      }

      if (this.stateTime >= activeDur) {
        if (this.comboFollowupPending) {
          this.comboFollowupPending = false;
          this.state = BossState.ATTACK_WINDUP;
          this.stateTime = 0.26;
          this.attackHasHit = false;
          this.shockwaveFired = false;
          this.glbCtrl?.playState('ATTACK_2', true, 1.35 * speedScale, 0.08);
        } else {
          this.state = BossState.RECOVERY;
          this.stateTime = 0;
          this.glbCtrl?.playState('IDLE', false, 1.0, 0.14);
        }
      }
    } else if (this.state === BossState.RECOVERY) {
      const spec = ATTACK_SPECS[this.currentAttack];
      if (this.stateTime >= spec.recovery / speedScale) {
        this.state = BossState.APPROACH;
        this.stateTime = 0;
      }
    } else if (this.state === BossState.STUNNED) {
      if (this.stateTime >= 2.6) {
        this.criticalAvailable = false;
        this.state = BossState.APPROACH;
        this.stateTime = 0;
        this.glbCtrl?.playState(dist > 3.1 ? 'MOVE' : 'IDLE', false, 1.0, 0.14);
      }
    } else if (this.state === BossState.ENRAGED) {
      if (this.stateTime >= 0.9 && !this.shockwaveFired) {
        this.shockwaveFired = true;
        this._applyPhaseVisuals(2);
        audio.playPhase2Transform();
        arena?.triggerBossAttackGlow?.(1.55);
        if (typeof vfx.spawnPhase2ArenaPulse === 'function') {
          vfx.spawnPhase2ArenaPulse(this.root.position);
        } else {
          vfx.spawnMagicBurst(this.root.position, 0xff8c2b, 6.2);
          vfx.spawnShockwave(this.root.position, 18.0, 14.0, 0xffaa33, false, 0);
        }
        callbacks.onHeavyImpact(0.75);
      }
      if (this.stateTime >= 2.15) {
        this.state = BossState.APPROACH;
        this.stateTime = 0;
        this.shockwaveFired = false;
        this.glbCtrl?.playState(dist > 3.1 ? 'MOVE' : 'IDLE', false, 1.0, 0.14);
      }
    }

    arena.resolveObstacleCollision(this.root.position, this.radius);
    this.root.rotation.y = this.facingYaw;

    this.animatePose(dt, elapsed, speedScale);

    const showTrail = this.state === BossState.ATTACK && this.currentAttack !== BossAttackType.GROUND_SHOCKWAVE;
    if (showTrail) {
      if (this.rig) {
        this.rig.bladeBaseMarker.getWorldPosition(this.bladeBaseWorld);
        this.rig.bladeTipMarker.getWorldPosition(this.bladeTipWorld);
      } else if (this.glbSwordBase && this.glbSwordTip) {
        this.glbSwordBase.getWorldPosition(this.bladeBaseWorld);
        this.glbSwordTip.getWorldPosition(this.bladeTipWorld);
      } else {
        const sw = this.facingYaw + Math.sin(this.stateTime * 14) * 1.25;
        this.bladeBaseWorld.set(this.root.position.x, 1.8, this.root.position.z);
        this.bladeTipWorld.set(
          this.root.position.x + Math.sin(sw) * 3.2,
          2.0,
          this.root.position.z + Math.cos(sw) * 3.2
        );
      }
      this.trail.update(true, this.bladeBaseWorld, this.bladeTipWorld);
    } else {
      this.trail.update(false);
    }
  }

  animatePose(dt, elapsed, speedScale = 1.0) {
    const recoilProg =
      this.hitRecoilTimer > 0 && this.hitRecoilDuration > 0 && this.state !== BossState.DEFEATED
        ? Math.sin((this.hitRecoilTimer / this.hitRecoilDuration) * Math.PI) * this.hitRecoilIntensity
        : 0;
    if (this.rig) {
      this._animateLimbs(dt, elapsed, speedScale);
      if (recoilProg > 0) {
        this.rig.torso.rotation.x -= recoilProg * 0.14;
        this.rig.head.rotation.x -= recoilProg * 0.16;
      }
    } else if (this.glbCtrl) {
      const animKey =
        this.state === BossState.APPROACH
          ? 'MOVE'
          : this.state === BossState.ATTACK_WINDUP
          ? this.currentAttack === BossAttackType.FORWARD_DASH
            ? 'PARRY'
            : this.currentAttack === BossAttackType.PHASE2_ERUPTION
            ? 'CAST'
            : this.currentAttack === BossAttackType.BASIC_SWING
            ? 'ATTACK'
            : 'HEAVY'
          : this.state === BossState.RECOVERY
          ? 'IDLE'
          : this.state === BossState.DEFEATED
          ? 'DEATH'
          : this.state;
      this.glbCtrl.update(dt, animKey, elapsed, this.state === BossState.APPROACH);
      if (this.visualGroup) {
        this.visualGroup.rotation.x = this.state !== BossState.DEFEATED && recoilProg > 0 ? -recoilProg * 0.08 : 0;
      }
    }
  }

  _chooseNextAttack(dist) {
    const pool =
      dist > 7.5
        ? [BossAttackType.FORWARD_DASH, BossAttackType.GROUND_SHOCKWAVE]
        : [BossAttackType.BASIC_SWING, BossAttackType.HEAVY_OVERHEAD, BossAttackType.GROUND_SHOCKWAVE, BossAttackType.FORWARD_DASH];
    if (this.phase === 2) {
      pool.push(BossAttackType.PHASE2_ERUPTION);
      if (dist <= 5.0) pool.push(BossAttackType.BASIC_SWING);
    }
    let idx = Math.floor(Math.random() * pool.length);
    if (idx === this.lastAttackIndex && pool.length > 1) idx = (idx + 1) % pool.length;
    this.lastAttackIndex = idx;
    this.currentAttack = pool[idx];
  }

  _resetPose(b) {
    const r = this.rig;
    r.hips.position.y = THREE.MathUtils.lerp(r.hips.position.y, 1.85, b);
    r.hips.rotation.set(THREE.MathUtils.lerp(r.hips.rotation.x, 0, b), THREE.MathUtils.lerp(r.hips.rotation.y, 0, b), 0);
    r.torso.rotation.set(THREE.MathUtils.lerp(r.torso.rotation.x, 0.08, b), THREE.MathUtils.lerp(r.torso.rotation.y, 0, b), 0);
    r.head.rotation.set(0, 0, 0);
    r.leftShoulder.rotation.set(THREE.MathUtils.lerp(r.leftShoulder.rotation.x, -0.25, b), 0, 0.25);
    r.rightShoulder.rotation.set(THREE.MathUtils.lerp(r.rightShoulder.rotation.x, -0.4, b), 0, -0.28);
    r.weaponGroup.rotation.set(Math.PI * 0.46, 0, 0);
    r.leftHip.group.rotation.x = THREE.MathUtils.lerp(r.leftHip.group.rotation.x, 0, b);
    r.rightHip.group.rotation.x = THREE.MathUtils.lerp(r.rightHip.group.rotation.x, 0, b);
    r.leftHip.shin.rotation.x = THREE.MathUtils.lerp(r.leftHip.shin.rotation.x, 0.08, b);
    r.rightHip.shin.rotation.x = THREE.MathUtils.lerp(r.rightHip.shin.rotation.x, 0.08, b);
  }

  _animateLimbs(dt, elapsed, speedScale) {
    const r = this.rig;
    const b = Math.min(1, dt * 12);

    if (this.state === BossState.IDLE) {
      this._resetPose(b);
      const breath = Math.sin(elapsed * 1.8);
      r.hips.position.y = 1.85 + breath * 0.035;
      r.torso.rotation.x = 0.08 + breath * 0.032;
      r.head.rotation.y = Math.sin(elapsed * 0.9) * 0.06;
      r.cloak.rotation.x = 0.14 + Math.sin(elapsed * 2.5) * 0.055;
    } else if (this.state === BossState.APPROACH) {
      const t = elapsed * 4.8 * speedScale;
      const stride = Math.sin(t) * 0.48;
      r.hips.position.y = 1.82 + Math.abs(Math.cos(t)) * 0.1;
      r.torso.rotation.x = 0.2;
      r.torso.rotation.y = -stride * 0.24;
      r.head.rotation.x = -0.08;
      r.leftHip.group.rotation.x = stride;
      r.rightHip.group.rotation.x = -stride;
      r.leftHip.shin.rotation.x = Math.max(0.1, -Math.cos(t) * 0.58);
      r.rightHip.shin.rotation.x = Math.max(0.1, Math.cos(t) * 0.58);
      r.leftShoulder.rotation.set(-stride * 0.42 - 0.2, 0, 0.25);
      r.rightShoulder.rotation.set(stride * 0.35 - 0.45, 0, -0.32);
      r.weaponGroup.rotation.set(Math.PI * 0.55, 0, 0.18);
      r.cloak.rotation.x = 0.36 + Math.sin(t * 2) * 0.08;
    } else if (this.state === BossState.ATTACK_WINDUP) {
      const spec = ATTACK_SPECS[this.currentAttack];
      const p = Math.min(1, this.stateTime / (spec.windup / speedScale));
      if (this.currentAttack === BossAttackType.BASIC_SWING) {
        r.torso.rotation.y = -0.88 * p;
        r.rightShoulder.rotation.set(-1.15 * p, -1.1 * p, -0.8 * p);
        r.weaponGroup.rotation.set(Math.PI * 0.5, 0, -0.4);
      } else if (
        this.currentAttack === BossAttackType.HEAVY_OVERHEAD ||
        this.currentAttack === BossAttackType.GROUND_SHOCKWAVE ||
        this.currentAttack === BossAttackType.PHASE2_ERUPTION
      ) {
        r.hips.position.y = 1.85 + p * 0.16;
        r.torso.rotation.x = -0.38 * p;
        r.rightShoulder.rotation.set(-2.68 * p, 0, -0.2);
        r.leftShoulder.rotation.set(-2.15 * p, 0.3, 0.2);
        r.weaponGroup.rotation.set(Math.PI * 0.28, 0, 0);
      } else if (this.currentAttack === BossAttackType.FORWARD_DASH) {
        r.hips.position.y = 1.55;
        r.torso.rotation.x = 0.46 * p;
        r.rightShoulder.rotation.set(0.65 * p, 0, -0.45);
        r.weaponGroup.rotation.set(Math.PI * 0.55, 0, 0);
      }
      r.cloak.rotation.x = 0.24 + p * 0.2;
    } else if (this.state === BossState.ATTACK) {
      const spec = ATTACK_SPECS[this.currentAttack];
      const p = Math.min(1, this.stateTime / (spec.active / speedScale));
      const s = THREE.MathUtils.smoothstep(p, 0.0, 0.55);
      if (this.currentAttack === BossAttackType.BASIC_SWING) {
        r.torso.rotation.y = THREE.MathUtils.lerp(-0.88, 1.08, s);
        r.rightShoulder.rotation.set(-0.9, THREE.MathUtils.lerp(-1.1, 1.32, s), -0.6);
      } else if (this.currentAttack === BossAttackType.FORWARD_DASH) {
        r.hips.position.y = 1.62;
        r.torso.rotation.x = 0.52;
        r.rightShoulder.rotation.set(-1.35, 0, -0.15);
        r.weaponGroup.rotation.set(Math.PI * 0.52, 0, 0);
      } else {
        r.hips.position.y = 1.62;
        r.torso.rotation.x = THREE.MathUtils.lerp(-0.38, 0.65, s);
        r.rightShoulder.rotation.set(THREE.MathUtils.lerp(-2.68, -0.1, s), 0, -0.2);
        r.leftShoulder.rotation.set(THREE.MathUtils.lerp(-2.15, -0.3, s), 0.2, 0.2);
      }
      r.cloak.rotation.x = 0.58;
    } else if (this.state === BossState.RECOVERY) {
      this._resetPose(b * 0.7);
      r.torso.rotation.x = 0.28;
    } else if (this.state === BossState.STUNNED) {
      const sway = Math.sin(elapsed * 4.5);
      r.hips.position.y = THREE.MathUtils.lerp(r.hips.position.y, 1.45, b);
      r.torso.rotation.x = 0.48 + Math.abs(sway) * 0.05;
      r.torso.rotation.z = sway * 0.06;
      r.head.rotation.x = 0.35;
      r.leftShoulder.rotation.set(-0.2, 0, 0.55);
      r.rightShoulder.rotation.set(-0.15, 0, -0.55);
      r.leftHip.group.rotation.x = -0.65;
      r.leftHip.shin.rotation.x = 1.05;
    } else if (this.state === BossState.ENRAGED) {
      if (this.stateTime < 0.9) {
        const p = this.stateTime / 0.9;
        r.hips.position.y = 1.85 - p * 0.45;
        r.torso.rotation.x = 0.45 * p;
        r.rightShoulder.rotation.set(-0.6, 0, -0.4);
        r.leftShoulder.rotation.set(-0.6, 0, 0.4);
      } else {
        const p = Math.min(1, (this.stateTime - 0.9) / 0.8);
        r.hips.position.y = 1.4 + p * 0.5;
        r.torso.rotation.x = -0.42 * p;
        r.head.rotation.x = -0.35 * p;
        r.rightShoulder.rotation.set(-2.3 * p, 0, -0.65);
        r.leftShoulder.rotation.set(-2.0 * p, 0, 0.65);
      }
    } else if (this.state === BossState.DEFEATED) {
      const p = Math.min(1, this.stateTime / 1.35);
      const ease = p * p * (3 - 2 * p);
      r.hips.position.y = THREE.MathUtils.lerp(1.85, 0.38, ease);
      r.hips.rotation.x = THREE.MathUtils.lerp(0, 1.42, ease);
      r.materials.moltenMat.emissiveIntensity = Math.max(0.05, 2.2 * (1 - ease));
      r.bossLight.intensity = Math.max(0, 4.0 * (1 - ease));
    }
  }

  clearTransientEffects() {
    this.hitFlashTimer = 0;
    this.trail?.update(false);
    if (this.rig) {
      this.rig.materials.bodyArmorMat.emissive.setHex(0x000000);
      this.rig.materials.bodyArmorMat.emissiveIntensity = 0;
    } else {
      for (const m of this.trackedMaterials) {
        if (!m || !m.emissive || m.name === 'Glow' || m.name === 'RuneGlowMat') continue;
        m.emissive.setHex(0x000000);
        m.emissiveIntensity = 0;
      }
    }
  }

  dispose() {
    this._clearVisual();
    this.trail?.dispose?.();
    if (this.contactAura) {
      this.root.remove(this.contactAura);
      this.contactAura.geometry?.dispose?.();
      this.contactAura.material?.dispose?.();
      this.contactAura = null;
    }
    if (this.bossAuraRing) {
      this.root.remove(this.bossAuraRing);
      this.bossAuraRing.geometry?.dispose?.();
      this.bossAuraRing.material?.dispose?.();
      this.bossAuraRing = null;
    }
    if (this.darkEnergyAura) {
      this.root.remove(this.darkEnergyAura);
      this.darkEnergyAura.geometry?.dispose?.();
      this.darkEnergyAura.material?.dispose?.();
      this.darkEnergyAura = null;
    }
    if (this.phase2CrownRing) {
      this.root.remove(this.phase2CrownRing);
      this.phase2CrownRing.geometry?.dispose?.();
      this.phase2CrownRing.material?.dispose?.();
      this.phase2CrownRing = null;
    }
    this.scene.remove(this.root);
  }
}

function lerpAngle(a, b, t) {
  let diff = ((b - a + Math.PI) % (Math.PI * 2)) - Math.PI;
  if (diff < -Math.PI) diff += Math.PI * 2;
  return a + diff * t;
}

function pointToSegmentDistSq2D(px, pz, ax, az, bx, bz) {
  const vx = bx - ax;
  const vz = bz - az;
  const lenSq = vx * vx + vz * vz;
  if (lenSq < 0.000001) {
    const dx = px - ax;
    const dz = pz - az;
    return dx * dx + dz * dz;
  }
  const t = Math.max(0, Math.min(1, ((px - ax) * vx + (pz - az) * vz) / lenSq));
  const cx = ax + vx * t;
  const cz = az + vz * t;
  const dx = px - cx;
  const dz = pz - cz;
  return dx * dx + dz * dz;
}
