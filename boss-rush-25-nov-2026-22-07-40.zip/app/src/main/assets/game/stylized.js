import * as THREE from 'three';

let sharedToonMap = null;
let sharedAuraTex = null;

export function getCartoonGradientMap() {
  if (sharedToonMap) return sharedToonMap;
  // Crisp 4-band cel-shaded gradient ramp for vibrant Stylized 3D Cartoon look
  const colors = new Uint8Array([
    72, 72, 86, 255,
    136, 136, 152, 255,
    210, 210, 222, 255,
    255, 255, 255, 255,
  ]);
  const tex = new THREE.DataTexture(colors, 4, 1, THREE.RGBAFormat);
  tex.minFilter = THREE.NearestFilter;
  tex.magFilter = THREE.NearestFilter;
  tex.generateMipmaps = false;
  tex.needsUpdate = true;
  tex.userData = { ...(tex.userData || {}), shared: true };
  sharedToonMap = tex;
  return tex;
}

export function getContactAuraTexture() {
  if (sharedAuraTex) return sharedAuraTex;
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 256;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  const half = size / 2;
  // Dense grounded contact-AO shadow at feet + crisp outer dark-fantasy aura halo
  const g = ctx.createRadialGradient(half, half, 4, half, half, half);
  g.addColorStop(0.0, 'rgba(0, 0, 0, 0.82)');
  g.addColorStop(0.42, 'rgba(0, 0, 0, 0.52)');
  g.addColorStop(0.62, 'rgba(0, 0, 0, 0.16)');
  g.addColorStop(0.74, 'rgba(255, 255, 255, 0.45)');
  g.addColorStop(0.84, 'rgba(255, 255, 255, 0.92)');
  g.addColorStop(0.92, 'rgba(255, 255, 255, 0.25)');
  g.addColorStop(1.0, 'rgba(255, 255, 255, 0.0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);

  // Subtle geometric rune tick marks around the perimeter
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.65)';
  ctx.lineWidth = 2.0;
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(half + Math.cos(a) * half * 0.72, half + Math.sin(a) * half * 0.72);
    ctx.lineTo(half + Math.cos(a) * half * 0.89, half + Math.sin(a) * half * 0.89);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.userData = { ...(tex.userData || {}), shared: true };
  sharedAuraTex = tex;
  return tex;
}

export function createContactAuraMesh(colorHex = 0x52d6ff, radius = 0.95, opacity = 0.64) {
  const tex = getContactAuraTexture();
  const geo = new THREE.PlaneGeometry(radius * 2, radius * 2);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshBasicMaterial({
    color: colorHex,
    map: tex || null,
    transparent: true,
    opacity: tex ? opacity : opacity * 0.28,
    depthWrite: false,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = 0.025;
  mesh.renderOrder = 1;
  return mesh;
}

export function createCharacterAuraRing(colorHex = 0x52d6ff, innerR = 0.78, outerR = 0.96, opacity = 0.38) {
  const geo = new THREE.RingGeometry(innerR, outerR, 36);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshBasicMaterial({
    color: colorHex,
    transparent: true,
    opacity,
    side: THREE.DoubleSide,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = 0.042;
  mesh.renderOrder = 2;
  return mesh;
}

let sharedDarkAuraTex = null;

export function getDarkEnergyAuraTexture() {
  if (sharedDarkAuraTex) return sharedDarkAuraTex;
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 256;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  const half = size / 2;
  const g = ctx.createRadialGradient(half, half, 8, half, half, half);
  g.addColorStop(0.0, 'rgba(8, 4, 14, 0.92)');
  g.addColorStop(0.45, 'rgba(26, 10, 42, 0.72)');
  g.addColorStop(0.74, 'rgba(64, 18, 52, 0.34)');
  g.addColorStop(1.0, 'rgba(12, 6, 18, 0.0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);

  ctx.strokeStyle = 'rgba(120, 32, 64, 0.45)';
  ctx.lineWidth = 2.4;
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(half + Math.cos(a) * half * 0.48, half + Math.sin(a) * half * 0.48);
    ctx.lineTo(half + Math.cos(a + 0.16) * half * 0.88, half + Math.sin(a + 0.16) * half * 0.88);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.userData = { ...(tex.userData || {}), shared: true };
  sharedDarkAuraTex = tex;
  return tex;
}

export function createDarkEnergyAuraMesh(radius = 2.25, opacity = 0.72) {
  const tex = getDarkEnergyAuraTexture();
  const geo = new THREE.PlaneGeometry(radius * 2, radius * 2);
  geo.rotateX(-Math.PI / 2);
  const mat = new THREE.MeshBasicMaterial({
    color: 0xffffff,
    map: tex || null,
    transparent: true,
    opacity: tex ? opacity : opacity * 0.35,
    depthWrite: false,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = 0.032;
  mesh.renderOrder = 1;
  return mesh;
}

export function applyStylizedRimShader(mat, rimColorHex = 0x70c8ff, rimStrength = 0.52) {
  if (!mat || !mat.isMeshStandardMaterial || mat.userData?.hasStylizedRim) return mat;
  const rimCol = new THREE.Color(rimColorHex);
  mat.userData.hasStylizedRim = true;
  mat.userData.rimColor = rimCol;
  mat.userData.rimStrength = rimStrength;
  mat.customProgramCacheKey = () => 'stylized-rim-v2';
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uRimColor = { value: mat.userData.rimColor };
    shader.uniforms.uRimStrength = { value: mat.userData.rimStrength };
    mat.userData.rimUniforms = shader.uniforms;

    shader.fragmentShader =
      `uniform vec3 uRimColor;\nuniform float uRimStrength;\n` +
      shader.fragmentShader.replace(
        '#include <dithering_fragment>',
        `
        vec3 rimViewDir = normalize(vViewPosition);
        vec3 rimNorm = normalize(normal);
        float hemiAO = mix(0.74, 1.05, clamp(rimNorm.y * 0.5 + 0.5, 0.0, 1.0));
        gl_FragColor.rgb *= hemiAO;
        float rimDot = 1.0 - clamp(abs(dot(rimNorm, rimViewDir)), 0.0, 1.0);
        float rimBand = smoothstep(0.36, 0.92, rimDot) * (0.45 + 0.55 * pow(rimDot, 1.8));
        gl_FragColor.rgb += uRimColor * (rimBand * uRimStrength);
        #include <dithering_fragment>
        `
      );
  };
  mat.needsUpdate = true;
  return mat;
}

export function updateRimShaderUniforms(materials, rimColorHex, rimStrength) {
  if (!materials) return;
  for (const m of materials) {
    if (!m || !m.userData?.hasStylizedRim) continue;
    if (m.userData.rimColor) m.userData.rimColor.setHex(rimColorHex);
    if (typeof rimStrength === 'number') {
      m.userData.rimStrength = rimStrength;
      if (m.userData.rimUniforms?.uRimStrength) {
        m.userData.rimUniforms.uRimStrength.value = rimStrength;
      }
    }
  }
}

export function makeToonMat(colorHex, opts = {}) {
  const isGlowing = (opts.emissive ?? 0) !== 0 && (opts.emissiveIntensity ?? 1.0) > 1.0;
  const mat = new THREE.MeshStandardMaterial({
    color: colorHex,
    roughness: opts.roughness ?? (isGlowing ? 0.2 : 0.36),
    metalness: opts.metalness ?? (isGlowing ? 0.18 : 0.56),
    envMapIntensity: opts.envMapIntensity ?? 1.45,
    emissive: opts.emissive ?? 0x000000,
    emissiveIntensity: opts.emissiveIntensity ?? 1.0,
    side: opts.side ?? THREE.FrontSide,
    transparent: opts.transparent ?? false,
    opacity: opts.opacity ?? 1.0,
  });
  if (!isGlowing && opts.rimColor !== false) {
    applyStylizedRimShader(mat, opts.rimColor ?? 0x7cb8ff, opts.rimStrength ?? 0.42);
  }
  return mat;
}

export function addInkOutline(mesh, scale = 1.06, colorHex = 0x0b080d) {
  if (!mesh || !mesh.geometry) return null;
  const outlineMat = new THREE.MeshBasicMaterial({
    color: colorHex,
    side: THREE.BackSide,
  });
  const outline = new THREE.Mesh(mesh.geometry, outlineMat);
  outline.scale.setScalar(scale);
  outline.castShadow = false;
  outline.receiveShadow = false;
  mesh.add(outline);
  return outline;
}

// Sculpted Stylized 3D Cartoon Player Knight (returns articulated rig matching PlayerCharacter)
export function buildStylizedPlayerRig(presetId = 'vanguard') {
  const isCrimson = presetId === 'crimson_paladin';
  const rimCol = isCrimson ? 0xffaa44 : 0x6ce5ff;
  const root = new THREE.Group();

  const armorMat = makeToonMat(isCrimson ? 0xa3262c : 0x4c6b94, {
    roughness: 0.28,
    metalness: 0.68,
    envMapIntensity: 1.7,
    rimColor: rimCol,
    rimStrength: 0.54,
  });
  const darkTrimMat = makeToonMat(isCrimson ? 0x2a1b22 : 0x222636, {
    roughness: 0.36,
    metalness: 0.62,
    envMapIntensity: 1.45,
    rimColor: rimCol,
    rimStrength: 0.32,
  });
  const goldMat = makeToonMat(isCrimson ? 0xf7cc5e : 0xf4b644, {
    emissive: 0x3b2205,
    emissiveIntensity: 0.38,
    roughness: 0.22,
    metalness: 0.9,
    envMapIntensity: 1.85,
    rimColor: 0xffe49e,
    rimStrength: 0.35,
  });
  const capeMat = makeToonMat(isCrimson ? 0xede2d4 : 0xc42830, {
    side: THREE.DoubleSide,
    roughness: 0.68,
    metalness: 0.08,
    rimColor: isCrimson ? 0xffc888 : 0xff6b6b,
    rimStrength: 0.35,
  });
  const eyeMat = new THREE.MeshBasicMaterial({ color: isCrimson ? 0xffe47a : 0x62f2ff });
  const bladeMat = makeToonMat(0xe6f1ff, {
    emissive: isCrimson ? 0xffaa33 : 0x3ba8ff,
    emissiveIntensity: 0.56,
    roughness: 0.16,
    metalness: 0.92,
    envMapIntensity: 1.9,
  });

  // Hips / Pelvis
  const hips = new THREE.Group();
  hips.position.y = 0.96;
  root.add(hips);

  const pelvis = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.21, 0.22, 12), darkTrimMat);
  pelvis.castShadow = true;
  addInkOutline(pelvis, 1.07);
  hips.add(pelvis);

  // Stylized armored tassets + gold trim edge
  [-0.22, 0.22].forEach((tx) => {
    const tasset = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.15, 4, 8), armorMat);
    tasset.position.set(tx, -0.07, 0);
    tasset.rotation.z = tx < 0 ? 0.24 : -0.24;
    tasset.castShadow = true;
    addInkOutline(tasset, 1.08);
    hips.add(tasset);
  });

  // Torso
  const torso = new THREE.Group();
  torso.position.y = 0.12;
  hips.add(torso);

  const waist = new THREE.Mesh(new THREE.CylinderGeometry(0.21, 0.18, 0.22, 12), darkTrimMat);
  waist.position.y = 0.11;
  torso.add(waist);

  // Heroic V-tapered stylized breastplate
  const chest = new THREE.Mesh(new THREE.CylinderGeometry(0.33, 0.21, 0.43, 14), armorMat);
  chest.scale.set(1.16, 1, 0.84);
  chest.position.y = 0.38;
  chest.castShadow = true;
  addInkOutline(chest, 1.06);
  torso.add(chest);

  const chestCrest = new THREE.Mesh(new THREE.OctahedronGeometry(0.115, 0), goldMat);
  chestCrest.scale.set(0.88, 1.38, 0.48);
  chestCrest.position.set(0, 0.4, 0.26);
  torso.add(chestCrest);

  const chestCore = new THREE.Mesh(new THREE.OctahedronGeometry(0.055, 0), eyeMat);
  chestCore.position.set(0, 0.4, 0.295);
  torso.add(chestCore);

  const belt = new THREE.Mesh(new THREE.CylinderGeometry(0.235, 0.235, 0.085, 12), goldMat);
  belt.position.y = 0.16;
  torso.add(belt);

  const gorget = new THREE.Mesh(new THREE.TorusGeometry(0.185, 0.055, 8, 16), goldMat);
  gorget.rotation.x = Math.PI / 2;
  gorget.position.y = 0.59;
  torso.add(gorget);

  // Flowing Heroic Cape with gold clasp
  const cape = new THREE.Group();
  cape.position.set(0, 0.57, -0.2);
  const capeGeo = new THREE.PlaneGeometry(0.7, 1.14, 4, 6);
  capeGeo.translate(0, -0.57, 0);
  const capeMesh = new THREE.Mesh(capeGeo, capeMat);
  capeMesh.rotation.x = 0.16;
  capeMesh.castShadow = true;
  cape.add(capeMesh);
  torso.add(cape);

  // Stylized Knight Helmet with glowing visor eyes & dynamic plume
  const head = new THREE.Group();
  head.position.y = 0.67;
  torso.add(head);

  const helm = new THREE.Mesh(new THREE.CapsuleGeometry(0.175, 0.12, 6, 12), armorMat);
  helm.position.y = 0.19;
  helm.castShadow = true;
  addInkOutline(helm, 1.07);
  head.add(helm);

  const browGuard = new THREE.Mesh(new THREE.TorusGeometry(0.17, 0.034, 6, 14, Math.PI), goldMat);
  browGuard.position.set(0, 0.21, 0.03);
  browGuard.rotation.x = 0.2;
  head.add(browGuard);

  // Side helm winglet fins
  [-1, 1].forEach((side) => {
    const wing = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.18, 4), goldMat);
    wing.position.set(side * 0.18, 0.26, -0.02);
    wing.rotation.z = -side * 0.55;
    wing.rotation.x = -0.35;
    head.add(wing);
  });

  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.1, 0.12), darkTrimMat);
  visor.position.set(0, 0.16, 0.12);
  head.add(visor);

  [-0.055, 0.055].forEach((ex) => {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.026, 8, 6), eyeMat);
    eye.scale.set(1.35, 0.7, 0.7);
    eye.position.set(ex, 0.165, 0.18);
    head.add(eye);
  });

  // Sweeping stylized crest plume
  const plumeCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0.36, 0.02),
    new THREE.Vector3(0, 0.5, -0.14),
    new THREE.Vector3(0, 0.35, -0.37),
  ]);
  const plume = new THREE.Mesh(new THREE.TubeGeometry(plumeCurve, 10, 0.054, 8, false), capeMat);
  plume.castShadow = true;
  addInkOutline(plume, 1.08);
  head.add(plume);

  // Left Arm + Rounded Stylized Heater Shield
  const leftShoulder = new THREE.Group();
  leftShoulder.position.set(-0.38, 0.54, 0);
  torso.add(leftShoulder);

  const lPauldron = new THREE.Mesh(new THREE.SphereGeometry(0.175, 10, 8), armorMat);
  lPauldron.scale.set(1.24, 0.92, 1.12);
  lPauldron.castShadow = true;
  addInkOutline(lPauldron, 1.08);
  leftShoulder.add(lPauldron);

  const lPauldronTrim = new THREE.Mesh(new THREE.TorusGeometry(0.145, 0.026, 6, 12), goldMat);
  lPauldronTrim.rotation.y = Math.PI / 2;
  lPauldronTrim.position.y = -0.02;
  leftShoulder.add(lPauldronTrim);

  const lPauldronFin = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.18, 4), goldMat);
  lPauldronFin.position.set(-0.1, 0.14, 0);
  lPauldronFin.rotation.z = 0.55;
  leftShoulder.add(lPauldronFin);

  const lUpper = new THREE.Mesh(new THREE.CapsuleGeometry(0.065, 0.18, 4, 8), darkTrimMat);
  lUpper.position.y = -0.15;
  leftShoulder.add(lUpper);

  const leftForearm = new THREE.Group();
  leftForearm.position.y = -0.29;
  leftShoulder.add(leftForearm);

  const lGauntlet = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.18, 4, 8), armorMat);
  lGauntlet.position.y = -0.14;
  lGauntlet.castShadow = true;
  addInkOutline(lGauntlet, 1.08);
  leftForearm.add(lGauntlet);

  // Stylized Kite Shield
  const shieldGroup = new THREE.Group();
  shieldGroup.position.set(-0.12, -0.14, 0.06);
  shieldGroup.rotation.y = -Math.PI * 0.45;
  leftForearm.add(shieldGroup);

  const shieldRim = new THREE.Mesh(new THREE.CylinderGeometry(0.33, 0.24, 0.06, 6), goldMat);
  shieldRim.rotation.x = Math.PI / 2;
  shieldRim.scale.set(0.88, 1, 1.2);
  shieldRim.castShadow = true;
  addInkOutline(shieldRim, 1.06);
  shieldGroup.add(shieldRim);

  const shieldFace = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.2, 0.075, 6), armorMat);
  shieldFace.rotation.x = Math.PI / 2;
  shieldFace.scale.set(0.86, 1, 1.18);
  shieldGroup.add(shieldFace);

  const shieldBoss = new THREE.Mesh(new THREE.OctahedronGeometry(0.085, 0), eyeMat);
  shieldBoss.scale.set(0.9, 1.25, 0.6);
  shieldBoss.position.z = 0.045;
  shieldGroup.add(shieldBoss);

  // Right Arm + Stylized Hero Broadsword
  const rightShoulder = new THREE.Group();
  rightShoulder.position.set(0.38, 0.54, 0);
  torso.add(rightShoulder);

  const rPauldron = new THREE.Mesh(new THREE.SphereGeometry(0.175, 10, 8), armorMat);
  rPauldron.scale.set(1.24, 0.92, 1.12);
  rPauldron.castShadow = true;
  addInkOutline(rPauldron, 1.08);
  rightShoulder.add(rPauldron);

  const rPauldronTrim = new THREE.Mesh(new THREE.TorusGeometry(0.145, 0.026, 6, 12), goldMat);
  rPauldronTrim.rotation.y = Math.PI / 2;
  rPauldronTrim.position.y = -0.02;
  rightShoulder.add(rPauldronTrim);

  const rPauldronFin = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.18, 4), goldMat);
  rPauldronFin.position.set(0.1, 0.14, 0);
  rPauldronFin.rotation.z = -0.55;
  rightShoulder.add(rPauldronFin);

  const rUpper = new THREE.Mesh(new THREE.CapsuleGeometry(0.065, 0.18, 4, 8), darkTrimMat);
  rUpper.position.y = -0.15;
  rightShoulder.add(rUpper);

  const rightForearm = new THREE.Group();
  rightForearm.position.y = -0.29;
  rightShoulder.add(rightForearm);

  const rGauntlet = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.18, 4, 8), armorMat);
  rGauntlet.position.y = -0.14;
  rGauntlet.castShadow = true;
  addInkOutline(rGauntlet, 1.08);
  rightForearm.add(rGauntlet);

  const weaponGroup = new THREE.Group();
  weaponGroup.position.set(0, -0.26, 0.07);
  weaponGroup.rotation.x = Math.PI * 0.45;
  rightForearm.add(weaponGroup);

  const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.028, 0.28, 8), darkTrimMat);
  weaponGroup.add(grip);

  const pommel = new THREE.Mesh(new THREE.OctahedronGeometry(0.06, 0), goldMat);
  pommel.position.y = -0.16;
  weaponGroup.add(pommel);

  const guard = new THREE.Mesh(new THREE.CapsuleGeometry(0.036, 0.36, 4, 8), goldMat);
  guard.rotation.z = Math.PI / 2;
  guard.position.y = 0.15;
  addInkOutline(guard, 1.1);
  weaponGroup.add(guard);

  const blade = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.26, 0.032), bladeMat);
  blade.position.y = 0.79;
  blade.castShadow = true;
  addInkOutline(blade, 1.07);
  weaponGroup.add(blade);

  const bladeCore = new THREE.Mesh(new THREE.BoxGeometry(0.038, 1.12, 0.042), eyeMat);
  bladeCore.position.y = 0.78;
  weaponGroup.add(bladeCore);

  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.068, 0.28, 4), bladeMat);
  tip.position.y = 1.54;
  tip.rotation.y = Math.PI / 4;
  weaponGroup.add(tip);

  const swordBaseMarker = new THREE.Object3D();
  swordBaseMarker.position.set(0, 0.24, 0);
  weaponGroup.add(swordBaseMarker);

  const swordTipMarker = new THREE.Object3D();
  swordTipMarker.position.set(0, 1.64, 0);
  weaponGroup.add(swordTipMarker);

  // Legs
  const buildLeg = (x) => {
    const group = new THREE.Group();
    group.position.set(x, -0.08, 0);
    const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.088, 0.26, 4, 8), armorMat);
    thigh.position.y = -0.21;
    thigh.castShadow = true;
    addInkOutline(thigh, 1.08);
    group.add(thigh);

    const shin = new THREE.Group();
    shin.position.y = -0.42;
    group.add(shin);

    const knee = new THREE.Mesh(new THREE.OctahedronGeometry(0.09, 0), goldMat);
    knee.position.z = 0.04;
    shin.add(knee);

    const greave = new THREE.Mesh(new THREE.CapsuleGeometry(0.078, 0.26, 4, 8), armorMat);
    greave.position.y = -0.21;
    greave.castShadow = true;
    addInkOutline(greave, 1.08);
    shin.add(greave);

    const boot = new THREE.Mesh(new THREE.CapsuleGeometry(0.074, 0.14, 4, 8), darkTrimMat);
    boot.rotation.x = Math.PI / 2;
    boot.position.set(0, -0.43, 0.055);
    boot.castShadow = true;
    addInkOutline(boot, 1.08);
    shin.add(boot);

    return { group, shin };
  };

  const leftHip = buildLeg(-0.14);
  const rightHip = buildLeg(0.14);
  hips.add(leftHip.group);
  hips.add(rightHip.group);

  return {
    root,
    hips,
    torso,
    head,
    cape,
    leftShoulder,
    leftForearm,
    rightShoulder,
    rightForearm,
    weaponGroup,
    leftHip,
    rightHip,
    swordBaseMarker,
    swordTipMarker,
    materials: { armorMat, bladeMat, goldMat },
  };
}

// Sculpted Stylized 3D Cartoon Monster-Knight Boss
export function buildStylizedBossRig(presetId = 'ashen_behemoth') {
  const isVoid = presetId === 'void_colossus';
  const rimHex = isVoid ? 0xb55cff : 0xff6a24;
  const root = new THREE.Group();

  const bodyArmorMat = makeToonMat(isVoid ? 0x2c1f42 : 0x28212b, {
    roughness: 0.3,
    metalness: 0.68,
    envMapIntensity: 1.68,
    rimColor: rimHex,
    rimStrength: 0.6,
  });
  const darkPlateMat = makeToonMat(isVoid ? 0x161124 : 0x151218, {
    roughness: 0.32,
    metalness: 0.72,
    envMapIntensity: 1.55,
    rimColor: rimHex,
    rimStrength: 0.38,
  });
  const skinMat = makeToonMat(isVoid ? 0x452b5e : 0x422422, { rimColor: rimHex, rimStrength: 0.44 });
  const moltenMat = makeToonMat(isVoid ? 0xaa4dff : 0xff5a1f, {
    emissive: isVoid ? 0x8f2eff : 0xff4510,
    emissiveIntensity: 2.6,
  });
  const cloakMat = makeToonMat(isVoid ? 0x22143a : 0x2a1216, {
    side: THREE.DoubleSide,
    roughness: 0.72,
    metalness: 0.08,
    rimColor: rimHex,
    rimStrength: 0.42,
  });

  const hips = new THREE.Group();
  hips.position.y = 1.85;
  root.add(hips);

  const pelvis = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.45, 0.48, 12), darkPlateMat);
  pelvis.scale.set(1.1, 1, 0.85);
  pelvis.castShadow = true;
  addInkOutline(pelvis, 1.06);
  hips.add(pelvis);

  [-0.5, 0.5].forEach((x) => {
    const fauld = new THREE.Mesh(new THREE.CapsuleGeometry(0.18, 0.42, 4, 8), bodyArmorMat);
    fauld.position.set(x, -0.22, 0);
    fauld.rotation.z = x < 0 ? 0.22 : -0.22;
    fauld.castShadow = true;
    addInkOutline(fauld, 1.07);
    hips.add(fauld);
  });

  const torso = new THREE.Group();
  torso.position.y = 0.24;
  hips.add(torso);

  const abdomen = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 0.42, 0.56, 12), skinMat);
  abdomen.position.y = 0.22;
  torso.add(abdomen);

  // Massive hunched cartoon monster-titan chest
  const chest = new THREE.Mesh(new THREE.SphereGeometry(0.78, 14, 10), bodyArmorMat);
  chest.scale.set(1.2, 0.94, 0.9);
  chest.position.y = 0.78;
  chest.castShadow = true;
  addInkOutline(chest, 1.05);
  torso.add(chest);

  // Glowing molten core & rib cracks
  const core = new THREE.Mesh(new THREE.OctahedronGeometry(0.25, 0), moltenMat);
  core.position.set(0, 0.82, 0.66);
  torso.add(core);

  [-0.38, 0.38].forEach((ang) => {
    const fissure = new THREE.Mesh(new THREE.CapsuleGeometry(0.048, 0.46, 4, 6), moltenMat);
    fissure.position.set(ang, 0.78, 0.62);
    fissure.rotation.z = ang * 1.15;
    torso.add(fissure);
  });

  // Jagged glowing dorsal spine spikes
  for (let s = 0; s < 3; s++) {
    const dorsal = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.5, 6), moltenMat);
    dorsal.position.set(0, 0.55 + s * 0.28, -0.64);
    dorsal.rotation.x = -0.9;
    torso.add(dorsal);
  }

  const bossLight = new THREE.PointLight(isVoid ? 0x9933ff : 0xff5518, 4.4, 14, 1.5);
  bossLight.position.set(0, 0.95, 0.9);
  torso.add(bossLight);

  const cloak = new THREE.Group();
  cloak.position.set(0, 1.15, -0.52);
  const cloakGeo = new THREE.PlaneGeometry(1.62, 2.4, 3, 5);
  cloakGeo.translate(0, -1.2, 0);
  const cloakMesh = new THREE.Mesh(cloakGeo, cloakMat);
  cloakMesh.rotation.x = 0.15;
  cloakMesh.castShadow = true;
  cloak.add(cloakMesh);
  torso.add(cloak);

  // Horned Monster Helm / Beast Head
  const head = new THREE.Group();
  head.position.set(0, 1.24, 0.14);
  torso.add(head);

  const skull = new THREE.Mesh(new THREE.SphereGeometry(0.32, 12, 10), darkPlateMat);
  skull.scale.set(1.05, 1.1, 1.12);
  skull.position.y = 0.25;
  skull.castShadow = true;
  addInkOutline(skull, 1.07);
  head.add(skull);

  // Floating volcanic / void warlord halo crest behind head
  const crownArc = new THREE.Mesh(new THREE.TorusGeometry(0.42, 0.032, 6, 16, Math.PI * 1.1), moltenMat);
  crownArc.position.set(0, 0.42, -0.14);
  crownArc.rotation.z = -Math.PI * 0.05;
  head.add(crownArc);

  // Fierce glowing cartoon beast eyes & jaw fangs
  [-0.12, 0.12].forEach((ex) => {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.058, 8, 6), moltenMat);
    eye.scale.set(1.45, 0.65, 0.8);
    eye.rotation.z = ex < 0 ? -0.35 : 0.35;
    eye.position.set(ex, 0.29, 0.29);
    head.add(eye);
  });

  [-0.1, 0.1].forEach((fx) => {
    const fang = new THREE.Mesh(new THREE.ConeGeometry(0.04, 0.14, 5), makeToonMat(0xe8dcc8));
    fang.position.set(fx, 0.08, 0.29);
    head.add(fang);
  });

  // Sweeping curved ram/demon horns
  [-1, 1].forEach((side) => {
    const hornCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(side * 0.22, 0.38, 0.02),
      new THREE.Vector3(side * 0.54, 0.68, -0.08),
      new THREE.Vector3(side * 0.42, 0.94, 0.16),
    ]);
    const horn = new THREE.Mesh(new THREE.TubeGeometry(hornCurve, 10, 0.078, 7, false), moltenMat);
    horn.castShadow = true;
    addInkOutline(horn, 1.07);
    head.add(horn);
  });

  // Muscular Cartoon Arms + Pauldrons
  const buildArm = (xPos, side) => {
    const shoulder = new THREE.Group();
    shoulder.position.set(xPos, 1.06, 0);
    torso.add(shoulder);

    const pauldron = new THREE.Mesh(new THREE.SphereGeometry(0.37, 10, 8), bodyArmorMat);
    pauldron.scale.set(1.26, 0.94, 1.15);
    pauldron.castShadow = true;
    addInkOutline(pauldron, 1.07);
    shoulder.add(pauldron);

    const hornSpike = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.54, 6), moltenMat);
    hornSpike.position.set(side * 0.22, 0.28, 0);
    hornSpike.rotation.z = -side * 0.6;
    shoulder.add(hornSpike);

    const pauldronRune = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.026, 6, 12), moltenMat);
    pauldronRune.rotation.y = Math.PI / 2;
    pauldronRune.position.set(side * 0.14, 0.02, 0);
    shoulder.add(pauldronRune);

    const upper = new THREE.Mesh(new THREE.CapsuleGeometry(0.15, 0.42, 4, 8), skinMat);
    upper.position.y = -0.34;
    addInkOutline(upper, 1.07);
    shoulder.add(upper);

    const forearm = new THREE.Group();
    forearm.position.y = -0.66;
    shoulder.add(forearm);

    const vambrace = new THREE.Mesh(new THREE.CapsuleGeometry(0.165, 0.4, 4, 8), darkPlateMat);
    vambrace.position.y = -0.3;
    vambrace.castShadow = true;
    addInkOutline(vambrace, 1.07);
    forearm.add(vambrace);

    return { shoulder, forearm };
  };

  const leftArm = buildArm(-0.88, -1);
  const rightArm = buildArm(0.88, 1);

  // Colossal Cartoon Demon Cleaver Greatsword
  const weaponGroup = new THREE.Group();
  weaponGroup.position.set(0, -0.58, 0.14);
  weaponGroup.rotation.x = Math.PI * 0.46;
  rightArm.forearm.add(weaponGroup);

  const hilt = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.58, 8), darkPlateMat);
  weaponGroup.add(hilt);

  const crossguard = new THREE.Mesh(new THREE.CapsuleGeometry(0.085, 0.74, 4, 8), bodyArmorMat);
  crossguard.rotation.z = Math.PI / 2;
  crossguard.position.y = 0.3;
  addInkOutline(crossguard, 1.08);
  weaponGroup.add(crossguard);

  const blade = new THREE.Mesh(new THREE.BoxGeometry(0.32, 2.78, 0.085), darkPlateMat);
  blade.position.y = 1.72;
  blade.castShadow = true;
  addInkOutline(blade, 1.06);
  weaponGroup.add(blade);

  const moltenEdge = new THREE.Mesh(new THREE.BoxGeometry(0.13, 2.62, 0.105), moltenMat);
  moltenEdge.position.set(0.1, 1.68, 0);
  weaponGroup.add(moltenEdge);

  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.19, 0.56, 4), moltenMat);
  tip.position.y = 3.36;
  tip.rotation.y = Math.PI / 4;
  weaponGroup.add(tip);

  const bladeBaseMarker = new THREE.Object3D();
  bladeBaseMarker.position.set(0, 0.45, 0);
  weaponGroup.add(bladeBaseMarker);

  const bladeTipMarker = new THREE.Object3D();
  bladeTipMarker.position.set(0, 3.48, 0);
  weaponGroup.add(bladeTipMarker);

  // Legs
  const buildLeg = (x) => {
    const group = new THREE.Group();
    group.position.set(x, -0.18, 0);

    const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.19, 0.52, 4, 8), bodyArmorMat);
    thigh.position.y = -0.42;
    thigh.castShadow = true;
    addInkOutline(thigh, 1.07);
    group.add(thigh);

    const shin = new THREE.Group();
    shin.position.y = -0.84;
    group.add(shin);

    const knee = new THREE.Mesh(new THREE.ConeGeometry(0.115, 0.3, 5), moltenMat);
    knee.rotation.x = Math.PI * 0.35;
    knee.position.z = 0.18;
    shin.add(knee);

    const greave = new THREE.Mesh(new THREE.CapsuleGeometry(0.16, 0.52, 4, 8), darkPlateMat);
    greave.position.y = -0.42;
    greave.castShadow = true;
    addInkOutline(greave, 1.07);
    shin.add(greave);

    const boot = new THREE.Mesh(new THREE.CapsuleGeometry(0.145, 0.24, 4, 8), darkPlateMat);
    boot.rotation.x = Math.PI / 2;
    boot.position.set(0, -0.82, 0.12);
    boot.castShadow = true;
    shin.add(boot);

    return { group, shin };
  };

  const leftHip = buildLeg(-0.32);
  const rightHip = buildLeg(0.32);
  hips.add(leftHip.group);
  hips.add(rightHip.group);

  return {
    root,
    hips,
    torso,
    head,
    cloak,
    leftShoulder: leftArm.shoulder,
    rightShoulder: rightArm.shoulder,
    weaponGroup,
    leftHip,
    rightHip,
    bladeBaseMarker,
    bladeTipMarker,
    bossLight,
    materials: { bodyArmorMat, moltenMat },
  };
}

// Stylized Cartoon Minion Builder ('cinder_imp' or 'obsidian_sentinel')
export function buildStylizedMinionRig(kind = 'cinder_imp') {
  const isSentinel = kind === 'obsidian_sentinel';
  const rimCol = isSentinel ? 0x52c4ff : 0xff7a2b;
  const root = new THREE.Group();

  const bodyMat = makeToonMat(isSentinel ? 0x3b4459 : 0xa32a1c, { rimColor: rimCol, rimStrength: 0.48 });
  const trimMat = makeToonMat(isSentinel ? 0xde9e44 : 0x261519, { rimColor: rimCol, rimStrength: 0.32 });
  const glowMat = makeToonMat(isSentinel ? 0x52c4ff : 0xffaa2b, {
    emissive: isSentinel ? 0x2c8cff : 0xff5a18,
    emissiveIntensity: 1.9,
  });

  const hips = new THREE.Group();
  hips.position.y = isSentinel ? 0.88 : 0.72;
  root.add(hips);

  const body = new THREE.Mesh(
    new THREE.SphereGeometry(isSentinel ? 0.36 : 0.26, 10, 8),
    bodyMat
  );
  body.scale.set(1.05, 1.25, 0.9);
  body.position.y = 0.26;
  body.castShadow = true;
  addInkOutline(body, 1.07);
  hips.add(body);

  const head = new THREE.Group();
  head.position.y = isSentinel ? 0.65 : 0.54;
  hips.add(head);

  const headMesh = new THREE.Mesh(
    new THREE.SphereGeometry(isSentinel ? 0.2 : 0.22, 10, 8),
    isSentinel ? trimMat : bodyMat
  );
  headMesh.position.y = 0.14;
  headMesh.castShadow = true;
  addInkOutline(headMesh, 1.08);
  head.add(headMesh);

  [-0.075, 0.075].forEach((ex) => {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.04, 6, 6), glowMat);
    eye.position.set(ex, 0.15, isSentinel ? 0.17 : 0.19);
    head.add(eye);
  });

  if (!isSentinel) {
    // Imp horns
    [-0.12, 0.12].forEach((hx) => {
      const horn = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.28, 5), glowMat);
      horn.position.set(hx, 0.34, 0.02);
      horn.rotation.z = hx < 0 ? 0.35 : -0.35;
      head.add(horn);
    });
  }

  const leftArm = new THREE.Group();
  leftArm.position.set(isSentinel ? -0.4 : -0.28, 0.42, 0);
  hips.add(leftArm);

  const lArmMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.24, 4, 6), bodyMat);
  lArmMesh.position.y = -0.15;
  addInkOutline(lArmMesh, 1.08);
  leftArm.add(lArmMesh);

  if (isSentinel) {
    // Tower shield on left arm with glowing rune boss
    const towerShield = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.85, 0.58), trimMat);
    towerShield.position.set(-0.08, -0.1, 0.16);
    towerShield.castShadow = true;
    addInkOutline(towerShield, 1.07);
    leftArm.add(towerShield);

    const shieldGlyph = new THREE.Mesh(new THREE.OctahedronGeometry(0.11, 0), glowMat);
    shieldGlyph.scale.set(0.35, 1.4, 0.9);
    shieldGlyph.position.set(-0.13, -0.1, 0.16);
    leftArm.add(shieldGlyph);
  }

  const rightArm = new THREE.Group();
  rightArm.position.set(isSentinel ? 0.4 : 0.28, 0.42, 0);
  hips.add(rightArm);

  const rArmMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.24, 4, 6), bodyMat);
  rArmMesh.position.y = -0.15;
  addInkOutline(rArmMesh, 1.08);
  rightArm.add(rArmMesh);

  const weapon = new THREE.Mesh(
    isSentinel ? new THREE.ConeGeometry(0.065, 1.18, 5) : new THREE.ConeGeometry(0.055, 0.52, 5),
    glowMat
  );
  weapon.rotation.x = Math.PI * 0.5;
  weapon.position.set(0, -0.25, isSentinel ? 0.45 : 0.22);
  rightArm.add(weapon);

  const buildLeg = (x) => {
    const leg = new THREE.Group();
    leg.position.set(x, -0.06, 0);
    const mesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.075, isSentinel ? 0.44 : 0.32, 4, 6), trimMat);
    mesh.position.y = isSentinel ? -0.26 : -0.2;
    mesh.castShadow = true;
    addInkOutline(mesh, 1.08);
    leg.add(mesh);
    return leg;
  };

  const leftLeg = buildLeg(isSentinel ? -0.16 : -0.12);
  const rightLeg = buildLeg(isSentinel ? 0.16 : 0.12);
  hips.add(leftLeg);
  hips.add(rightLeg);

  return { root, hips, head, leftArm, rightArm, leftLeg, rightLeg, bodyMat, glowMat };
}

// Equips CC0 Skeleton_Warrior / Skeleton_Minion GLBs with forged PBR weapon, armor ornaments & shield
export function equipSkeletonGLBArmory(modelRoot, variant = 'boss') {
  const handR = modelRoot.getObjectByName('handslot.r');
  const handL = modelRoot.getObjectByName('handslot.l');
  const headNode = modelRoot.getObjectByName('head');
  const isBoss = variant === 'boss';
  const isSentinel = variant === 'obsidian_sentinel';
  const rimCol = isSentinel ? 0x52c4ff : 0xff6a24;

  const steelMat = new THREE.MeshStandardMaterial({
    color: 0x33303e,
    roughness: 0.22,
    metalness: 0.94,
    envMapIntensity: 1.85,
  });
  applyStylizedRimShader(steelMat, rimCol, 0.6);

  const runeMat = new THREE.MeshStandardMaterial({
    name: 'RuneGlowMat',
    color: isSentinel ? 0x52c4ff : 0xff6a24,
    emissive: isSentinel ? 0x2c8cff : 0xff4810,
    emissiveIntensity: isBoss ? 3.4 : 2.1,
    roughness: 0.18,
    metalness: 0.25,
  });
  const goldMat = new THREE.MeshStandardMaterial({
    color: 0xe3ad4b,
    roughness: 0.2,
    metalness: 0.95,
    envMapIntensity: 1.9,
  });

  let swordBaseMarker = null;
  let swordTipMarker = null;

  if (handR) {
    const bladeLen = isBoss ? 1.62 : isSentinel ? 1.18 : 0.88;
    const bladeW = isBoss ? 0.19 : 0.115;
    const wGroup = new THREE.Group();
    wGroup.rotation.x = Math.PI * 0.5;

    const grip = new THREE.Mesh(new THREE.CylinderGeometry(0.032, 0.032, 0.34, 8), steelMat);
    wGroup.add(grip);

    const guard = new THREE.Mesh(new THREE.BoxGeometry(bladeW * 2.6, 0.065, 0.085), goldMat);
    guard.position.y = 0.16;
    wGroup.add(guard);

    if (isBoss) {
      [-1, 1].forEach((side) => {
        const wing = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.2, 4), goldMat);
        wing.position.set(side * bladeW * 1.25, 0.22, 0);
        wing.rotation.z = -side * 0.55;
        wGroup.add(wing);
      });
    }

    const blade = new THREE.Mesh(new THREE.BoxGeometry(bladeW, bladeLen, 0.042), steelMat);
    blade.position.y = 0.18 + bladeLen * 0.5;
    blade.castShadow = true;
    wGroup.add(blade);

    const core = new THREE.Mesh(new THREE.BoxGeometry(bladeW * 0.38, bladeLen * 0.92, 0.05), runeMat);
    core.position.y = 0.18 + bladeLen * 0.5;
    wGroup.add(core);

    const tip = new THREE.Mesh(new THREE.ConeGeometry(bladeW * 0.74, 0.28, 4), runeMat);
    tip.position.y = 0.18 + bladeLen + 0.12;
    tip.rotation.y = Math.PI / 4;
    wGroup.add(tip);

    swordBaseMarker = new THREE.Object3D();
    swordBaseMarker.name = 'SwordBase';
    swordBaseMarker.position.set(0, 0.22, 0);
    wGroup.add(swordBaseMarker);

    swordTipMarker = new THREE.Object3D();
    swordTipMarker.name = 'SwordTip';
    swordTipMarker.position.set(0, 0.18 + bladeLen + 0.24, 0);
    wGroup.add(swordTipMarker);

    handR.add(wGroup);
  }

  if (handL && (isSentinel || isBoss)) {
    const shGroup = new THREE.Group();
    const shieldBody = new THREE.Mesh(
      new THREE.CylinderGeometry(isBoss ? 0.46 : 0.39, isBoss ? 0.36 : 0.31, 0.075, 6),
      steelMat
    );
    shieldBody.rotation.z = Math.PI / 2;
    shieldBody.castShadow = true;
    shGroup.add(shieldBody);

    const bossRing = new THREE.Mesh(new THREE.TorusGeometry(isBoss ? 0.23 : 0.19, 0.032, 6, 12), runeMat);
    bossRing.rotation.y = Math.PI / 2;
    bossRing.position.x = -0.042;
    shGroup.add(bossRing);

    handL.add(shGroup);
  }

  if (headNode && isBoss) {
    // Warlord Iron & Molten Crown Horns on Skeleton_Warrior boss
    const crownBand = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.028, 6, 14), goldMat);
    crownBand.rotation.x = Math.PI / 2;
    crownBand.position.set(0, 0.34, 0);
    headNode.add(crownBand);

    [-1, 1].forEach((side) => {
      const horn = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.32, 5), runeMat);
      horn.position.set(side * 0.2, 0.46, 0.02);
      horn.rotation.z = -side * 0.45;
      horn.rotation.x = 0.2;
      headNode.add(horn);
    });
  }

  if (isBoss) {
    // Emissive armor rune details & forged silhouette pauldrons on Skeleton_Warrior boss
    const chestNode = modelRoot.getObjectByName('chest') || modelRoot.getObjectByName('spine');
    if (chestNode) {
      const chestSigil = new THREE.Mesh(new THREE.OctahedronGeometry(0.11, 0), runeMat);
      chestSigil.scale.set(0.95, 1.35, 0.45);
      chestSigil.position.set(0, 0.16, 0.22);
      chestNode.add(chestSigil);

      const collarRing = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.022, 6, 16), runeMat);
      collarRing.rotation.x = Math.PI / 2;
      collarRing.position.set(0, 0.32, 0);
      chestNode.add(collarRing);
    }

    ['upperarm.l', 'upperarm.r'].forEach((armName, idx) => {
      const armNode = modelRoot.getObjectByName(armName);
      if (!armNode) return;
      const side = idx === 0 ? -1 : 1;
      const pauldronCap = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 6), steelMat);
      pauldronCap.scale.set(1.2, 0.78, 1.1);
      pauldronCap.position.set(side * 0.04, 0.06, 0);
      armNode.add(pauldronCap);

      const armRune = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.02, 5, 12), runeMat);
      armRune.rotation.y = Math.PI / 2;
      armRune.position.set(side * 0.08, 0.06, 0);
      armNode.add(armRune);
    });
  }

  return { swordBaseMarker, swordTipMarker, runeMat };
}
