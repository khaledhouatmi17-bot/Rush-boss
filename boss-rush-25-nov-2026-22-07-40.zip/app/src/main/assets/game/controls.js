import * as THREE from 'three';

export class InputController {
  constructor(callbacks, canvasEl = null) {
    this.callbacks = callbacks; // { onLight, onHeavy, onDodge, onParry, onSkill, onLockToggle, onCameraOrbit, onAnyInput }
    this.canvasEl = canvasEl;
    this.keys = new Set();
    this.joyVector = { x: 0, y: 0 };
    this.joyPointerId = null;
    this.joyCenter = { x: 0, y: 0 };
    this.joyMaxRadius = 46;

    this.camPointerId = null;
    this.camLast = { x: 0, y: 0 };

    this.moveWorld = new THREE.Vector3();
    this.camForward = new THREE.Vector3();
    this.camRight = new THREE.Vector3();

    this.joystickZone = document.getElementById('joystick-zone');
    this.joystickBase = document.getElementById('joystick-base');
    this.joystickKnob = document.getElementById('joystick-knob');

    this.btnAttack = document.getElementById('btn-attack');
    this.btnHeavy = document.getElementById('btn-heavy');
    this.btnDodge = document.getElementById('btn-dodge');
    this.btnParry = document.getElementById('btn-parry');
    this.btnSkill = document.getElementById('btn-skill');
    this.btnLock = document.getElementById('btn-lock');

    this._boundHandlers = [];
    this._buttons = [];
    this._bindJoystick();
    this._bindCameraDrag();
    this._bindButton(this.btnAttack, 'onLight');
    this._bindButton(this.btnHeavy, 'onHeavy');
    this._bindButton(this.btnDodge, 'onDodge');
    this._bindButton(this.btnParry, 'onParry');
    this._bindButton(this.btnSkill, 'onSkill');
    this._bindButton(this.btnLock, 'onLockToggle');
    this._bindKeyboard();
  }

  _listen(target, type, fn, opts) {
    if (!target) return;
    target.addEventListener(type, fn, opts);
    this._boundHandlers.push({ target, type, fn, opts });
  }

  _bindJoystick() {
    const onDown = (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.callbacks.onAnyInput?.();
      if (this.joyPointerId !== null) return;
      this.joyPointerId = e.pointerId;
      const rect = this.joystickBase.getBoundingClientRect();
      this.joyCenter.x = rect.left + rect.width * 0.5;
      this.joyCenter.y = rect.top + rect.height * 0.5;
      this.joystickZone.setPointerCapture?.(e.pointerId);
      this._updateJoystick(e.clientX, e.clientY);
    };

    const onMove = (e) => {
      if (e.pointerId !== this.joyPointerId) return;
      e.preventDefault();
      this._updateJoystick(e.clientX, e.clientY);
    };

    const onUp = (e) => {
      if (e.pointerId !== this.joyPointerId) return;
      this.joyPointerId = null;
      this.joyVector.x = 0;
      this.joyVector.y = 0;
      this.joystickKnob.style.transform = 'translate3d(0px, 0px, 0)';
    };

    this._listen(this.joystickZone, 'pointerdown', onDown, { passive: false });
    this._listen(window, 'pointermove', onMove, { passive: false });
    this._listen(window, 'pointerup', onUp);
    this._listen(window, 'pointercancel', onUp);
  }

  _bindCameraDrag() {
    if (!this.canvasEl) return;
    const onDown = (e) => {
      if (this.joyPointerId === e.pointerId || this.camPointerId !== null) return;
      this.camPointerId = e.pointerId;
      this.camLast.x = e.clientX;
      this.camLast.y = e.clientY;
    };
    const onMove = (e) => {
      if (e.pointerId !== this.camPointerId) return;
      const dx = e.clientX - this.camLast.x;
      const dy = e.clientY - this.camLast.y;
      this.camLast.x = e.clientX;
      this.camLast.y = e.clientY;
      this.callbacks.onCameraOrbit?.(dx, dy);
    };
    const onUp = (e) => {
      if (e.pointerId === this.camPointerId) {
        this.camPointerId = null;
      }
    };
    this._listen(this.canvasEl, 'pointerdown', onDown, { passive: true });
    this._listen(window, 'pointermove', onMove, { passive: true });
    this._listen(window, 'pointerup', onUp);
    this._listen(window, 'pointercancel', onUp);
  }

  _updateJoystick(clientX, clientY) {
    const dx = clientX - this.joyCenter.x;
    const dy = clientY - this.joyCenter.y;
    const dist = Math.hypot(dx, dy);
    const clamped = Math.min(this.joyMaxRadius, dist);
    const angle = Math.atan2(dy, dx);
    const kx = Math.cos(angle) * clamped;
    const ky = Math.sin(angle) * clamped;

    this.joystickKnob.style.transform = `translate3d(${kx.toFixed(1)}px, ${ky.toFixed(1)}px, 0)`;

    const norm = clamped / this.joyMaxRadius;
    if (norm < 0.14) {
      this.joyVector.x = 0;
      this.joyVector.y = 0;
    } else {
      this.joyVector.x = kx / this.joyMaxRadius;
      this.joyVector.y = ky / this.joyMaxRadius;
    }
  }

  _bindButton(el, callbackKey) {
    if (!el) return;
    this._buttons.push(el);
    let activePointer = null;
    const onDown = (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.callbacks.onAnyInput?.();
      activePointer = e.pointerId;
      el.classList.add('pressed');
      this.callbacks[callbackKey]?.();
    };
    const onUp = (e) => {
      if (activePointer === null || e.pointerId === activePointer) {
        activePointer = null;
        el.classList.remove('pressed');
      }
    };
    this._listen(el, 'pointerdown', onDown, { passive: false });
    this._listen(window, 'pointerup', onUp);
    this._listen(window, 'pointercancel', onUp);
  }

  _bindKeyboard() {
    const onKeyDown = (e) => {
      this.callbacks.onAnyInput?.();
      const code = e.code;
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(code)) {
        e.preventDefault();
      }
      const isRepeat = this.keys.has(code);
      this.keys.add(code);
      if (isRepeat) return;

      if (code === 'KeyJ') this.callbacks.onLight?.();
      else if (code === 'KeyK') this.callbacks.onHeavy?.();
      else if (code === 'Space') this.callbacks.onDodge?.();
      else if (code === 'KeyL') this.callbacks.onParry?.();
      else if (code === 'KeyU' || code === 'KeyE') this.callbacks.onSkill?.();
      else if (code === 'KeyQ' || code === 'Tab') this.callbacks.onLockToggle?.();
    };

    const onKeyUp = (e) => {
      this.keys.delete(e.code);
    };

    const onBlur = () => {
      this.clearTransient();
    };

    this._listen(window, 'keydown', onKeyDown, { passive: false });
    this._listen(window, 'keyup', onKeyUp);
    this._listen(window, 'blur', onBlur);
  }

  getMoveVector(camera) {
    let ix = this.joyVector.x;
    let iy = this.joyVector.y;

    let kx = 0;
    let ky = 0;
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) kx -= 1;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) kx += 1;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) ky -= 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) ky += 1;

    if (kx !== 0 || ky !== 0) {
      const len = Math.hypot(kx, ky);
      ix = kx / len;
      iy = ky / len;
    }

    if (ix === 0 && iy === 0) {
      this.moveWorld.set(0, 0, 0);
      return this.moveWorld;
    }

    camera.getWorldDirection(this.camForward);
    this.camForward.y = 0;
    if (this.camForward.lengthSq() < 0.0001) this.camForward.set(0, 0, -1);
    this.camForward.normalize();

    this.camRight.set(-this.camForward.z, 0, this.camForward.x);

    this.moveWorld.set(0, 0, 0);
    this.moveWorld.addScaledVector(this.camRight, ix);
    this.moveWorld.addScaledVector(this.camForward, -iy);
    return this.moveWorld;
  }

  clearTransient() {
    this.keys.clear();
    this.joyPointerId = null;
    this.camPointerId = null;
    this.joyVector.x = 0;
    this.joyVector.y = 0;
    if (this.joystickKnob) {
      this.joystickKnob.style.transform = 'translate3d(0px, 0px, 0)';
    }
    for (let i = 0; i < this._buttons.length; i++) {
      this._buttons[i].classList?.remove?.('pressed');
    }
  }

  dispose() {
    this.clearTransient();
    for (const h of this._boundHandlers) {
      h.target.removeEventListener(h.type, h.fn, h.opts);
    }
    this._boundHandlers = [];
    this._buttons = [];
  }
}
