import * as THREE from 'three';
import * as SkeletonUtils from '/vendor/addons/utils/SkeletonUtils.js';
import { buildStylizedMinionRig, equipSkeletonGLBArmory, createContactAuraMesh } from './stylized.js';
import {
  GLBAnimationController,
  disposeObject3D,
  markSharedResources,
  cloneInstanceMaterials,
} from './modelManager.js';

export const MINION_GLB_URL = '/models/Skeleton_Minion.glb';

export class MinionEnemy {
  constructor(scene, kind = 'cinder_imp', spawnPos = new THREE.Vector3(6, 0, -4)) {
    this.scene = scene;
    this.kind = kind;
    this.root = new THREE.Group();
    this.root.position.copy(spawnPos);
    this.root.position.y = 0;

    const isSentinel = kind === 'obsidian_sentinel';
    this.maxHp = isSentinel ? 460 : 260;
    this.hp = this.maxHp;
    this.speed = isSentinel ? 2.6 : 4.5;
    this.attackRange = isSentinel ? 2.4 : 2.1;
    this.damage = isSentinel ? 95 : 65;
    this.radius = isSentinel ? 0.72 : 0.55;

    this.state = 'APPROACH';
    this.stateTime = 0;
    this.attackHasHit = false;
    this.lastHitGuarded = false;
    this.facingYaw = 0;
    this.hitFlash = 0;
    this.deadTimer = 0;
    this.removed = false;

    this.rig = null;
    this.glbCtrl = null;
    this.visualGroup = null;
    this.trackedMaterials = [];

    this.contactAura = createContactAuraMesh(isSentinel ? 0x52c4ff : 0xff7a2b, isSentinel ? 0.92 : 0.72, 0.52);
    this.root.add(this.contactAura);

    this._buildDefault();
    this.scene.add(this.root);
  }

  _buildDefault() {
    this._clearVisual();
    this.rig = buildStylizedMinionRig(this.kind);
    this.visualGroup = this.rig.root;
    this.root.add(this.visualGroup);
  }

  applyCustomGLB(clonedScene, animations, equipVariant = null) {
    this._clearVisual();
    this.rig = null;
    this.visualGroup = clonedScene;
    // Give each minion independent cloned materials so hit flashes & disposal never affect sibling minions
    this.trackedMaterials = cloneInstanceMaterials(clonedScene);
    if (equipVariant) {
      equipSkeletonGLBArmory(clonedScene, equipVariant);
      const scale = equipVariant === 'obsidian_sentinel' ? 1.12 : 0.9;
      clonedScene.scale.multiplyScalar(scale);
      clonedScene.position.multiplyScalar(scale);
    }
    this.root.add(this.visualGroup);
    this.glbCtrl = new GLBAnimationController(this.visualGroup, animations);
    this.glbCtrl.playState('IDLE');
  }

  _clearVisual() {
    if (this.glbCtrl) {
      this.glbCtrl.dispose();
      this.glbCtrl = null;
    }
    if (this.visualGroup) {
      this.root.remove(this.visualGroup);
      disposeObject3D(this.visualGroup);
      this.visualGroup = null;
    }
    this.trackedMaterials = [];
  }

  takeDamage(amount, attackerPos, isHeavyOrSkill, vfx, audio, arena = null) {
    if (this.state === 'DEAD') return 0;
    this.lastHitGuarded = false;

    // Obsidian Sentinel blocks light frontal attacks with its tower shield!
    if (this.kind === 'obsidian_sentinel' && !isHeavyOrSkill && attackerPos) {
      const dx = attackerPos.x - this.root.position.x;
      const dz = attackerPos.z - this.root.position.z;
      const dist = Math.max(0.01, Math.hypot(dx, dz));
      const dot = (Math.sin(this.facingYaw) * dx + Math.cos(this.facingYaw) * dz) / dist;
      if (dot > 0.35 && this.state !== 'WINDUP' && this.state !== 'RECOVERY' && this.state !== 'HIT') {
        const reduced = Math.round(amount * 0.3);
        this.hp = Math.max(0, this.hp - reduced);
        this.lastHitGuarded = true;
        this.hitFlash = 0.08;
        audio.playShieldClash();
        vfx.spawnSparks({ x: this.root.position.x, y: 1.05, z: this.root.position.z }, 14, 0x70c8ff, 7, 12);
        vfx.spawnFloatingText(this.root.position, `GUARD -${reduced}`, 'normal');
        if (this.hp <= 0) this._die(vfx, audio);
        return reduced;
      }
    }

    this.hp = Math.max(0, this.hp - amount);
    this.hitFlash = 0.16;
    if (attackerPos) {
      const kx = this.root.position.x - attackerPos.x;
      const kz = this.root.position.z - attackerPos.z;
      const len = Math.hypot(kx, kz);
      if (len > 0.001) {
        const push = isHeavyOrSkill ? 0.95 : 0.55;
        this.root.position.x += (kx / len) * push;
        this.root.position.z += (kz / len) * push;
        arena?.resolveObstacleCollision(this.root.position, this.radius);
      }
    }
    if (this.hp <= 0) {
      this._die(vfx, audio);
    } else if (this.state !== 'WINDUP') {
      this.state = 'HIT';
      this.stateTime = 0;
      this.attackHasHit = false;
      this.glbCtrl?.playState('HIT', true, 1.65, 0.06);
    }
    return amount;
  }

  _die(vfx, audio) {
    this.state = 'DEAD';
    this.stateTime = 0;
    if (this.contactAura) this.contactAura.visible = false;
    this.glbCtrl?.playState('DEATH', true);
    audio?.playEnemyDeath?.(this.kind === 'obsidian_sentinel');
    const deathColor = this.kind === 'obsidian_sentinel' ? 0x52c4ff : 0xff7a2b;
    vfx.spawnSparks({ x: this.root.position.x, y: 0.9, z: this.root.position.z }, 22, deathColor, 7.5, 10);
    vfx.spawnSmoke(this.root.position, 4, 0x3b323d);
    vfx.spawnHitFlash?.({ x: this.root.position.x, y: 0.95, z: this.root.position.z }, deathColor, 2.1);
  }

  update(dt, elapsed, playerPos, arena, onHitPlayer) {
    this.stateTime += dt;

    if (this.state === 'DEAD') {
      this.deadTimer += dt;
      if (this.rig) {
        const p = Math.min(1, this.deadTimer / 0.5);
        this.rig.hips.rotation.x = p * 1.45;
        this.rig.hips.position.y = THREE.MathUtils.lerp(0.75, 0.2, p);
      } else if (this.glbCtrl) {
        this.glbCtrl.update(dt, 'DEATH', elapsed, false);
      }
      if (this.deadTimer > 1.2) {
        this.removed = true;
      }
      return;
    }

    if (this.hitFlash > 0) this.hitFlash -= dt;
    if (this.rig) {
      if (this.hitFlash > 0) {
        this.rig.bodyMat.emissive.setHex(0xffffff);
        this.rig.bodyMat.emissiveIntensity = 0.45;
      } else {
        this.rig.bodyMat.emissive.setHex(0x000000);
        this.rig.bodyMat.emissiveIntensity = 0;
      }
    } else if (this.trackedMaterials.length > 0) {
      for (const m of this.trackedMaterials) {
        if (!m || !m.emissive || m.name === 'Glow') continue;
        if (this.hitFlash > 0) {
          m.emissive.setHex(0xaa2010);
          m.emissiveIntensity = 0.65;
        } else {
          m.emissive.setHex(0x000000);
          m.emissiveIntensity = 0;
        }
      }
    }

    const dx = playerPos.x - this.root.position.x;
    const dz = playerPos.z - this.root.position.z;
    const dist = Math.hypot(dx, dz);
    const angleToPlayer = Math.atan2(dx, dz);

    if (this.state === 'APPROACH') {
      this.facingYaw = lerpAngle(this.facingYaw, angleToPlayer, Math.min(1, dt * 8.5));
      if (dist > this.attackRange * 0.88) {
        this.root.position.x += Math.sin(this.facingYaw) * this.speed * dt;
        this.root.position.z += Math.cos(this.facingYaw) * this.speed * dt;
        this.glbCtrl?.playState('MOVE');
      } else {
        this.state = 'WINDUP';
        this.stateTime = 0;
        this.attackHasHit = false;
        const atkSpeed = this.kind === 'obsidian_sentinel' ? 1.18 : 1.40;
        this.glbCtrl?.playState('ATTACK', true, atkSpeed, 0.08);
      }
    } else if (this.state === 'WINDUP') {
      const windupDur = this.kind === 'obsidian_sentinel' ? 0.56 : 0.42;
      if (this.stateTime < windupDur * 0.72) {
        this.facingYaw = lerpAngle(this.facingYaw, angleToPlayer, Math.min(1, dt * 7.0));
      }
      if (this.stateTime >= windupDur) {
        this.state = 'ATTACK';
        this.stateTime = 0;
      }
    } else if (this.state === 'ATTACK') {
      if (this.stateTime < 0.18) {
        this.root.position.x += Math.sin(this.facingYaw) * 4.5 * dt;
        this.root.position.z += Math.cos(this.facingYaw) * 4.5 * dt;
      }
      if (!this.attackHasHit && this.stateTime >= 0.08 && this.stateTime <= 0.24 && dist <= this.attackRange + 0.4) {
        const toPlayerDot =
          dist > 0.001
            ? (Math.sin(this.facingYaw) * dx + Math.cos(this.facingYaw) * dz) / dist
            : 1;
        if (toPlayerDot >= 0.05) {
          this.attackHasHit = true;
          onHitPlayer(this.damage, this.root.position);
        }
      }
      if (this.stateTime >= 0.34) {
        this.state = 'RECOVERY';
        this.stateTime = 0;
        this.glbCtrl?.playState('IDLE', false, 1.0, 0.12);
      }
    } else if (this.state === 'RECOVERY') {
      if (this.stateTime >= 0.65) {
        this.state = 'APPROACH';
        this.stateTime = 0;
      }
    } else if (this.state === 'HIT') {
      if (this.stateTime >= 0.30) {
        this.state = 'APPROACH';
        this.stateTime = 0;
      }
    }

    arena.resolveObstacleCollision(this.root.position, this.radius);
    this.root.rotation.y = this.facingYaw;

    if (this.rig) {
      const baseH = this.kind === 'obsidian_sentinel' ? 0.88 : 0.72;
      const t = elapsed * (this.kind === 'cinder_imp' ? 11 : 7);
      if (this.state === 'APPROACH') {
        const stride = Math.sin(t) * 0.52;
        this.rig.hips.rotation.x = 0.08;
        this.rig.leftLeg.rotation.x = stride;
        this.rig.rightLeg.rotation.x = -stride;
        this.rig.leftArm.rotation.x = -stride * 0.6;
        this.rig.rightArm.rotation.x = stride * 0.6;
        this.rig.hips.position.y = baseH + Math.abs(Math.cos(t)) * 0.06;
      } else if (this.state === 'WINDUP') {
        const windupDur = this.kind === 'obsidian_sentinel' ? 0.56 : 0.42;
        const p = Math.min(1, this.stateTime / windupDur);
        this.rig.hips.rotation.x = -0.15 * p;
        this.rig.rightArm.rotation.x = THREE.MathUtils.lerp(-0.25, -1.85, p);
        this.rig.leftArm.rotation.x = -0.35 * p;
        this.rig.leftLeg.rotation.x = 0;
        this.rig.rightLeg.rotation.x = 0;
        this.rig.hips.position.y = baseH;
      } else if (this.state === 'ATTACK') {
        const p = Math.min(1, this.stateTime / 0.34);
        const swing = THREE.MathUtils.smoothstep(p, 0, 0.55);
        this.rig.hips.rotation.x = THREE.MathUtils.lerp(-0.15, 0.25, swing);
        this.rig.rightArm.rotation.x = THREE.MathUtils.lerp(-1.85, 0.85, swing);
        this.rig.leftArm.rotation.x = 0.25 * swing;
      } else if (this.state === 'HIT') {
        const recoil = Math.sin(Math.min(1, this.stateTime / 0.3) * Math.PI);
        this.rig.hips.rotation.x = -0.32 * recoil;
        this.rig.leftArm.rotation.z = 0.4 * recoil;
        this.rig.rightArm.rotation.z = -0.4 * recoil;
        this.rig.hips.position.y = baseH - recoil * 0.06;
      } else {
        this.rig.hips.rotation.x = 0;
        this.rig.rightArm.rotation.x = -0.25;
        this.rig.rightArm.rotation.z = 0;
        this.rig.leftArm.rotation.x = 0;
        this.rig.leftArm.rotation.z = 0;
        this.rig.leftLeg.rotation.x = 0;
        this.rig.rightLeg.rotation.x = 0;
        this.rig.hips.position.y = baseH + Math.sin(elapsed * 2.5) * 0.015;
      }
    } else if (this.glbCtrl) {
      const animKey =
        this.state === 'APPROACH'
          ? 'MOVE'
          : this.state === 'WINDUP'
          ? 'ATTACK'
          : this.state === 'RECOVERY'
          ? 'IDLE'
          : this.state;
      this.glbCtrl.update(dt, animKey, elapsed, this.state === 'APPROACH');
    }
  }

  dispose() {
    this._clearVisual();
    if (this.contactAura) {
      this.root.remove(this.contactAura);
      this.contactAura.geometry?.dispose?.();
      this.contactAura.material?.dispose?.();
      this.contactAura = null;
    }
    this.scene.remove(this.root);
  }
}

export class MinionManager {
  constructor(scene) {
    this.scene = scene;
    this.minions = [];
    this.customTemplate = null; // { scene, animations }
    this.defaultTemplate = null; // { scene, animations } loaded from Skeleton_Minion.glb
    this.customRequestId = 0;
    this.wave1Spawned = false;
    this.wave2Spawned = false;
  }

  async preloadDefaultGLB(glbLoader) {
    if (this.defaultTemplate) return;
    try {
      const loaded = await glbLoader.loadAsync(MINION_GLB_URL, 1.65, {
        stylizeToon: false,
        addOutlines: false,
        enhancePBR: true,
        hideSpareWeapons: true,
        rimColor: 0xff7a2b,
        rimStrength: 0.45,
      });
      markSharedResources(loaded.scene);
      this.defaultTemplate = { scene: loaded.scene, animations: loaded.animations };
    } catch (_) {
      // Keep stylized procedural rig fallback silently
    }
  }

  setCustomTemplate(scene, animations) {
    this.customRequestId++;
    if (this.customTemplate?.scene) {
      disposeObject3D(this.customTemplate.scene, { includeShared: true });
    }
    if (scene) markSharedResources(scene);
    this.customTemplate = scene ? { scene, animations } : null;
  }

  clear() {
    for (const m of this.minions) {
      m.dispose();
    }
    this.minions = [];
    this.wave1Spawned = false;
    this.wave2Spawned = false;
  }

  dispose() {
    this.clear();
    if (this.defaultTemplate?.scene) {
      disposeObject3D(this.defaultTemplate.scene, { includeShared: true });
      this.defaultTemplate = null;
    }
    if (this.customTemplate?.scene) {
      disposeObject3D(this.customTemplate.scene, { includeShared: true });
      this.customTemplate = null;
    }
  }

  spawnReinforcements(kindList, bossPos, vfx, audio) {
    kindList.forEach((kind, i) => {
      const ang = (i === 0 ? -0.9 : 0.9) + Math.random() * 0.3;
      const spawn = new THREE.Vector3(
        bossPos.x + Math.sin(ang) * 4.8,
        0,
        bossPos.z + Math.cos(ang) * 4.8
      );
      const minion = new MinionEnemy(this.scene, kind, spawn);
      if (this.customTemplate) {
        minion.applyCustomGLB(SkeletonUtils.clone(this.customTemplate.scene), this.customTemplate.animations);
      } else if (this.defaultTemplate) {
        minion.applyCustomGLB(
          SkeletonUtils.clone(this.defaultTemplate.scene),
          this.defaultTemplate.animations,
          kind
        );
      }
      this.minions.push(minion);
      vfx.spawnMagicBurst(spawn, 0xff7a2b);
    });
    audio.playFireBurst();
  }

  update(dt, elapsed, playerPos, arena, onHitPlayer) {
    for (let i = this.minions.length - 1; i >= 0; i--) {
      const m = this.minions[i];
      m.update(dt, elapsed, playerPos, arena, onHitPlayer);
      if (m.removed) {
        m.dispose();
        this.minions.splice(i, 1);
      }
    }
  }
}

function lerpAngle(a, b, t) {
  let diff = ((b - a + Math.PI) % (Math.PI * 2)) - Math.PI;
  if (diff < -Math.PI) diff += Math.PI * 2;
  return a + diff * t;
}
