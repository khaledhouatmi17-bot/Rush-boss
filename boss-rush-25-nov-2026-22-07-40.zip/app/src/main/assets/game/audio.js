// Procedural Web Audio API synthesizer for Boss Rush: Ashes of the Last Gods
// Supports independent Music and SFX volume controls, mute, footsteps, unsheathe, skills, and multi-phase music.

export class SoundEngine {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.sfxGain = null;
    this.musicGain = null;
    this.noiseBuffer = null;
    this.muted = false;
    this.masterVolume = 1.0; // 0..1
    this.musicVolume = 0.7;  // 0..1
    this.sfxVolume = 0.85;   // 0..1
    this.initFailed = false;
    this.musicTimer = null;
    this.musicPhase = 0; // 0 = menu/idle, 1 = phase 1, 2 = phase 2
    this.beatIndex = 0;
    this.droneOscs = [];
    this._lastPlayed = new Map();
    this.customBuffers = new Map();
    this.customAudioUrls = new Map();
  }

  init() {
    if (this.ctx || this.initFailed) return;
    const AudioCtx = typeof window !== 'undefined' && (window.AudioContext || window.webkitAudioContext);
    if (!AudioCtx) return;

    try {
      this.ctx = new AudioCtx();
      const compressor = this.ctx.createDynamicsCompressor();
      compressor.threshold.value = -15;
      compressor.knee.value = 18;
      compressor.ratio.value = 6;
      compressor.attack.value = 0.004;
      compressor.release.value = 0.2;

      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : this.masterVolume * 0.78;

      this.sfxGain = this.ctx.createGain();
      this.sfxGain.gain.value = this.sfxVolume;

      this.musicGain = this.ctx.createGain();
      this.musicGain.gain.value = this.musicVolume * 0.45;

      this.sfxGain.connect(compressor);
      this.musicGain.connect(compressor);
      compressor.connect(this.master);
      this.master.connect(this.ctx.destination);

      const sampleRate = this.ctx.sampleRate || 44100;
      this.noiseBuffer = this.ctx.createBuffer(1, sampleRate, sampleRate);
      const data = this.noiseBuffer.getChannelData(0);
      for (let i = 0; i < sampleRate; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      if (this.customAudioUrls.size > 0) {
        for (const [key, url] of this.customAudioUrls.entries()) {
          this._decodeExternalAudio(key, url);
        }
      }

      if (this.musicPhase !== 0 && !this.musicTimer) {
        this._restartMusicLoop();
      }
    } catch (_) {
      this.initFailed = true;
      try {
        this.ctx?.close?.();
      } catch (_) {}
      this.ctx = null;
      this.master = null;
      this.sfxGain = null;
      this.musicGain = null;
      this.noiseBuffer = null;
    }
  }

  unlock() {
    this.init();
    try {
      if (this.ctx && this.ctx.state === 'suspended' && typeof this.ctx.resume === 'function') {
        this.ctx.resume().catch(() => {});
      }
    } catch (_) {}
  }

  suspend() {
    try {
      if (this.ctx && this.ctx.state === 'running' && typeof this.ctx.suspend === 'function') {
        this.ctx.suspend().catch(() => {});
      }
    } catch (_) {}
  }

  resumeIfNeeded() {
    try {
      if (this.ctx && this.ctx.state === 'suspended' && typeof this.ctx.resume === 'function') {
        this.ctx.resume().catch(() => {});
      }
    } catch (_) {}
  }

  async registerAudioAsset(eventName, url) {
    if (!eventName || !url) return false;
    this.customAudioUrls.set(eventName, url);
    if (!this.ctx) return true;
    return this._decodeExternalAudio(eventName, url);
  }

  async loadCustomAudioPack(assetMap) {
    if (!assetMap || typeof assetMap !== 'object') return;
    const entries = Object.entries(assetMap);
    await Promise.all(entries.map(([key, url]) => this.registerAudioAsset(key, url)));
  }

  async _decodeExternalAudio(eventName, url) {
    if (!this.ctx || typeof fetch !== 'function') return false;
    try {
      const res = await fetch(url);
      if (!res.ok) return false;
      const arr = await res.arrayBuffer();
      const decoded = await this.ctx.decodeAudioData(arr);
      this.customBuffers.set(eventName, decoded);
      return true;
    } catch (_) {
      return false;
    }
  }

  _playCustomBuffer(eventName, gain = 0.85, playbackRate = 1.0) {
    if (!this.ctx || this.muted || !this.customBuffers.has(eventName)) return false;
    const buf = this.customBuffers.get(eventName);
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = playbackRate;
    const g = this.ctx.createGain();
    g.gain.value = gain;
    src.connect(g);
    g.connect(this.sfxGain);
    src.onended = () => {
      try {
        src.disconnect();
        g.disconnect();
      } catch (_) {}
    };
    src.start();
    return true;
  }

  _canPlay(key, minGapMs = 45) {
    const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
    const prev = this._lastPlayed.get(key) ?? -Infinity;
    if (now - prev < minGapMs) return false;
    this._lastPlayed.set(key, now);
    return true;
  }

  setMuted(muted) {
    this.muted = !!muted;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(this.muted ? 0 : this.masterVolume * 0.78, this.ctx.currentTime, 0.04);
    }
  }

  setMasterVolume(vol) {
    const n = Number(vol);
    this.masterVolume = Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 1.0;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(this.muted ? 0 : this.masterVolume * 0.78, this.ctx.currentTime, 0.04);
    }
  }

  setMusicVolume(vol) {
    const n = Number(vol);
    this.musicVolume = Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0.7;
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setTargetAtTime(this.musicVolume * 0.45, this.ctx.currentTime, 0.04);
    }
  }

  setSfxVolume(vol) {
    const n = Number(vol);
    this.sfxVolume = Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0.85;
    if (this.sfxGain && this.ctx) {
      this.sfxGain.gain.setTargetAtTime(this.sfxVolume, this.ctx.currentTime, 0.04);
    }
  }

  _noiseBurst(duration, filterFreqStart, filterFreqEnd, filterType, gainPeak, q = 1.4, delay = 0) {
    if (!this.ctx || !this.noiseBuffer || this.muted) return;
    const now = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = filterType;
    filter.Q.value = q;
    filter.frequency.setValueAtTime(filterFreqStart, now);
    filter.frequency.exponentialRampToValueAtTime(Math.max(40, filterFreqEnd), now + duration);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.001, now);
    g.gain.linearRampToValueAtTime(gainPeak, now + 0.015);
    g.gain.exponentialRampToValueAtTime(0.001, now + duration);

    src.connect(filter);
    filter.connect(g);
    g.connect(this.sfxGain);
    src.onended = () => {
      try {
        src.disconnect();
        filter.disconnect();
        g.disconnect();
      } catch (_) {}
    };
    src.start(now);
    src.stop(now + duration + 0.02);
  }

  _tone(freqStart, freqEnd, duration, type, gainPeak, delay = 0) {
    if (!this.ctx || this.muted) return;
    const now = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freqStart, now);
    if (freqEnd !== freqStart) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(24, freqEnd), now + duration);
    }

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.001, now);
    g.gain.linearRampToValueAtTime(gainPeak, now + 0.012);
    g.gain.exponentialRampToValueAtTime(0.001, now + duration);

    osc.connect(g);
    g.connect(this.sfxGain);
    osc.onended = () => {
      try {
        osc.disconnect();
        g.disconnect();
      } catch (_) {}
    };
    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  playSwordUnsheathe() {
    this.unlock();
    if (!this._canPlay('unsheathe', 120)) return;
    if (this._playCustomBuffer('unsheathe', 0.8)) return;
    this._noiseBurst(0.26, 2200, 4800, 'bandpass', 0.22, 4.5);
    this._tone(1180, 1760, 0.22, 'sine', 0.14);
    this._tone(1620, 2120, 0.28, 'triangle', 0.09, 0.04);
  }

  playFootstep(isBoss = false) {
    this.unlock();
    if (!this._canPlay(isBoss ? 'step_boss' : 'step_player', isBoss ? 180 : 120)) return;
    if (this._playCustomBuffer(isBoss ? 'footstep_boss' : 'footstep', isBoss ? 0.75 : 0.45)) return;
    const jitter = 0.94 + Math.random() * 0.12;
    if (isBoss) {
      this._tone(84 * jitter, 32, 0.17, 'sine', 0.24);
      this._noiseBurst(0.09, 360, 110, 'lowpass', 0.15, 1.0);
    } else {
      this._tone(160 * jitter, 72, 0.06, 'triangle', 0.075);
      this._noiseBurst(0.04, 1200, 380, 'bandpass', 0.06, 1.6);
    }
  }

  playSwordSwing(heavy = false) {
    if (heavy) {
      this.playHeavyAttack(false);
    } else {
      this.playLightAttack(0);
    }
  }

  playLightAttack(step = 0) {
    this.playComboSwing(step, false);
  }

  playHeavyAttack(isFinisher = false) {
    this.unlock();
    if (!this._canPlay('swing', 75)) return;
    const customKey = isFinisher ? 'swing_finisher' : 'swing_heavy';
    if (this._playCustomBuffer(customKey, 0.9, isFinisher ? 0.96 : 1.0)) return;
    this._noiseBurst(isFinisher ? 0.38 : 0.34, isFinisher ? 1120 : 980, 180, 'bandpass', isFinisher ? 0.48 : 0.44, 1.8);
    this._tone(isFinisher ? 175 : 195, 62, isFinisher ? 0.32 : 0.28, 'triangle', isFinisher ? 0.28 : 0.24);
    this._tone(isFinisher ? 460 : 420, 130, 0.18, 'sine', 0.14);
    if (isFinisher) {
      this._tone(680, 260, 0.16, 'triangle', 0.1, 0.03);
    }
  }

  playComboSwing(step = 0, heavy = false) {
    this.unlock();
    if (!this._canPlay('swing', 75)) return;
    if (this._playCustomBuffer(heavy ? 'swing_heavy' : 'swing_light', 0.85, 0.95 + step * 0.05)) return;
    if (heavy) {
      this._noiseBurst(0.34, 980, 195, 'bandpass', 0.44, 1.8);
      this._tone(195, 68, 0.28, 'triangle', 0.24);
      this._tone(420, 140, 0.16, 'sine', 0.12);
    } else {
      const pitchShift = step === 1 ? 1.14 : step === 2 ? 0.86 : 1.0;
      this._noiseBurst(step === 2 ? 0.24 : 0.19, 1500 * pitchShift, 360 * pitchShift, 'bandpass', step === 2 ? 0.34 : 0.29, 2.0);
      this._tone(285 * pitchShift, 115 * pitchShift, step === 2 ? 0.18 : 0.14, 'sine', step === 2 ? 0.16 : 0.13);
      if (step === 2) {
        this._tone(540, 190, 0.2, 'triangle', 0.13, 0.02);
      }
    }
  }

  playImpact(heavy = false, isArmor = false) {
    this.unlock();
    const specificKey = isArmor ? 'impact_armor' : 'impact_flesh';
    if (!this._canPlay('impact_any', 40)) return;
    if (!this._canPlay(specificKey, 48)) return;
    if (this._playCustomBuffer(heavy ? 'impact_heavy' : 'impact', 0.9)) return;
    const jitter = 0.94 + Math.random() * 0.12;
    if (isArmor) {
      this._tone((heavy ? 112 : 156) * jitter, 38, heavy ? 0.31 : 0.18, 'triangle', heavy ? 0.48 : 0.32);
      this._noiseBurst(heavy ? 0.18 : 0.13, heavy ? 2350 : 1950, 540, 'bandpass', heavy ? 0.34 : 0.26, 2.8);
      this._tone((heavy ? 500 : 680) * jitter, 300, heavy ? 0.15 : 0.11, 'square', heavy ? 0.11 : 0.08);
      this._tone((heavy ? 1420 : 1280) * jitter, 940, 0.11, 'sine', heavy ? 0.09 : 0.06);
    } else {
      this._tone((heavy ? 124 : 148) * jitter, 42, heavy ? 0.28 : 0.16, 'sine', heavy ? 0.48 : 0.34);
      this._noiseBurst(heavy ? 0.15 : 0.11, heavy ? 1320 : 1050, 210, 'lowpass', heavy ? 0.35 : 0.28, 1.0);
    }
  }

  playBossHit(heavy = false) {
    this.playImpact(heavy, true);
  }

  playCriticalAttack() {
    this.unlock();
    if (!this._canPlay('critical_attack', 140)) return;
    if (this._playCustomBuffer('critical_attack', 1.0)) return;
    this._tone(108, 32, 0.46, 'sine', 0.56);
    this._tone(215, 58, 0.38, 'triangle', 0.36);
    this._tone(780, 420, 0.26, 'sawtooth', 0.14, 0.02);
    this._tone(1560, 1180, 0.32, 'sine', 0.16, 0.03);
    this._noiseBurst(0.24, 2800, 420, 'bandpass', 0.38, 2.2);
  }

  playPlayerDamage() {
    this.unlock();
    if (!this._canPlay('player_damage', 90)) return;
    if (this._playCustomBuffer('player_damage', 0.9)) return;
    this._tone(118, 38, 0.26, 'sawtooth', 0.26);
    this._tone(168, 52, 0.24, 'sine', 0.42);
    this._noiseBurst(0.16, 860, 160, 'lowpass', 0.34, 1.2);
  }

  playEnemyDeath(isSentinel = false) {
    this.unlock();
    if (!this._canPlay('enemy_death', 80)) return;
    if (this._playCustomBuffer('enemy_death', 0.85)) return;
    if (isSentinel) {
      this._tone(165, 42, 0.38, 'triangle', 0.3);
      this._noiseBurst(0.28, 1600, 180, 'bandpass', 0.28, 2.0);
    } else {
      this._tone(240, 62, 0.28, 'sawtooth', 0.16);
      this._noiseBurst(0.24, 1200, 200, 'lowpass', 0.24, 1.2);
    }
  }

  playShieldClash() {
    this.unlock();
    if (!this._canPlay('shield_clash', 65)) return;
    if (this._playCustomBuffer('shield_clash', 0.85)) return;
    this._tone(540, 380, 0.2, 'triangle', 0.26);
    this._tone(860, 690, 0.16, 'sine', 0.14);
    this._noiseBurst(0.11, 2100, 720, 'bandpass', 0.24, 2.4);
  }

  playParry() {
    this.playPerfectParry();
  }

  playPerfectParry() {
    this.unlock();
    if (!this._canPlay('parry', 120)) return;
    if (this._playCustomBuffer('parry', 0.95)) return;
    this._tone(180, 56, 0.22, 'sine', 0.32);
    this._tone(1046.5, 988, 0.4, 'triangle', 0.3);
    this._tone(1567.98, 1520, 0.48, 'sine', 0.26, 0.01);
    this._tone(2349.32, 2210, 0.34, 'sine', 0.18, 0.02);
    this._noiseBurst(0.1, 3800, 1400, 'highpass', 0.26, 1.8);
  }

  playStagger() {
    this.unlock();
    if (!this._canPlay('stagger', 180)) return;
    if (this._playCustomBuffer('stagger', 0.9)) return;
    this._tone(98, 36, 0.55, 'sawtooth', 0.26);
    this._tone(220, 110, 0.48, 'triangle', 0.28, 0.05);
    this._tone(440, 293, 0.55, 'sine', 0.2, 0.08);
  }

  playDodge() {
    this.unlock();
    if (!this._canPlay('dodge', 120)) return;
    if (this._playCustomBuffer('dodge', 0.75)) return;
    this._noiseBurst(0.2, 720, 210, 'lowpass', 0.24, 1.2);
    this._tone(235, 95, 0.16, 'sine', 0.11);
  }

  playPerfectDodge() {
    this.unlock();
    if (!this._canPlay('perfect_dodge', 130)) return;
    if (this._playCustomBuffer('perfect_dodge', 0.9)) return;
    this._noiseBurst(0.24, 1400, 320, 'bandpass', 0.26, 1.6);
    this._tone(520, 1040, 0.24, 'sine', 0.2);
    this._tone(780, 1560, 0.28, 'triangle', 0.13, 0.03);
  }

  playSkill() {
    this.unlock();
    if (!this._canPlay('skill', 200)) return;
    if (this._playCustomBuffer('skill', 0.95)) return;
    this._tone(260, 820, 0.22, 'sine', 0.22);
    this._tone(520, 140, 0.42, 'triangle', 0.32, 0.08);
    this._noiseBurst(0.45, 2000, 220, 'bandpass', 0.42, 1.5, 0.05);
    this._tone(125, 36, 0.4, 'sine', 0.38, 0.08);
  }

  playFireBurst() {
    this.unlock();
    if (!this._canPlay('fire_burst', 110)) return;
    if (this._playCustomBuffer('fire_burst', 0.85)) return;
    this._noiseBurst(0.45, 900, 160, 'lowpass', 0.36, 1.1);
    this._tone(140, 46, 0.34, 'triangle', 0.24);
  }

  playBossRoar(enraged = false) {
    this.unlock();
    if (!this._canPlay('boss_roar', 250)) return;
    if (this._playCustomBuffer(enraged ? 'boss_roar_p2' : 'boss_roar', 0.95)) return;
    const dur = enraged ? 1.15 : 0.85;
    this._tone(enraged ? 115 : 95, 40, dur, 'sawtooth', 0.26);
    this._tone(enraged ? 172 : 140, 56, dur * 0.9, 'triangle', 0.28);
    this._noiseBurst(dur * 0.85, 520, 130, 'bandpass', 0.3, 2.2);
  }

  playShockwave() {
    this.unlock();
    if (!this._canPlay('shockwave', 120)) return;
    if (this._playCustomBuffer('shockwave', 0.95)) return;
    this._tone(112, 26, 0.65, 'sine', 0.52);
    this._tone(75, 28, 0.58, 'triangle', 0.36);
    this._noiseBurst(0.45, 650, 90, 'lowpass', 0.4, 1.1);
  }

  playPhase2Transform() {
    this.unlock();
    if (!this._canPlay('phase2', 400)) return;
    if (this._playCustomBuffer('phase2', 1.0)) return;
    this.playBossRoar(true);
    this._tone(65, 30, 1.15, 'sine', 0.5);
    this._tone(220, 330, 0.9, 'triangle', 0.18, 0.15);
    this._tone(330, 440, 0.9, 'sine', 0.14, 0.25);
  }

  playVictory() {
    this.unlock();
    if (!this._canPlay('victory', 1000)) return;
    if (this._playCustomBuffer('victory', 0.9)) return;
    const notes = [220, 277.18, 329.63, 440];
    notes.forEach((n, idx) => {
      this._tone(n, n, 1.35, 'triangle', 0.18, idx * 0.11);
      this._tone(n * 0.5, n * 0.5, 1.4, 'sine', 0.16, idx * 0.11);
    });
  }

  playDefeat() {
    this.unlock();
    if (!this._canPlay('defeat', 1000)) return;
    if (this._playCustomBuffer('defeat', 0.9)) return;
    this._tone(146.83, 110, 1.2, 'triangle', 0.24, 0);
    this._tone(110, 73.42, 1.5, 'sine', 0.28, 0.25);
    this._noiseBurst(0.6, 380, 90, 'lowpass', 0.18, 1.0);
  }

  setMusicState(phase) {
    if (this.musicPhase === phase) return;
    this.musicPhase = phase;
    this.beatIndex = 0;
    this._restartMusicLoop();
  }

  _restartMusicLoop() {
    if (this.musicTimer) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
    this._stopDrones();
    if (!this.ctx || this.musicPhase === 0) return;

    const intervalMs = this.musicPhase === 2 ? 235 : 350;
    const scale = [73.42, 82.41, 87.31, 110.0, 116.54, 130.81];
    const pattern1 = [0, -1, 3, 2, 0, -1, 4, 3];
    const pattern2 = [0, 0, 3, 4, 2, 0, 5, 4];

    [73.42, 110.0].forEach((freq) => {
      const osc = this.ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.value = freq;
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = this.musicPhase === 2 ? 330 : 215;
      const g = this.ctx.createGain();
      g.gain.value = this.musicPhase === 2 ? 0.16 : 0.11;
      osc.connect(filter);
      filter.connect(g);
      g.connect(this.musicGain);
      osc.start();
      this.droneOscs.push({ osc, filter, g });
    });

    this.musicTimer = setInterval(() => {
      if (!this.ctx || this.ctx.state !== 'running' || this.muted || this.musicVolume <= 0.01) return;
      const now = this.ctx.currentTime;
      const pat = this.musicPhase === 2 ? pattern2 : pattern1;
      const step = pat[this.beatIndex % pat.length];

      if (this.beatIndex % 2 === 0 || (this.musicPhase === 2 && this.beatIndex % 4 === 3)) {
        const drum = this.ctx.createOscillator();
        drum.type = 'sine';
        drum.frequency.setValueAtTime(this.musicPhase === 2 ? 96 : 78, now);
        drum.frequency.exponentialRampToValueAtTime(34, now + 0.18);
        const dg = this.ctx.createGain();
        dg.gain.setValueAtTime(0.001, now);
        dg.gain.linearRampToValueAtTime(this.musicPhase === 2 ? 0.34 : 0.24, now + 0.01);
        dg.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
        drum.connect(dg);
        dg.connect(this.musicGain);
        drum.onended = () => {
          try {
            drum.disconnect();
            dg.disconnect();
          } catch (_) {}
        };
        drum.start(now);
        drum.stop(now + 0.24);
      }

      if (step >= 0) {
        const freq = scale[step] * (this.musicPhase === 2 && this.beatIndex % 8 >= 4 ? 2 : 1);
        const osc = this.ctx.createOscillator();
        osc.type = this.musicPhase === 2 ? 'sawtooth' : 'triangle';
        osc.frequency.setValueAtTime(freq, now);
        const filt = this.ctx.createBiquadFilter();
        filt.type = 'lowpass';
        filt.frequency.value = this.musicPhase === 2 ? 560 : 340;
        const g = this.ctx.createGain();
        g.gain.setValueAtTime(0.001, now);
        g.gain.linearRampToValueAtTime(this.musicPhase === 2 ? 0.15 : 0.11, now + 0.02);
        g.gain.exponentialRampToValueAtTime(0.001, now + (this.musicPhase === 2 ? 0.22 : 0.34));
        osc.connect(filt);
        filt.connect(g);
        g.connect(this.musicGain);
        osc.onended = () => {
          try {
            osc.disconnect();
            filt.disconnect();
            g.disconnect();
          } catch (_) {}
        };
        osc.start(now);
        osc.stop(now + 0.36);
      }

      this.beatIndex++;
    }, intervalMs);
  }

  _stopDrones() {
    for (const d of this.droneOscs) {
      try {
        d.osc.stop();
        d.osc.disconnect?.();
        d.filter?.disconnect?.();
        d.g?.disconnect?.();
      } catch (_) {}
    }
    this.droneOscs = [];
  }

  dispose() {
    if (this.musicTimer) clearInterval(this.musicTimer);
    this.musicTimer = null;
    this._stopDrones();
    this.customBuffers.clear();
    if (this.ctx) {
      try {
        this.ctx.close?.().catch?.(() => {});
      } catch (_) {}
      this.ctx = null;
    }
  }
}
