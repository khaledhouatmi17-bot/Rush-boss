import * as THREE from 'three';

export const ARENA_RADIUS = 19.2;

// Converts a single-channel canvas heightfield (0..255) into a crisp tangent-space NormalMap
function heightCanvasToNormalTexture(heightCanvas, strength = 2.6, repeat = 1) {
  if (typeof document === 'undefined' || !heightCanvas) return null;
  const srcCtx = heightCanvas.getContext?.('2d');
  if (!srcCtx) return null;
  const w = heightCanvas.width;
  const h = heightCanvas.height;
  const src = srcCtx.getImageData(0, 0, w, h).data;

  const outCanvas = document.createElement('canvas');
  outCanvas.width = w;
  outCanvas.height = h;
  const octx = outCanvas.getContext?.('2d');
  if (!octx) return null;
  const outImg = octx.createImageData(w, h);
  const dst = outImg.data;

  const sample = (x, y) => {
    const wx = ((x % w) + w) % w;
    const wy = ((y % h) + h) % h;
    return src[(wy * w + wx) * 4] / 255.0;
  };

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      // Sobel 3x3 gradient
      const tl = sample(x - 1, y - 1);
      const t = sample(x, y - 1);
      const tr = sample(x + 1, y - 1);
      const l = sample(x - 1, y);
      const r = sample(x + 1, y);
      const bl = sample(x - 1, y + 1);
      const b = sample(x, y + 1);
      const br = sample(x + 1, y + 1);

      const dX = (tr + 2 * r + br) - (tl + 2 * l + bl);
      const dY = (bl + 2 * b + br) - (tl + 2 * t + tr);

      let nx = -dX * strength;
      let ny = -dY * strength;
      let nz = 1.0;
      const invLen = 1.0 / Math.hypot(nx, ny, nz);
      nx *= invLen;
      ny *= invLen;
      nz *= invLen;

      const idx = (y * w + x) * 4;
      dst[idx] = Math.round((nx * 0.5 + 0.5) * 255);
      dst[idx + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      dst[idx + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      dst[idx + 3] = 255;
    }
  }
  octx.putImageData(outImg, 0, 0);

  const tex = new THREE.CanvasTexture(outCanvas);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  return tex;
}

// High-craft PBR stone floor textures (Albedo + Sobel NormalMap + RoughnessMap + MetalnessMap)
function createFloorPBRMaps() {
  if (typeof document === 'undefined') {
    return { map: null, normalMap: null, roughnessMap: null, metalnessMap: null };
  }
  const size = 512;
  const diffCanvas = document.createElement('canvas');
  const hCanvas = document.createElement('canvas');
  const roughCanvas = document.createElement('canvas');
  const metalCanvas = document.createElement('canvas');
  [diffCanvas, hCanvas, roughCanvas, metalCanvas].forEach((c) => {
    c.width = size;
    c.height = size;
  });

  const ctx = diffCanvas.getContext?.('2d');
  const hctx = hCanvas.getContext?.('2d');
  const rctx = roughCanvas.getContext?.('2d');
  const mctx = metalCanvas.getContext?.('2d');
  if (!ctx || !hctx || !rctx || !mctx) {
    return { map: null, normalMap: null, roughnessMap: null, metalnessMap: null };
  }

  // Deep recessed mortar seams: low height, rough matte ash, non-metallic
  ctx.fillStyle = '#121017';
  ctx.fillRect(0, 0, size, size);
  hctx.fillStyle = '#202020';
  hctx.fillRect(0, 0, size, size);
  rctx.fillStyle = '#e8e8e8'; // ~0.91 roughness in mortar
  rctx.fillRect(0, 0, size, size);
  mctx.fillStyle = '#0c0c0c';
  mctx.fillRect(0, 0, size, size);

  const tiles = 8;
  const step = size / tiles;

  // Deterministic pseudo-random helper for crisp reproducible stonework
  let seed = 1337;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  for (let row = 0; row < tiles; row++) {
    let col = 0;
    while (col < tiles) {
      const span = col < tiles - 1 && rand() < 0.24 ? 2 : 1;
      const x = col * step + (row % 2 === 0 ? 0 : step * 0.25);
      const y = row * step;
      const wSpan = step * span;
      const drawTile = (ox) => {
        const shade = 25 + Math.floor(rand() * 22);
        const warm = Math.floor(rand() * 10);
        const cool = Math.floor(rand() * 8);
        ctx.fillStyle = `rgb(${shade + warm}, ${shade + 1}, ${shade + 8 + cool})`;
        ctx.fillRect(ox + 2.5, y + 2.5, wSpan - 5, step - 5);

        // Beveled slate height
        const hVal = 152 + Math.floor(rand() * 56);
        hctx.fillStyle = `rgb(${hVal}, ${hVal}, ${hVal})`;
        hctx.fillRect(ox + 3.5, y + 3.5, wSpan - 7, step - 7);

        // Specular damp patches (~0.32 - 0.64 roughness across polished battle-worn basalt)
        const rVal = 82 + Math.floor(rand() * 78);
        rctx.fillStyle = `rgb(${rVal}, ${rVal}, ${rVal})`;
        rctx.fillRect(ox + 3, y + 3, wSpan - 6, step - 6);

        // Subtle iron mineral flecks
        const mVal = 22 + Math.floor(rand() * 36);
        mctx.fillStyle = `rgb(${mVal}, ${mVal}, ${mVal})`;
        mctx.fillRect(ox + 3, y + 3, wSpan - 6, step - 6);

        // Corner brass rivet/inlay accent on alternating sanctuary slabs
        if ((row + col) % 4 === 0) {
          ctx.fillStyle = '#6c542e';
          ctx.fillRect(ox + 6, y + 6, 4, 4);
          hctx.fillStyle = '#dce0e0';
          hctx.fillRect(ox + 6, y + 6, 4, 4);
          rctx.fillStyle = '#484848';
          rctx.fillRect(ox + 6, y + 6, 4, 4);
          mctx.fillStyle = '#d8d8d8';
          mctx.fillRect(ox + 6, y + 6, 4, 4);
        }

        // Chiseled battle cracks & branched fissures
        if (rand() < 0.56) {
          let cx = ox + wSpan * (0.2 + rand() * 0.6);
          let cy = y + step * (0.2 + rand() * 0.6);
          ctx.strokeStyle = 'rgba(8, 6, 12, 0.82)';
          ctx.lineWidth = 1.4;
          hctx.strokeStyle = '#141414';
          hctx.lineWidth = 2.0;
          rctx.strokeStyle = '#e0e0e0';
          rctx.lineWidth = 2.0;
          ctx.beginPath();
          hctx.beginPath();
          rctx.beginPath();
          ctx.moveTo(cx, cy);
          hctx.moveTo(cx, cy);
          rctx.moveTo(cx, cy);
          for (let s = 0; s < 4; s++) {
            cx += (rand() - 0.5) * step * 0.55;
            cy += (rand() - 0.5) * step * 0.55;
            ctx.lineTo(cx, cy);
            hctx.lineTo(cx, cy);
            rctx.lineTo(cx, cy);
          }
          ctx.stroke();
          hctx.stroke();
          rctx.stroke();
        }
      };

      drawTile(x);
      if (x + wSpan > size) drawTile(x - size);
      col += span;
    }
  }

  // Wet rain-slicked basalt puddles for realistic moonlight & brazier specular contrast
  for (let p = 0; p < 7; p++) {
    const px = rand() * size;
    const py = rand() * size;
    const rx = 28 + rand() * 44;
    const ry = 18 + rand() * 34;
    const rot = rand() * Math.PI;
    const drawPuddle = (ox, oy) => {
      ctx.save();
      ctx.translate(ox, oy);
      ctx.rotate(rot);
      ctx.fillStyle = 'rgba(10, 12, 18, 0.34)';
      ctx.beginPath();
      ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      rctx.save();
      rctx.translate(ox, oy);
      rctx.rotate(rot);
      rctx.fillStyle = 'rgba(34, 34, 34, 0.72)';
      rctx.beginPath();
      rctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
      rctx.fill();
      rctx.restore();

      mctx.save();
      mctx.translate(ox, oy);
      mctx.rotate(rot);
      mctx.fillStyle = 'rgba(92, 92, 92, 0.32)';
      mctx.beginPath();
      mctx.ellipse(0, 0, rx * 0.85, ry * 0.85, 0, 0, Math.PI * 2);
      mctx.fill();
      mctx.restore();
    };
    drawPuddle(px, py);
    if (px + rx > size) drawPuddle(px - size, py);
    if (px - rx < 0) drawPuddle(px + size, py);
    if (py + ry > size) drawPuddle(px, py - size);
    if (py - ry < 0) drawPuddle(px, py + size);
  }

  // Stone grain, soot & damp sheen variation
  for (let i = 0; i < 1600; i++) {
    const px = rand() * size;
    const py = rand() * size;
    const sz = 2 + rand() * 4;
    const isAsh = rand() > 0.45;
    ctx.fillStyle = isAsh ? 'rgba(10,8,14,0.12)' : 'rgba(98,88,92,0.08)';
    ctx.fillRect(px, py, sz, sz);
    const hv = isAsh ? 110 : 195;
    hctx.fillStyle = `rgba(${hv},${hv},${hv},0.16)`;
    hctx.fillRect(px, py, sz, sz);
    const rv = isAsh ? 210 : 72;
    rctx.fillStyle = `rgba(${rv},${rv},${rv},0.18)`;
    rctx.fillRect(px, py, sz, sz);
  }

  const repeat = 5;
  const map = new THREE.CanvasTexture(diffCanvas);
  map.wrapS = map.wrapT = THREE.RepeatWrapping;
  map.repeat.set(repeat, repeat);
  map.colorSpace = THREE.SRGBColorSpace;

  const normalMap = heightCanvasToNormalTexture(hCanvas, 2.8, repeat);
  const roughnessMap = new THREE.CanvasTexture(roughCanvas);
  roughnessMap.wrapS = roughnessMap.wrapT = THREE.RepeatWrapping;
  roughnessMap.repeat.set(repeat, repeat);

  const metalnessMap = new THREE.CanvasTexture(metalCanvas);
  metalnessMap.wrapS = metalnessMap.wrapT = THREE.RepeatWrapping;
  metalnessMap.repeat.set(repeat, repeat);

  return { map, normalMap, roughnessMap, metalnessMap };
}

function createWeatheredStonePBR() {
  if (typeof document === 'undefined') {
    return { map: null, normalMap: null, roughnessMap: null };
  }
  const size = 256;
  const c = document.createElement('canvas');
  const h = document.createElement('canvas');
  const r = document.createElement('canvas');
  [c, h, r].forEach((cv) => {
    cv.width = size;
    cv.height = size;
  });

  const ctx = c.getContext?.('2d');
  const hctx = h.getContext?.('2d');
  const rctx = r.getContext?.('2d');
  if (!ctx || !hctx || !rctx) {
    return { map: null, normalMap: null, roughnessMap: null };
  }

  ctx.fillStyle = '#322d3a';
  ctx.fillRect(0, 0, size, size);
  hctx.fillStyle = '#9e9e9e';
  hctx.fillRect(0, 0, size, size);
  rctx.fillStyle = '#b4b4b4';
  rctx.fillRect(0, 0, size, size);

  let seed = 9001;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  for (let y = 0; y < size; y += 32) {
    const tone = 42 + ((y * 7) % 16);
    ctx.fillStyle = `rgb(${tone + 4}, ${tone}, ${tone + 9})`;
    ctx.fillRect(0, y + 2, size, 28);
    ctx.fillStyle = '#15121a';
    ctx.fillRect(0, y, size, 3);

    hctx.fillStyle = '#c4c4c4';
    hctx.fillRect(0, y + 3, size, 26);
    hctx.fillStyle = '#222222';
    hctx.fillRect(0, y, size, 3);

    rctx.fillStyle = '#989898';
    rctx.fillRect(0, y + 2, size, 28);
    rctx.fillStyle = '#dedede';
    rctx.fillRect(0, y, size, 3);
  }

  for (let i = 0; i < 650; i++) {
    const px = rand() * size;
    const py = rand() * size;
    ctx.fillStyle = `rgba(12, 10, 16, ${0.12 + rand() * 0.2})`;
    ctx.fillRect(px, py, 3, 3);
    const hv = 110 + Math.floor(rand() * 90);
    hctx.fillStyle = `rgba(${hv},${hv},${hv},0.28)`;
    hctx.fillRect(px, py, 3, 3);
  }

  const map = new THREE.CanvasTexture(c);
  map.wrapS = map.wrapT = THREE.RepeatWrapping;
  map.colorSpace = THREE.SRGBColorSpace;
  const normalMap = heightCanvasToNormalTexture(h, 2.5, 1);
  const roughnessMap = new THREE.CanvasTexture(r);
  roughnessMap.wrapS = roughnessMap.wrapT = THREE.RepeatWrapping;
  return { map, normalMap, roughnessMap };
}

function createForgedMetalPBR(baseTint = '#463b32') {
  if (typeof document === 'undefined') {
    return { map: null, normalMap: null, roughnessMap: null, metalnessMap: null };
  }
  const size = 256;
  const c = document.createElement('canvas');
  const h = document.createElement('canvas');
  const r = document.createElement('canvas');
  const m = document.createElement('canvas');
  [c, h, r, m].forEach((cv) => {
    cv.width = size;
    cv.height = size;
  });

  const ctx = c.getContext?.('2d');
  const hctx = h.getContext?.('2d');
  const rctx = r.getContext?.('2d');
  const mctx = m.getContext?.('2d');
  if (!ctx || !hctx || !rctx || !mctx) {
    return { map: null, normalMap: null, roughnessMap: null, metalnessMap: null };
  }

  ctx.fillStyle = baseTint;
  ctx.fillRect(0, 0, size, size);
  hctx.fillStyle = '#888888';
  hctx.fillRect(0, 0, size, size);
  rctx.fillStyle = '#626262';
  rctx.fillRect(0, 0, size, size);
  mctx.fillStyle = '#e6e6e6';
  mctx.fillRect(0, 0, size, size);

  let seed = 4242;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  // Hammered dimples & brushed scratches
  for (let i = 0; i < 420; i++) {
    const px = rand() * size;
    const py = rand() * size;
    const rad = 3 + rand() * 8;
    const bright = rand() > 0.45;
    hctx.fillStyle = bright ? 'rgba(210,210,210,0.16)' : 'rgba(55,55,55,0.22)';
    hctx.beginPath();
    hctx.arc(px, py, rad, 0, Math.PI * 2);
    hctx.fill();

    rctx.fillStyle = bright ? 'rgba(65,65,65,0.24)' : 'rgba(130,130,130,0.22)';
    rctx.beginPath();
    rctx.arc(px, py, rad, 0, Math.PI * 2);
    rctx.fill();

    ctx.fillStyle = bright ? 'rgba(255,215,170,0.06)' : 'rgba(10,8,10,0.14)';
    ctx.beginPath();
    ctx.arc(px, py, rad, 0, Math.PI * 2);
    ctx.fill();
  }

  const map = new THREE.CanvasTexture(c);
  map.wrapS = map.wrapT = THREE.RepeatWrapping;
  map.colorSpace = THREE.SRGBColorSpace;
  const normalMap = heightCanvasToNormalTexture(h, 2.2, 1);
  const roughnessMap = new THREE.CanvasTexture(r);
  roughnessMap.wrapS = roughnessMap.wrapT = THREE.RepeatWrapping;
  const metalnessMap = new THREE.CanvasTexture(m);
  metalnessMap.wrapS = metalnessMap.wrapT = THREE.RepeatWrapping;
  return { map, normalMap, roughnessMap, metalnessMap };
}

function createSanctumSigilTextures() {
  if (typeof document === 'undefined') {
    return { map: null, emissiveMap: null };
  }
  const size = 512;
  const diffC = document.createElement('canvas');
  const emC = document.createElement('canvas');
  diffC.width = emC.width = size;
  diffC.height = emC.height = size;
  const ctx = diffC.getContext?.('2d');
  const ectx = emC.getContext?.('2d');
  if (!ctx || !ectx) {
    return { map: null, emissiveMap: null };
  }

  ctx.clearRect(0, 0, size, size);
  ectx.fillStyle = '#000000';
  ectx.fillRect(0, 0, size, size);

  const cx = size / 2;
  const cy = size / 2;

  const drawRing = (r, w, col, emCol) => {
    ctx.strokeStyle = col;
    ctx.lineWidth = w;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();

    ectx.strokeStyle = emCol;
    ectx.lineWidth = w;
    ectx.beginPath();
    ectx.arc(cx, cy, r, 0, Math.PI * 2);
    ectx.stroke();
  };

  drawRing(236, 12, '#634a26', '#180c04');
  drawRing(212, 4, '#b8762c', '#ff6d1f');
  drawRing(166, 9, '#544024', '#140804');
  drawRing(150, 3, '#c88935', '#ff8c2e');
  drawRing(92, 6, '#694e28', '#331506');

  // 8 radial sanctuary spoke inlay beams & runic glyphs
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * Math.PI * 2;
    ctx.strokeStyle = '#6c512a';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(a) * 92, cy + Math.sin(a) * 92);
    ctx.lineTo(cx + Math.cos(a) * 236, cy + Math.sin(a) * 236);
    ctx.stroke();

    ectx.strokeStyle = '#e85d1a';
    ectx.lineWidth = 2.5;
    ectx.beginPath();
    ectx.moveTo(cx + Math.cos(a) * 150, cy + Math.sin(a) * 150);
    ectx.lineTo(cx + Math.cos(a) * 212, cy + Math.sin(a) * 212);
    ectx.stroke();

    // Glyph diamond between spokes
    const ga = a + Math.PI / 8;
    const gx = cx + Math.cos(ga) * 188;
    const gy = cy + Math.sin(ga) * 188;
    ectx.fillStyle = '#ff9638';
    ectx.save();
    ectx.translate(gx, gy);
    ectx.rotate(ga);
    ectx.fillRect(-5, -5, 10, 10);
    ectx.restore();
  }

  const map = new THREE.CanvasTexture(diffC);
  map.colorSpace = THREE.SRGBColorSpace;
  const emissiveMap = new THREE.CanvasTexture(emC);
  emissiveMap.colorSpace = THREE.SRGBColorSpace;
  return { map, emissiveMap };
}

function createFlameHaloTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 128;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;
  const g = ctx.createRadialGradient(size / 2, size / 2, 2, size / 2, size / 2, size / 2);
  g.addColorStop(0, 'rgba(255, 240, 190, 1.0)');
  g.addColorStop(0.32, 'rgba(255, 130, 35, 0.55)');
  g.addColorStop(1, 'rgba(255, 60, 10, 0.0)');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createVolumetricShaftTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const w = 64;
  const h = 128;
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  ctx.clearRect(0, 0, w, h);
  if (typeof ctx.createLinearGradient === 'function') {
    const g = ctx.createLinearGradient(0, 0, 0, h);
    g.addColorStop(0.0, 'rgba(255, 255, 255, 0.0)');
    g.addColorStop(0.22, 'rgba(255, 255, 255, 0.85)');
    g.addColorStop(0.65, 'rgba(255, 255, 255, 0.38)');
    g.addColorStop(1.0, 'rgba(255, 255, 255, 0.0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  } else {
    const bands = 16;
    for (let i = 0; i < bands; i++) {
      const t = i / (bands - 1);
      const a = Math.sin(t * Math.PI) * (1 - t * 0.45);
      ctx.fillStyle = `rgba(255,255,255,${a.toFixed(2)})`;
      ctx.fillRect(0, (i * h) / bands, w, h / bands + 1);
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createMistCloudTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 128;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;
  ctx.clearRect(0, 0, size, size);
  const lobes = [
    [64, 64, 58, 0.42],
    [44, 58, 36, 0.32],
    [84, 62, 34, 0.3],
    [62, 78, 32, 0.28],
  ];
  for (const [lx, ly, lr, alpha] of lobes) {
    const g = ctx.createRadialGradient(lx, ly, 2, lx, ly, lr);
    g.addColorStop(0, `rgba(220, 215, 235, ${alpha})`);
    g.addColorStop(0.55, `rgba(170, 155, 195, ${(alpha * 0.4).toFixed(2)})`);
    g.addColorStop(1, 'rgba(120, 105, 145, 0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, size, size);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createAbyssChasmTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 256;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  const half = size / 2;
  const g = ctx.createRadialGradient(half, half, 24, half, half, half);
  g.addColorStop(0.0, '#14090c');
  g.addColorStop(0.45, '#0b070e');
  g.addColorStop(1.0, '#050408');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);

  ctx.strokeStyle = 'rgba(255, 92, 26, 0.34)';
  ctx.lineWidth = 1.6;
  let seed = 7717;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };
  for (let i = 0; i < 18; i++) {
    let a = (i / 18) * Math.PI * 2 + rand() * 0.25;
    let r = 56 + rand() * 14;
    ctx.beginPath();
    ctx.moveTo(half + Math.cos(a) * r, half + Math.sin(a) * r);
    for (let s = 0; s < 4; s++) {
      r += 12 + rand() * 12;
      a += (rand() - 0.5) * 0.22;
      ctx.lineTo(half + Math.cos(a) * r, half + Math.sin(a) * r);
    }
    ctx.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createMacroWeatherTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 512;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  ctx.clearRect(0, 0, size, size);
  const half = size / 2;
  // Perimeter soot & moonlight vignette to break floor tiling regularity
  const edge = ctx.createRadialGradient(half, half, size * 0.16, half, half, half);
  edge.addColorStop(0.0, 'rgba(18, 22, 38, 0.04)');
  edge.addColorStop(0.55, 'rgba(10, 8, 16, 0.22)');
  edge.addColorStop(0.88, 'rgba(6, 5, 10, 0.52)');
  edge.addColorStop(1.0, 'rgba(4, 3, 7, 0.72)');
  ctx.fillStyle = edge;
  ctx.fillRect(0, 0, size, size);

  let seed = 31337;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };
  for (let i = 0; i < 22; i++) {
    const px = rand() * size;
    const py = rand() * size;
    const rad = 24 + rand() * 58;
    const scorch = rand() > 0.45;
    const g = ctx.createRadialGradient(px, py, 2, px, py, rad);
    g.addColorStop(0, scorch ? 'rgba(6, 4, 8, 0.28)' : 'rgba(56, 68, 102, 0.14)');
    g.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, size, size);
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createLavaCrackTexture() {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas');
  if (!c || typeof c.getContext !== 'function') return null;
  const size = 512;
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  if (!ctx) return null;

  ctx.clearRect(0, 0, size, size);
  const half = size / 2;

  let seed = 8089;
  const rand = () => {
    seed = (seed * 16807) % 2147483647;
    return (seed - 1) / 2147483646;
  };

  for (let i = 0; i < 16; i++) {
    let ang = (i / 16) * Math.PI * 2 + (rand() - 0.5) * 0.22;
    let r = 34 + rand() * 24;
    const pts = [[half + Math.cos(ang) * r, half + Math.sin(ang) * r]];
    for (let s = 0; s < 5; s++) {
      r += 24 + rand() * 26;
      ang += (rand() - 0.5) * 0.34;
      pts.push([half + Math.cos(ang) * r, half + Math.sin(ang) * r]);
    }

    // Soft outer magma heat bloom
    ctx.strokeStyle = 'rgba(255, 72, 18, 0.45)';
    ctx.lineWidth = 6.5;
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let k = 1; k < pts.length; k++) ctx.lineTo(pts[k][0], pts[k][1]);
    ctx.stroke();

    // Hot molten fissure core
    ctx.strokeStyle = 'rgba(255, 198, 92, 0.92)';
    ctx.lineWidth = 2.0;
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let k = 1; k < pts.length; k++) ctx.lineTo(pts[k][0], pts[k][1]);
    ctx.stroke();

    // Secondary jagged fork
    const forkPt = pts[2];
    let fAng = ang + (rand() > 0.5 ? 0.55 : -0.55);
    let fx = forkPt[0];
    let fy = forkPt[1];
    ctx.strokeStyle = 'rgba(255, 128, 42, 0.65)';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(fx, fy);
    for (let b = 0; b < 3; b++) {
      fx += Math.cos(fAng) * (18 + rand() * 14);
      fy += Math.sin(fAng) * (18 + rand() * 14);
      fAng += (rand() - 0.5) * 0.4;
      ctx.lineTo(fx, fy);
    }
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export class CathedralArena {
  constructor(scene) {
    this.scene = scene;
    this.group = new THREE.Group();
    this.obstacles = []; // { x, z, radius }
    this.flames = [];
    this.brazierLights = [];
    this.shaftMeshes = [];
    this.phase2Progress = 0;
    this.bossAttackGlow = 0;

    this.stonePBR = createWeatheredStonePBR();
    this.ironPBR = createForgedMetalPBR('#2a262c');
    this.bronzePBR = createForgedMetalPBR('#5c4529');
    this.haloTex = createFlameHaloTexture();
    this.shaftTex = createVolumetricShaftTexture();
    this.mistTex = createMistCloudTexture();
    this.abyssTex = createAbyssChasmTexture();
    this.macroWeatherTex = createMacroWeatherTexture();
    this.lavaCrackTex = createLavaCrackTexture();

    this._buildLighting();
    this._buildSkyAndMoon();
    this._buildFloor();
    this._buildFloorDetails();
    this._buildFloorDebris();
    this._buildRuinedPillars();
    this._buildSentinelStatues();
    this._buildOuterCathedralWalls();
    this._buildVolumetricShafts();
    this._buildBraziers();
    this._buildGroundMist();
    this._buildFloatingEmbers();
    this._buildPreviewPedestal();

    this.scene.add(this.group);
  }

  // Bakes a rich HDR-like twilight & molten-ember IBL environment cubemap for realistic PBR metals
  buildEnvironmentMap(renderer) {
    if (!renderer) return null;
    try {
      const pmrem = new THREE.PMREMGenerator(renderer);
      pmrem.compileEquirectangularShader();

      const envScene = new THREE.Scene();
      envScene.background = new THREE.Color(0x110e1c);

      // Twilight indigo sky dome & crimson volcanic horizon bounce
      const skyDome = new THREE.Mesh(
        new THREE.SphereGeometry(24, 24, 16),
        new THREE.MeshBasicMaterial({ color: 0x1c203d, side: THREE.BackSide })
      );
      envScene.add(skyDome);

      // Cool moonlight zenith patch overhead for steel/basalt specular highlights
      const moonPatch = new THREE.Mesh(
        new THREE.SphereGeometry(5.2, 12, 12),
        new THREE.MeshBasicMaterial({ color: 0xe6f0ff })
      );
      moonPatch.position.set(11, 19, 9);
      envScene.add(moonPatch);

      // Molten apse glow patch behind boss horizon
      const emberPatch = new THREE.Mesh(
        new THREE.SphereGeometry(6.2, 12, 12),
        new THREE.MeshBasicMaterial({ color: 0xff6e28 })
      );
      emberPatch.position.set(-6, 3.5, -18);
      envScene.add(emberPatch);

      // Warm torch ring highlights at horizon
      const orbGeo = new THREE.SphereGeometry(1.9, 8, 8);
      const orbMat = new THREE.MeshBasicMaterial({ color: 0xff9a44 });
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2;
        const orb = new THREE.Mesh(orbGeo, orbMat);
        orb.position.set(Math.cos(a) * 16, 1.5, Math.sin(a) * 16);
        envScene.add(orb);
      }

      const rt = pmrem.fromScene(envScene, 0.04);
      this.envRT = rt;
      const disposedGeos = new Set();
      const disposedMats = new Set();
      envScene.traverse((n) => {
        if (n.geometry && !disposedGeos.has(n.geometry)) {
          disposedGeos.add(n.geometry);
          n.geometry.dispose();
        }
        if (n.material && !disposedMats.has(n.material)) {
          disposedMats.add(n.material);
          n.material.dispose();
        }
      });
      pmrem.dispose();
      return rt.texture;
    } catch (_) {
      return null;
    }
  }

  _buildPreviewPedestal() {
    this.previewPedestal = new THREE.Group();
    const dais = new THREE.Mesh(
      new THREE.CylinderGeometry(2.2, 2.55, 0.34, 28),
      new THREE.MeshStandardMaterial({
        map: this.stonePBR.map,
        normalMap: this.stonePBR.normalMap,
        roughnessMap: this.stonePBR.roughnessMap,
        roughness: 0.55,
        metalness: 0.35,
      })
    );
    dais.position.y = 0.17;
    dais.receiveShadow = true;
    this.previewPedestal.add(dais);

    const trimRing = new THREE.Mesh(
      new THREE.TorusGeometry(2.22, 0.06, 8, 36),
      new THREE.MeshStandardMaterial({
        map: this.bronzePBR.map,
        normalMap: this.bronzePBR.normalMap,
        roughnessMap: this.bronzePBR.roughnessMap,
        metalnessMap: this.bronzePBR.metalnessMap,
        roughness: 0.35,
        metalness: 0.85,
      })
    );
    trimRing.rotation.x = Math.PI / 2;
    trimRing.position.y = 0.34;
    this.previewPedestal.add(trimRing);

    const runeRing = new THREE.Mesh(
      new THREE.RingGeometry(1.75, 1.98, 36),
      new THREE.MeshBasicMaterial({ color: 0xf2a649, side: THREE.DoubleSide, transparent: true, opacity: 0.84 })
    );
    runeRing.rotation.x = -Math.PI / 2;
    runeRing.position.y = 0.355;
    this.previewPedestal.add(runeRing);

    this.previewPedestal.visible = false;
    this.group.add(this.previewPedestal);
  }

  setPreviewMode(active) {
    this.previewPedestal.visible = !!active;
  }

  setQualityTier(tier) {
    if (tier === 'LOW') {
      this.applyRenderQuality({ shadowsEnabled: false, shadowMapSize: 512, arenaAdaptiveLevel: 2 });
    } else if (tier === 'HIGH') {
      this.applyRenderQuality({ shadowsEnabled: true, shadowMapSize: 2048, arenaAdaptiveLevel: 0 });
    } else {
      this.applyRenderQuality({ shadowsEnabled: true, shadowMapSize: 1024, arenaAdaptiveLevel: 0 });
    }
  }

  applyRenderQuality({ shadowsEnabled = true, shadowMapSize = 1024, arenaAdaptiveLevel = 0 } = {}) {
    this.dirLight.castShadow = !!shadowsEnabled;
    if (shadowsEnabled && this.dirLight.shadow.mapSize.x !== shadowMapSize) {
      this.dirLight.shadow.mapSize.set(shadowMapSize, shadowMapSize);
      if (this.dirLight.shadow.map) {
        this.dirLight.shadow.map.dispose();
        this.dirLight.shadow.map = null;
      }
    }

    if (arenaAdaptiveLevel >= 2) {
      this.embers.visible = false;
      this.mistGroup.visible = false;
      if (this.shaftGroup) this.shaftGroup.visible = false;
      if (this.debrisGroup) this.debrisGroup.visible = false;
      if (this.lavaCrackMesh) this.lavaCrackMesh.visible = false;
      for (const bl of this.brazierLights) {
        bl.light.visible = false;
      }
    } else if (arenaAdaptiveLevel === 1) {
      this.embers.visible = true;
      this.mistGroup.visible = false;
      if (this.shaftGroup) this.shaftGroup.visible = true;
      if (this.debrisGroup) this.debrisGroup.visible = true;
      if (this.lavaCrackMesh) this.lavaCrackMesh.visible = true;
      this.brazierLights.forEach((bl, idx) => {
        bl.light.visible = idx < 2;
      });
    } else {
      this.embers.visible = true;
      this.mistGroup.visible = true;
      if (this.shaftGroup) this.shaftGroup.visible = true;
      if (this.debrisGroup) this.debrisGroup.visible = true;
      if (this.lavaCrackMesh) this.lavaCrackMesh.visible = true;
      for (const bl of this.brazierLights) {
        bl.light.visible = true;
      }
    }
  }

  _buildLighting() {
    this.scene.background = new THREE.Color(0x0a0711);
    this.scene.fog = new THREE.FogExp2(0x120c18, 0.0175);

    // Rich hemisphere skylight + volcanic floor bounce for crisp cool/warm separation
    this.hemiLight = new THREE.HemisphereLight(0x7d92db, 0x2f1814, 1.08);
    this.group.add(this.hemiLight);

    // Cool moonlight key light casting crisp cathedral & armor shadows
    this.dirLight = new THREE.DirectionalLight(0xcbe0ff, 2.55);
    this.dirLight.position.set(14, 28, 12);
    this.dirLight.castShadow = true;
    this.dirLight.shadow.mapSize.set(1024, 1024);
    this.dirLight.shadow.camera.near = 2;
    this.dirLight.shadow.camera.far = 70;
    const d = 21;
    this.dirLight.shadow.camera.left = -d;
    this.dirLight.shadow.camera.right = d;
    this.dirLight.shadow.camera.top = d;
    this.dirLight.shadow.camera.bottom = -d;
    this.dirLight.shadow.bias = -0.00045;
    this.dirLight.shadow.normalBias = 0.025;
    this.dirLight.shadow.radius = 2.0;
    this.group.add(this.dirLight);

    // Strong warm rim light from the broken apse behind the boss for unmistakable silhouette readability
    this.apseLight = new THREE.DirectionalLight(0xff6629, 1.85);
    this.apseLight.position.set(-10, 12, -24);
    this.group.add(this.apseLight);
  }

  _buildSkyAndMoon() {
    // Eclipse Blood Moon hanging behind the broken cathedral apse
    const moonGroup = new THREE.Group();
    moonGroup.position.set(-7, 21, -48);

    const moonDisk = new THREE.Mesh(
      new THREE.CircleGeometry(4.6, 32),
      new THREE.MeshBasicMaterial({ color: 0xffe4c4, fog: false })
    );
    moonGroup.add(moonDisk);

    const eclipseCore = new THREE.Mesh(
      new THREE.CircleGeometry(3.85, 32),
      new THREE.MeshBasicMaterial({ color: 0x1a0c14, fog: false })
    );
    eclipseCore.position.z = 0.06;
    moonGroup.add(eclipseCore);

    const coronaMat = new THREE.SpriteMaterial({
      map: this.haloTex,
      color: 0xff7733,
      transparent: true,
      opacity: 0.72,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      fog: false,
    });
    const corona = new THREE.Sprite(coronaMat);
    corona.scale.set(24, 24, 1);
    moonGroup.add(corona);
    this.moonCorona = coronaMat;

    moonGroup.lookAt(0, 2, 0);
    this.group.add(moonGroup);
  }

  _buildFloor() {
    const pbr = createFloorPBRMaps();
    const floorMat = new THREE.MeshStandardMaterial({
      map: pbr.map,
      normalMap: pbr.normalMap,
      normalScale: new THREE.Vector2(1.22, 1.22),
      roughnessMap: pbr.roughnessMap,
      metalnessMap: pbr.metalnessMap,
      roughness: 0.88,
      metalness: 0.24,
      envMapIntensity: 1.55,
    });

    // Main circular sanctuary floor
    const floor = new THREE.Mesh(new THREE.CylinderGeometry(21.4, 22.4, 1.2, 64), floorMat);
    floor.position.y = -0.6;
    floor.receiveShadow = true;
    this.group.add(floor);

    // Ornate carved bronze & glowing runic sanctum inlay disc at arena center
    const sigil = createSanctumSigilTextures();
    this.sigilMat = new THREE.MeshStandardMaterial({
      map: sigil.map,
      emissive: new THREE.Color(0xff6b22),
      emissiveMap: sigil.emissiveMap,
      emissiveIntensity: 1.35,
      roughness: 0.34,
      metalness: 0.78,
      envMapIntensity: 1.45,
      transparent: true,
      opacity: 0.94,
    });
    const sigilDisc = new THREE.Mesh(new THREE.CircleGeometry(10.6, 64), this.sigilMat);
    sigilDisc.rotation.x = -Math.PI / 2;
    sigilDisc.position.y = 0.015;
    sigilDisc.receiveShadow = true;
    this.group.add(sigilDisc);

    // Stone dais rim framing the central runic sanctum inlay
    const daisRimMat = new THREE.MeshStandardMaterial({
      map: this.stonePBR.map,
      normalMap: this.stonePBR.normalMap,
      roughnessMap: this.stonePBR.roughnessMap,
      roughness: 0.68,
      metalness: 0.18,
    });
    const daisRim = new THREE.Mesh(new THREE.RingGeometry(10.58, 11.05, 64), daisRimMat);
    daisRim.rotation.x = -Math.PI / 2;
    daisRim.position.y = 0.019;
    daisRim.receiveShadow = true;
    this.group.add(daisRim);

    // Outer bronze border ring framing playable ring
    const bronzeRingMat = new THREE.MeshStandardMaterial({
      map: this.bronzePBR.map,
      normalMap: this.bronzePBR.normalMap,
      roughnessMap: this.bronzePBR.roughnessMap,
      metalnessMap: this.bronzePBR.metalnessMap,
      roughness: 0.36,
      metalness: 0.85,
      envMapIntensity: 1.5,
    });
    const borderRing = new THREE.Mesh(new THREE.RingGeometry(19.05, 19.35, 72), bronzeRingMat);
    borderRing.rotation.x = -Math.PI / 2;
    borderRing.position.y = 0.018;
    borderRing.receiveShadow = true;
    this.group.add(borderRing);

    // Glowing molten boundary rune ring marking playable radius
    this.boundaryMat = new THREE.MeshBasicMaterial({
      color: 0xe85a24,
      transparent: true,
      opacity: 0.42,
      side: THREE.DoubleSide,
    });
    const boundaryRing = new THREE.Mesh(new THREE.RingGeometry(19.38, 19.62, 72), this.boundaryMat);
    boundaryRing.rotation.x = -Math.PI / 2;
    boundaryRing.position.y = 0.022;
    this.group.add(boundaryRing);

    // Stepped amphitheater outer stone rim + ruined parapet blocks
    const stoneTrimMat = new THREE.MeshStandardMaterial({
      map: this.stonePBR.map,
      normalMap: this.stonePBR.normalMap,
      roughnessMap: this.stonePBR.roughnessMap,
      roughness: 0.72,
      metalness: 0.14,
    });
    for (let stepIdx = 0; stepIdx < 2; stepIdx++) {
      const rIn = 20.8 + stepIdx * 1.3;
      const tier = new THREE.Mesh(new THREE.CylinderGeometry(rIn + 1.4, rIn + 1.6, 0.55 + stepIdx * 0.45, 48, 1, true), stoneTrimMat);
      tier.position.y = 0.25 + stepIdx * 0.25;
      tier.receiveShadow = true;
      this.group.add(tier);
    }

    const curbIndices = [];
    const curbSegments = 36;
    for (let i = 0; i < curbSegments; i++) {
      if (i % 6 !== 2) curbIndices.push(i);
    }
    const curbGeo = new THREE.BoxGeometry(2.9, 1.0, 1.05);
    const curbMesh = new THREE.InstancedMesh(curbGeo, stoneTrimMat, curbIndices.length);
    curbMesh.castShadow = true;
    curbMesh.receiveShadow = true;
    const dummy = new THREE.Object3D();
    curbIndices.forEach((segIdx, instIdx) => {
      const angle = (segIdx / curbSegments) * Math.PI * 2;
      const h = 0.52 + (segIdx % 3) * 0.24;
      dummy.position.set(Math.cos(angle) * 20.5, h * 0.5, Math.sin(angle) * 20.5);
      dummy.rotation.set(0, -angle + Math.PI / 2, 0);
      dummy.scale.set(1, h, 1);
      dummy.updateMatrix();
      curbMesh.setMatrixAt(instIdx, dummy.matrix);
    });
    curbMesh.instanceMatrix.needsUpdate = true;
    this.group.add(curbMesh);

    // Outer abyssal volcanic shelf with glowing magma fissures
    const abyss = new THREE.Mesh(
      new THREE.RingGeometry(21.4, 78, 48),
      new THREE.MeshBasicMaterial({
        map: this.abyssTex || null,
        color: this.abyssTex ? 0xffffff : 0x08060c,
      })
    );
    abyss.rotation.x = -Math.PI / 2;
    abyss.position.y = -1.25;
    this.group.add(abyss);
  }

  _buildFloorDetails() {
    // Macro soot & moonlight vignette disc to break floor tile repetition
    if (this.macroWeatherTex) {
      const weatherDisc = new THREE.Mesh(
        new THREE.CircleGeometry(21.2, 48),
        new THREE.MeshBasicMaterial({
          map: this.macroWeatherTex,
          transparent: true,
          opacity: 0.72,
          depthWrite: false,
        })
      );
      weatherDisc.rotation.x = -Math.PI / 2;
      weatherDisc.position.y = 0.013;
      this.group.add(weatherDisc);
    }

    // Glowing magma fissure overlay reacting to Phase 2 and boss heavy attacks
    this.lavaCrackMat = new THREE.MeshBasicMaterial({
      map: this.lavaCrackTex || null,
      color: 0xff6a24,
      transparent: true,
      opacity: 0.04,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.lavaCrackMesh = new THREE.Mesh(new THREE.CircleGeometry(19.0, 48), this.lavaCrackMat);
    this.lavaCrackMesh.rotation.x = -Math.PI / 2;
    this.lavaCrackMesh.position.y = 0.017;
    this.group.add(this.lavaCrackMesh);
  }

  _buildFloorDebris() {
    this.debrisGroup = new THREE.Group();
    const debrisMat = new THREE.MeshStandardMaterial({
      map: this.stonePBR.map,
      normalMap: this.stonePBR.normalMap,
      roughnessMap: this.stonePBR.roughnessMap,
      roughness: 0.78,
      metalness: 0.14,
    });
    const chunkGeo = new THREE.DodecahedronGeometry(0.28, 0);
    const slabGeo = new THREE.BoxGeometry(0.46, 0.14, 0.34);

    // Debris nestled inside pillar collision footprints (r = 13.8, dist <= 1.05 inside radius 1.32)
    const innerAngles = [Math.PI * 0.27, Math.PI * 0.73, Math.PI * 1.27, Math.PI * 1.73];
    innerAngles.forEach((ang, pIdx) => {
      const px = Math.cos(ang) * 13.8;
      const pz = Math.sin(ang) * 13.8;
      for (let k = 0; k < 3; k++) {
        const subAng = ang + k * 2.1 + pIdx * 0.5;
        const dist = 0.76 + (k % 2) * 0.24;
        const m = new THREE.Mesh(k === 1 ? slabGeo : chunkGeo, debrisMat);
        m.position.set(px + Math.cos(subAng) * dist, k === 1 ? 0.06 : 0.11, pz + Math.sin(subAng) * dist);
        m.rotation.set(k * 0.35, subAng, (pIdx + k) * 0.22);
        m.scale.setScalar(0.78 + (k % 3) * 0.22);
        m.castShadow = false;
        m.receiveShadow = true;
        this.debrisGroup.add(m);
      }
    });

    // Outer parapet fallen basalt rubble strictly outside ARENA_RADIUS (19.2)
    for (let i = 0; i < 8; i++) {
      const ang = (i / 8) * Math.PI * 2 + 0.18;
      const r = 19.45 + (i % 3) * 0.32;
      const m = new THREE.Mesh(i % 2 === 0 ? chunkGeo : slabGeo, debrisMat);
      m.position.set(Math.cos(ang) * r, i % 2 === 0 ? 0.13 : 0.07, Math.sin(ang) * r);
      m.rotation.set(i * 0.4, ang, i * 0.25);
      m.scale.setScalar(0.85 + (i % 3) * 0.2);
      m.castShadow = false;
      m.receiveShadow = true;
      this.debrisGroup.add(m);
    }

    this.group.add(this.debrisGroup);
  }

  _buildRuinedPillars() {
    const pillarMat = new THREE.MeshStandardMaterial({
      map: this.stonePBR.map,
      normalMap: this.stonePBR.normalMap,
      roughnessMap: this.stonePBR.roughnessMap,
      roughness: 0.74,
      metalness: 0.12,
    });
    const ironTrimMat = new THREE.MeshStandardMaterial({
      map: this.ironPBR.map,
      normalMap: this.ironPBR.normalMap,
      roughnessMap: this.ironPBR.roughnessMap,
      metalnessMap: this.ironPBR.metalnessMap,
      roughness: 0.42,
      metalness: 0.85,
    });
    const runeCollarMat = new THREE.MeshStandardMaterial({
      color: 0xff7b2e,
      emissive: 0xff5a18,
      emissiveIntensity: 1.6,
      roughness: 0.25,
      metalness: 0.4,
    });

    // 4 tactical fluted interior pillars with shared geometries
    const plinthGeo = new THREE.CylinderGeometry(1.32, 1.48, 0.72, 8);
    const ironBaseRingGeo = new THREE.TorusGeometry(1.06, 0.08, 8, 16);
    const shaftTallGeo = new THREE.CylinderGeometry(0.84, 0.96, 4.6, 12);
    const shaftShortGeo = new THREE.CylinderGeometry(0.84, 0.96, 3.1, 12);
    const ironCollarGeo = new THREE.CylinderGeometry(0.95, 0.95, 0.22, 12);
    const runeStripGeo = new THREE.TorusGeometry(0.95, 0.032, 6, 18);
    const capGeo = new THREE.CylinderGeometry(0.68, 0.9, 0.58, 7);
    const drumGeo = new THREE.CylinderGeometry(0.55, 0.55, 0.85, 8);

    const innerAngles = [Math.PI * 0.27, Math.PI * 0.73, Math.PI * 1.27, Math.PI * 1.73];
    innerAngles.forEach((ang, idx) => {
      const dist = 13.8;
      const px = Math.cos(ang) * dist;
      const pz = Math.sin(ang) * dist;
      const height = idx % 2 === 0 ? 4.6 : 3.1;

      const pGroup = new THREE.Group();
      pGroup.position.set(px, 0, pz);

      const plinth = new THREE.Mesh(plinthGeo, pillarMat);
      plinth.position.y = 0.36;
      plinth.castShadow = true;
      plinth.receiveShadow = true;
      pGroup.add(plinth);

      const ironBaseRing = new THREE.Mesh(ironBaseRingGeo, ironTrimMat);
      ironBaseRing.rotation.x = Math.PI / 2;
      ironBaseRing.position.y = 0.74;
      pGroup.add(ironBaseRing);

      const shaft = new THREE.Mesh(idx % 2 === 0 ? shaftTallGeo : shaftShortGeo, pillarMat);
      shaft.position.y = 0.72 + height * 0.5;
      shaft.castShadow = true;
      shaft.receiveShadow = true;
      pGroup.add(shaft);

      // Glowing inlaid rune collar & iron clamp halfway up
      const ironCollar = new THREE.Mesh(ironCollarGeo, ironTrimMat);
      ironCollar.position.y = 1.65;
      pGroup.add(ironCollar);

      const runeStrip = new THREE.Mesh(runeStripGeo, runeCollarMat);
      runeStrip.rotation.x = Math.PI / 2;
      runeStrip.position.y = 1.65;
      pGroup.add(runeStrip);

      // Jagged broken capital + fallen column drum
      const cap = new THREE.Mesh(capGeo, pillarMat);
      cap.position.set(0.08, 0.72 + height + 0.2, -0.06);
      cap.rotation.set(0.2, idx, -0.15);
      cap.castShadow = true;
      pGroup.add(cap);

      const drum = new THREE.Mesh(drumGeo, pillarMat);
      drum.position.set(1.22, 0.42, 0.68);
      drum.rotation.set(Math.PI * 0.42, idx * 0.7, 0.45);
      drum.castShadow = true;
      drum.receiveShadow = true;
      pGroup.add(drum);

      this.group.add(pGroup);
      this.obstacles.push({ x: px, z: pz, radius: 1.32 });
    });
  }

  _buildSentinelStatues() {
    // 6 monumental oxidized bronze & iron guardian statues ringing the colonnade
    const bronzeMat = new THREE.MeshStandardMaterial({
      map: this.bronzePBR.map,
      normalMap: this.bronzePBR.normalMap,
      roughnessMap: this.bronzePBR.roughnessMap,
      metalnessMap: this.bronzePBR.metalnessMap,
      roughness: 0.44,
      metalness: 0.78,
    });
    const stonePedestalMat = new THREE.MeshStandardMaterial({
      map: this.stonePBR.map,
      normalMap: this.stonePBR.normalMap,
      roughnessMap: this.stonePBR.roughnessMap,
      roughness: 0.78,
      metalness: 0.14,
    });
    const emberEyeMat = new THREE.MeshBasicMaterial({ color: 0xff6e24 });

    const pedestalGeo = new THREE.BoxGeometry(2.0, 1.5, 2.0);
    const robeGeo = new THREE.CylinderGeometry(0.55, 0.92, 2.8, 8);
    const torsoGeo = new THREE.BoxGeometry(1.35, 1.2, 0.75);
    const headGeo = new THREE.CylinderGeometry(0.28, 0.34, 0.65, 6);
    const crownGeo = new THREE.ConeGeometry(0.32, 0.42, 6);
    const eyeGeo = new THREE.SphereGeometry(0.045, 6, 6);
    const swordGeo = new THREE.BoxGeometry(0.22, 3.6, 0.1);
    const crossGeo = new THREE.BoxGeometry(0.85, 0.16, 0.22);

    const count = 6;
    const radius = 21.6;
    for (let i = 0; i < count; i++) {
      const ang = (i / count) * Math.PI * 2 + Math.PI / 6;
      const sx = Math.cos(ang) * radius;
      const sz = Math.sin(ang) * radius;

      const sGroup = new THREE.Group();
      sGroup.position.set(sx, 0, sz);
      sGroup.lookAt(0, 0, 0);

      const pedestal = new THREE.Mesh(pedestalGeo, stonePedestalMat);
      pedestal.position.y = 0.75;
      pedestal.castShadow = true;
      pedestal.receiveShadow = true;
      sGroup.add(pedestal);

      const robe = new THREE.Mesh(robeGeo, bronzeMat);
      robe.position.y = 2.9;
      robe.castShadow = true;
      sGroup.add(robe);

      const torso = new THREE.Mesh(torsoGeo, bronzeMat);
      torso.position.y = 4.65;
      torso.castShadow = true;
      sGroup.add(torso);

      const head = new THREE.Mesh(headGeo, bronzeMat);
      head.position.y = 5.55;
      sGroup.add(head);

      const crown = new THREE.Mesh(crownGeo, bronzeMat);
      crown.position.y = 6.02;
      sGroup.add(crown);

      // Faint glowing sentinel eyes gazing into the pit
      [-0.09, 0.09].forEach((ex) => {
        const eye = new THREE.Mesh(eyeGeo, emberEyeMat);
        eye.position.set(ex, 5.58, 0.28);
        sGroup.add(eye);
      });

      // Resting colossal stone greatsword in front
      const sword = new THREE.Mesh(swordGeo, bronzeMat);
      sword.position.set(0, 3.25, 0.7);
      sGroup.add(sword);

      const cross = new THREE.Mesh(crossGeo, bronzeMat);
      cross.position.set(0, 4.75, 0.7);
      sGroup.add(cross);

      this.group.add(sGroup);
    }
  }

  _buildOuterCathedralWalls() {
    const archMat = new THREE.MeshStandardMaterial({
      map: this.stonePBR.map,
      normalMap: this.stonePBR.normalMap,
      roughnessMap: this.stonePBR.roughnessMap,
      roughness: 0.78,
      metalness: 0.15,
    });
    const ironBandMat = new THREE.MeshStandardMaterial({
      map: this.ironPBR.map,
      normalMap: this.ironPBR.normalMap,
      roughnessMap: this.ironPBR.roughnessMap,
      metalnessMap: this.ironPBR.metalnessMap,
      roughness: 0.45,
      metalness: 0.85,
    });

    // 12 towering cathedral buttress piers & gothic arches around the colonnade (shared geometries)
    const count = 12;
    const outerR = 23.6;
    const spanConst = 2 * outerR * Math.sin(Math.PI / count);
    const colTallGeo = new THREE.BoxGeometry(2.2, 15.5, 2.2);
    const colShortGeo = new THREE.BoxGeometry(2.2, 11.2, 2.2);
    const bandGeo = new THREE.BoxGeometry(2.36, 0.35, 2.36);
    const ribGeo = new THREE.BoxGeometry(spanConst * 0.56, 0.95, 1.15);
    const keystoneGeo = new THREE.BoxGeometry(1.1, 1.45, 1.35);
    const wallGeo = new THREE.BoxGeometry(spanConst * 0.86, 8.6, 0.72);

    for (let i = 0; i < count; i++) {
      const ang = (i / count) * Math.PI * 2;
      const x = Math.cos(ang) * outerR;
      const z = Math.sin(ang) * outerR;
      const isTall = i % 3 === 0;
      const h = isTall ? 15.5 : 11.2;

      const col = new THREE.Mesh(isTall ? colTallGeo : colShortGeo, archMat);
      col.position.set(x, h * 0.5 - 0.5, z);
      col.rotation.y = -ang;
      col.castShadow = true;
      col.receiveShadow = true;
      this.group.add(col);

      const band = new THREE.Mesh(bandGeo, ironBandMat);
      band.position.set(x, 4.6, z);
      band.rotation.y = -ang;
      this.group.add(band);

      if (Math.sin(ang) < 0.35) {
        const nextAng = ((i + 1) / count) * Math.PI * 2;
        const nx = Math.cos(nextAng) * outerR;
        const nz = Math.sin(nextAng) * outerR;
        const mx = (x + nx) * 0.5;
        const mz = (z + nz) * 0.5;
        const spanYaw = -Math.atan2(nz - z, nx - x);

        // Gothic pointed ribbed arch pair meeting at apex keystone
        const leftRib = new THREE.Mesh(ribGeo, archMat);
        leftRib.position.set((x + mx) * 0.5, 10.6, (z + mz) * 0.5);
        leftRib.rotation.y = spanYaw;
        leftRib.rotation.z = 0.32;
        this.group.add(leftRib);

        const rightRib = new THREE.Mesh(ribGeo, archMat);
        rightRib.position.set((nx + mx) * 0.5, 10.6, (nz + mz) * 0.5);
        rightRib.rotation.y = spanYaw;
        rightRib.rotation.z = -0.32;
        this.group.add(rightRib);

        const keystone = new THREE.Mesh(keystoneGeo, ironBandMat);
        keystone.position.set(mx, 11.45, mz);
        keystone.rotation.y = spanYaw;
        this.group.add(keystone);

        if (i % 2 === 0) {
          const wall = new THREE.Mesh(wallGeo, archMat);
          wall.position.set(mx * 1.07, 4.0, mz * 1.07);
          wall.rotation.y = spanYaw;
          this.group.add(wall);
        }
      }
    }

    // North Apse Gothic Rose Window & Ruined Altar Dais behind the Boss (r >= 21.8, strictly outside arena)
    const apseGroup = new THREE.Group();
    apseGroup.position.set(0, 0, -24.2);

    const altarStep1 = new THREE.Mesh(new THREE.BoxGeometry(9.6, 0.45, 3.2), archMat);
    altarStep1.position.set(0, 0.22, 1.4);
    altarStep1.receiveShadow = true;
    apseGroup.add(altarStep1);

    const altarStep2 = new THREE.Mesh(new THREE.BoxGeometry(6.8, 0.55, 2.1), archMat);
    altarStep2.position.set(0, 0.72, 1.1);
    altarStep2.receiveShadow = true;
    apseGroup.add(altarStep2);

    const roseOuter = new THREE.Mesh(new THREE.TorusGeometry(3.4, 0.32, 8, 28), archMat);
    roseOuter.position.set(0, 9.6, -0.4);
    apseGroup.add(roseOuter);

    const roseGlass = new THREE.Mesh(
      new THREE.CircleGeometry(3.22, 24),
      new THREE.MeshBasicMaterial({
        color: 0xff5a22,
        transparent: true,
        opacity: 0.24,
        side: THREE.DoubleSide,
      })
    );
    roseGlass.position.set(0, 9.6, -0.45);
    apseGroup.add(roseGlass);

    const spokeGeo = new THREE.BoxGeometry(0.16, 6.4, 0.22);
    for (let s = 0; s < 8; s++) {
      const spoke = new THREE.Mesh(spokeGeo, ironBandMat);
      spoke.position.set(0, 9.6, -0.38);
      spoke.rotation.z = (s / 8) * Math.PI;
      apseGroup.add(spoke);
    }
    if (this.haloTex) {
      const roseHalo = new THREE.Sprite(
        new THREE.SpriteMaterial({
          map: this.haloTex,
          color: 0xff6e2b,
          transparent: true,
          opacity: 0.42,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
        })
      );
      roseHalo.position.set(0, 9.6, -0.55);
      roseHalo.scale.set(9.6, 9.6, 1);
      apseGroup.add(roseHalo);
    }
    this.group.add(apseGroup);

    // Distant jagged Gothic spire silhouettes batched into a single InstancedMesh draw call
    const spireMat = new THREE.MeshBasicMaterial({ color: 0x120d19 });
    const spireGeo = new THREE.ConeGeometry(2.6, 24, 5);
    const spireMesh = new THREE.InstancedMesh(spireGeo, spireMat, 8);
    const spireDummy = new THREE.Object3D();
    for (let i = 0; i < 8; i++) {
      const ang = (i / 8) * Math.PI * 2 + 0.2;
      spireDummy.position.set(Math.cos(ang) * 40, 8.5, Math.sin(ang) * 40);
      spireDummy.updateMatrix();
      spireMesh.setMatrixAt(i, spireDummy.matrix);
    }
    spireMesh.instanceMatrix.needsUpdate = true;
    this.group.add(spireMesh);
  }

  _buildVolumetricShafts() {
    this.shaftGroup = new THREE.Group();
    const shaftGeo = new THREE.CylinderGeometry(1.15, 3.4, 24, 10, 1, true);
    const configs = [
      { x: 7.5, y: 10.5, z: 4.5, rx: 0.22, rz: -0.28, color: 0x90b6ff, baseOpacity: 0.068, warm: false },
      { x: -6.8, y: 10.8, z: 6.2, rx: 0.18, rz: -0.24, color: 0x89aef8, baseOpacity: 0.056, warm: false },
      { x: 2.2, y: 11.2, z: -2.5, rx: 0.24, rz: -0.22, color: 0x9ec2ff, baseOpacity: 0.062, warm: false },
      { x: -4.2, y: 10.2, z: -15.5, rx: 0.34, rz: 0.14, color: 0xff7533, baseOpacity: 0.075, warm: true },
      { x: 4.2, y: 10.2, z: -15.5, rx: 0.34, rz: -0.14, color: 0xff6b28, baseOpacity: 0.075, warm: true },
    ];
    for (let i = 0; i < configs.length; i++) {
      const cfg = configs[i];
      const mat = new THREE.MeshBasicMaterial({
        map: this.shaftTex || null,
        color: cfg.color,
        transparent: true,
        opacity: cfg.baseOpacity,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(shaftGeo, mat);
      mesh.position.set(cfg.x, cfg.y, cfg.z);
      mesh.rotation.set(cfg.rx, 0, cfg.rz);
      this.shaftGroup.add(mesh);
      this.shaftMeshes.push({ mesh, mat, baseOpacity: cfg.baseOpacity, warm: cfg.warm, phase: i * 1.4 });
    }
    this.group.add(this.shaftGroup);
  }

  _buildBraziers() {
    const ironMat = new THREE.MeshStandardMaterial({
      map: this.ironPBR.map,
      normalMap: this.ironPBR.normalMap,
      roughnessMap: this.ironPBR.roughnessMap,
      metalnessMap: this.ironPBR.metalnessMap,
      roughness: 0.38,
      metalness: 0.88,
    });
    const bronzeRimMat = new THREE.MeshStandardMaterial({
      map: this.bronzePBR.map,
      normalMap: this.bronzePBR.normalMap,
      roughnessMap: this.bronzePBR.roughnessMap,
      metalnessMap: this.bronzePBR.metalnessMap,
      roughness: 0.34,
      metalness: 0.86,
    });
    const coalMat = new THREE.MeshBasicMaterial({ color: 0xff5a1f });
    const flameMat = new THREE.MeshBasicMaterial({
      color: 0xff9a36,
      transparent: true,
      opacity: 0.88,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const standGeo = new THREE.CylinderGeometry(0.42, 0.72, 1.38, 6);
    const bowlGeo = new THREE.CylinderGeometry(0.88, 0.44, 0.52, 8);
    const rimGeo = new THREE.TorusGeometry(0.84, 0.07, 6, 12);
    const coalGeo = new THREE.SphereGeometry(0.62, 8, 6);
    const flameGeo = new THREE.ConeGeometry(0.46, 1.45, 6);
    const haloMat = new THREE.SpriteMaterial({
      map: this.haloTex,
      color: 0xff8a30,
      transparent: true,
      opacity: 0.58,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const angles = [0.15, 1.15, 2.0, 3.3, 4.25, 5.2];
    angles.forEach((ang, idx) => {
      const r = 18.0;
      const bx = Math.cos(ang) * r;
      const bz = Math.sin(ang) * r;

      const bGroup = new THREE.Group();
      bGroup.position.set(bx, 0, bz);

      const stand = new THREE.Mesh(standGeo, ironMat);
      stand.position.y = 0.69;
      stand.castShadow = true;
      stand.receiveShadow = true;
      bGroup.add(stand);

      const bowl = new THREE.Mesh(bowlGeo, ironMat);
      bowl.position.y = 1.52;
      bowl.castShadow = true;
      bGroup.add(bowl);

      const rim = new THREE.Mesh(rimGeo, bronzeRimMat);
      rim.rotation.x = Math.PI / 2;
      rim.position.y = 1.78;
      bGroup.add(rim);

      const coals = new THREE.Mesh(coalGeo, coalMat);
      coals.scale.y = 0.46;
      coals.position.y = 1.7;
      bGroup.add(coals);

      const flame = new THREE.Mesh(flameGeo, flameMat);
      flame.position.y = 2.3;
      bGroup.add(flame);

      const halo = new THREE.Sprite(haloMat);
      halo.position.y = 2.35;
      halo.scale.set(3.4, 3.4, 1);
      bGroup.add(halo);

      this.flames.push({ mesh: flame, halo, baseY: 2.3, phase: idx * 1.3 });

      if (idx % 2 === 0) {
        const pl = new THREE.PointLight(0xff7728, 6.2, 21, 1.45);
        pl.position.set(bx, 2.8, bz);
        this.group.add(pl);
        this.brazierLights.push({ light: pl, baseIntensity: 6.2, phase: idx });
      }

      this.group.add(bGroup);
      this.obstacles.push({ x: bx, z: bz, radius: 0.9 });
    });
  }

  _buildGroundMist() {
    this.mistGroup = new THREE.Group();
    const mistTex = this.mistTex || this.haloTex;
    this.mistSprites = [];
    for (let i = 0; i < 16; i++) {
      const a = (i / 16) * Math.PI * 2;
      const r = 12.2 + (i % 4) * 2.8;
      const mat = new THREE.SpriteMaterial({
        map: mistTex,
        color: i % 3 === 0 ? 0x4b3354 : 0x352c48,
        transparent: true,
        opacity: 0.2,
        depthWrite: false,
      });
      const sp = new THREE.Sprite(mat);
      sp.position.set(Math.cos(a) * r, 0.65, Math.sin(a) * r);
      sp.scale.set(10.5, 2.8, 1);
      this.mistGroup.add(sp);
      this.mistSprites.push({ sp, angle: a, r, speed: 0.042 + (i % 4) * 0.012 });
    }
    this.group.add(this.mistGroup);
  }

  _buildFloatingEmbers() {
    this.emberCount = 280;
    const positions = new Float32Array(this.emberCount * 3);
    const colors = new Float32Array(this.emberCount * 3);
    this.emberMeta = [];

    const emberA = new THREE.Color(0xff7b28);
    const emberB = new THREE.Color(0xffcc66);
    const ashCol = new THREE.Color(0xb6aec4);

    for (let i = 0; i < this.emberCount; i++) {
      const r = Math.sqrt(Math.random()) * 22;
      const a = Math.random() * Math.PI * 2;
      const isAsh = i % 3 === 0;
      positions[i * 3] = Math.cos(a) * r;
      positions[i * 3 + 1] = Math.random() * 14;
      positions[i * 3 + 2] = Math.sin(a) * r;

      const c = isAsh ? ashCol : i % 2 === 0 ? emberA : emberB;
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;

      this.emberMeta.push({
        speed: isAsh ? 0.35 + Math.random() * 0.65 : 0.9 + Math.random() * 2.1,
        swirl: Math.random() * Math.PI * 2,
        drift: isAsh ? 0.8 + Math.random() * 0.9 : 0.4 + Math.random() * 0.8,
        isAsh,
      });
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    this.emberMat = new THREE.PointsMaterial({
      color: 0xffffff,
      vertexColors: true,
      map: this.haloTex,
      size: 0.24,
      transparent: true,
      opacity: 0.86,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    this.embers = new THREE.Points(geo, this.emberMat);
    this.group.add(this.embers);
  }

  setPhase2Intensity(active) {
    this.targetPhase2 = active ? 1 : 0;
  }

  triggerBossAttackGlow(strength = 1.0) {
    this.bossAttackGlow = Math.max(this.bossAttackGlow || 0, Math.min(1.6, Number(strength) || 1.0));
  }

  resolveObstacleCollision(pos, entityRadius = 0.65) {
    const distCenter = Math.hypot(pos.x, pos.z);
    const maxR = ARENA_RADIUS - entityRadius;
    if (distCenter > maxR && distCenter > 0.0001) {
      const s = maxR / distCenter;
      pos.x *= s;
      pos.z *= s;
    }

    for (let i = 0; i < this.obstacles.length; i++) {
      const ob = this.obstacles[i];
      const dx = pos.x - ob.x;
      const dz = pos.z - ob.z;
      const minD = ob.radius + entityRadius;
      const dSq = dx * dx + dz * dz;
      if (dSq < minD * minD && dSq > 0.00001) {
        const d = Math.sqrt(dSq);
        const push = (minD - d) / d;
        pos.x += dx * push;
        pos.z += dz * push;
      }
    }
  }

  update(dt, elapsed) {
    const target = this.targetPhase2 || 0;
    this.phase2Progress += (target - this.phase2Progress) * Math.min(1, dt * 2.2);
    this.bossAttackGlow = Math.max(0, (this.bossAttackGlow || 0) - dt * 1.45);

    this.scene.fog.color.setRGB(
      0.068 + this.phase2Progress * 0.092,
      0.045 + this.phase2Progress * 0.012,
      0.095 - this.phase2Progress * 0.046
    );
    this.scene.fog.density = 0.0175 + this.phase2Progress * 0.0055;
    this.hemiLight.groundColor.setRGB(
      0.184 + this.phase2Progress * 0.28,
      0.094 + this.phase2Progress * 0.045,
      0.078 - this.phase2Progress * 0.028
    );
    this.apseLight.intensity = 1.85 + this.phase2Progress * 1.65 + this.bossAttackGlow * 1.15;
    this.sigilMat.emissiveIntensity = 1.2 + Math.sin(elapsed * 2.4) * 0.25 + this.phase2Progress * 1.35 + this.bossAttackGlow * 0.85;
    this.boundaryMat.opacity = 0.36 + Math.sin(elapsed * 2.5) * 0.06 + this.phase2Progress * 0.3;
    if (this.lavaCrackMat) {
      const pulse = 0.9 + Math.sin(elapsed * 3.8) * 0.1;
      this.lavaCrackMat.opacity = Math.min(
        0.68,
        (0.04 + this.phase2Progress * 0.24 + this.bossAttackGlow * 0.38) * pulse
      );
    }
    if (this.moonCorona) {
      this.moonCorona.opacity = 0.68 + this.phase2Progress * 0.28 + Math.sin(elapsed * 1.8) * 0.05;
    }

    if (this.shaftGroup?.visible) {
      for (let i = 0; i < this.shaftMeshes.length; i++) {
        const s = this.shaftMeshes[i];
        const shimmer = 0.88 + Math.sin(elapsed * 1.3 + s.phase) * 0.14;
        const p2Boost = s.warm ? 1 + this.phase2Progress * 0.55 : 1 - this.phase2Progress * 0.15;
        s.mat.opacity = s.baseOpacity * shimmer * p2Boost;
      }
    }

    for (let i = 0; i < this.flames.length; i++) {
      const f = this.flames[i];
      const flicker = 0.88 + Math.sin(elapsed * 9.5 + f.phase) * 0.16 + Math.cos(elapsed * 15 + f.phase) * 0.08;
      f.mesh.scale.set(1, flicker * (1 + this.phase2Progress * 0.35), 1);
      f.mesh.position.y = f.baseY + (flicker - 1) * 0.35;
      const hScale = 3.2 + flicker * 0.5 + this.phase2Progress * 0.8;
      f.halo.scale.set(hScale, hScale, 1);
    }

    for (let i = 0; i < this.brazierLights.length; i++) {
      const bl = this.brazierLights[i];
      bl.light.intensity =
        (bl.baseIntensity + this.phase2Progress * 2.8) *
        (0.86 + Math.sin(elapsed * 11 + bl.phase * 2) * 0.14);
    }

    if (this.mistGroup.visible) {
      for (let i = 0; i < this.mistSprites.length; i++) {
        const m = this.mistSprites[i];
        m.angle += m.speed * dt;
        m.sp.position.x = Math.cos(m.angle) * m.r;
        m.sp.position.z = Math.sin(m.angle) * m.r;
      }
    }

    if (this.embers.visible) {
      const posAttr = this.embers.geometry.getAttribute('position');
      const arr = posAttr.array;
      const speedMult = 1 + this.phase2Progress * 1.35;
      for (let i = 0; i < this.emberCount; i++) {
        const meta = this.emberMeta[i];
        const idx = i * 3;
        arr[idx] += Math.cos(elapsed * 0.9 + meta.swirl) * meta.drift * dt;
        arr[idx + 1] += meta.speed * (meta.isAsh ? 1.0 : speedMult) * dt;
        arr[idx + 2] += Math.sin(elapsed * 0.8 + meta.swirl) * meta.drift * dt;

        if (arr[idx + 1] > 14.5) {
          const r = Math.sqrt(Math.random()) * 21;
          const a = Math.random() * Math.PI * 2;
          arr[idx] = Math.cos(a) * r;
          arr[idx + 1] = 0.1;
          arr[idx + 2] = Math.sin(a) * r;
        }
      }
      posAttr.needsUpdate = true;
      this.emberMat.size = 0.24 + this.phase2Progress * 0.1;
    }
  }

  dispose() {
    const disposedGeos = new Set();
    const disposedMats = new Set();
    const disposedTex = new Set();
    this.group.traverse((n) => {
      if (n.geometry && !disposedGeos.has(n.geometry)) {
        disposedGeos.add(n.geometry);
        n.geometry.dispose();
      }
      if (n.material) {
        const mats = Array.isArray(n.material) ? n.material : [n.material];
        for (const m of mats) {
          if (!m || disposedMats.has(m)) continue;
          disposedMats.add(m);
          for (const key of Object.keys(m)) {
            const v = m[key];
            if (v && typeof v === 'object' && v.isTexture && !disposedTex.has(v)) {
              disposedTex.add(v);
              v.dispose();
            }
          }
          m.dispose();
        }
      }
    });
    this.haloTex?.dispose?.();
    this.shaftTex?.dispose?.();
    this.mistTex?.dispose?.();
    this.abyssTex?.dispose?.();
    this.macroWeatherTex?.dispose?.();
    this.lavaCrackTex?.dispose?.();
    this.envRT?.dispose?.();
    if (this.scene.environment === this.envRT?.texture) {
      this.scene.environment = null;
    }
    this.scene.remove(this.group);
  }
}
