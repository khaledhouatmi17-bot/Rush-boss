package com.example

import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.game.GameViewModel
import com.example.game.GameWebView
import com.example.game.ModelStorageManager
import com.example.ui.BOSS_PRESETS
import com.example.ui.GameOverlays
import com.example.ui.theme.BossRushTheme
import org.json.JSONObject

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    configureImmersiveMode()

    setContent {
      BossRushTheme {
        val gameViewModel: GameViewModel = viewModel()
        val uiState by gameViewModel.uiState.collectAsStateWithLifecycle()
        var webViewRef by remember { mutableStateOf<WebView?>(null) }

        LaunchedEffect(Unit) { gameViewModel.loadPersistedPrefs(this@MainActivity) }

        LaunchedEffect(uiState.resultReady, uiState.phase) {
          if (uiState.resultReady) {
            gameViewModel.recordBattleOutcomeIfNeeded(this@MainActivity)
          }
        }

        val glbPickerLauncher =
          rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@rememberLauncherForActivityResult
            val role = uiState.selectedArmoryRole
            val result = ModelStorageManager.importPendingModel(this@MainActivity, role, uri)
            if (!result.success) {
              gameViewModel.setPreviewError(role, result.displayName, result.error)
            } else {
              val urlJson = JSONObject.quote(result.previewUrl)
              val labelJson = JSONObject.quote(result.displayName)
              webViewRef?.evaluateJavascript(
                "window.GameAPI?.previewGLB('$role', $urlJson, $labelJson)",
                null,
              )
            }
          }

        fun previewCurrentSelectionForRole(role: String) {
          val wv = webViewRef ?: return
          val activeCustomUrl = ModelStorageManager.getActiveCustomModelUrl(this@MainActivity, role)
          if (activeCustomUrl != null) {
            val label =
              when (role) {
                "player" -> uiState.playerCustomName ?: "Custom Player.glb"
                "boss" -> uiState.bossCustomName ?: "Custom Boss.glb"
                else -> uiState.minionCustomName ?: "Custom Minion.glb"
              }
            wv.evaluateJavascript(
              "window.GameAPI?.previewGLB('$role', ${JSONObject.quote(activeCustomUrl)}, ${JSONObject.quote(label)})",
              null,
            )
          } else {
            val (presetId, label) =
              when (role) {
                "boss" ->
                  uiState.bossPresetId to
                    when (uiState.bossPresetId) {
                      "void_colossus" -> "Void Colossus"
                      "skeleton_warlord" -> "Skeleton Warlord"
                      else -> "Ashen Behemoth"
                    }
                "minion" ->
                  uiState.minionPresetId to
                    if (uiState.minionPresetId == "obsidian_sentinel") "Obsidian Sentinel"
                    else "Cinder Imp"
                else ->
                  uiState.playerPresetId to
                    if (uiState.playerPresetId == "crimson_paladin") "Barbarian Warlord"
                    else "Aegis Knight"
              }
            wv.evaluateJavascript(
              "window.GameAPI?.previewPreset('$role', '$presetId', ${JSONObject.quote(label)})",
              null,
            )
          }
        }

        Box(modifier = Modifier.fillMaxSize()) {
          GameWebView(
            modifier = Modifier.fillMaxSize(),
            onWebViewReady = { webViewRef = it },
            onPageReady = { wv ->
              val current = gameViewModel.uiState.value
              wv.evaluateJavascript(
                "window.GameAPI?.setMuted(${current.isMuted});" +
                  "window.GameAPI?.setMasterVolume(${current.masterVolume});" +
                  "window.GameAPI?.setMusicVolume(${current.musicVolume});" +
                  "window.GameAPI?.setSfxVolume(${current.sfxVolume});" +
                  "window.GameAPI?.setQuality('${current.qualityTier.name}');" +
                  "window.GameAPI?.setCameraSensitivity(${current.cameraSensitivity});" +
                  "window.GameAPI?.setInvertCameraY(${current.invertCameraY});" +
                  "window.GameAPI?.setControlScale(${current.controlScale});",
                null,
              )
              if (current.playerPresetId != "vanguard") {
                wv.evaluateJavascript("window.GameAPI?.selectPlayerPreset('${current.playerPresetId}')", null)
              }
              if (current.bossPresetId != "ashen_behemoth") {
                wv.evaluateJavascript("window.GameAPI?.selectBossPreset('${current.bossPresetId}')", null)
              }
              listOf("player", "boss", "minion").forEach { role ->
                ModelStorageManager.getActiveCustomModelUrl(this@MainActivity, role)?.let { url ->
                  wv.evaluateJavascript(
                    "window.GameAPI?.applySavedGLB('$role', ${JSONObject.quote(url)})",
                    null,
                  )
                }
              }
            },
            onStateJson = { json -> gameViewModel.onBridgeStateJson(json) },
            onPreviewMetaJson = { json -> gameViewModel.onPreviewMetaJson(json) },
            onGameErrorJson = { json -> gameViewModel.onGameErrorJson(json) },
            onRuntimeError = { msg -> gameViewModel.setRuntimeError(msg) },
          )

          GameOverlays(
            uiState = uiState,
            onStartBattle = {
              webViewRef?.requestFocus()
              webViewRef?.evaluateJavascript("window.GameAPI?.startIntro()", null)
            },
            onSelectBossPreset = { presetId ->
              ModelStorageManager.clearRoleModels(this@MainActivity, "boss")
              gameViewModel.selectBossPreset(this@MainActivity, presetId)
              webViewRef?.evaluateJavascript("window.GameAPI?.selectBossPreset('$presetId')", null)
            },
            onOpenArmory = { previewCurrentSelectionForRole(uiState.selectedArmoryRole) },
            onSelectArmoryRole = { role ->
              gameViewModel.setSelectedArmoryRole(role)
              previewCurrentSelectionForRole(role)
            },
            onPreviewPreset = { role, presetId, label ->
              webViewRef?.evaluateJavascript(
                "window.GameAPI?.previewPreset('$role', '$presetId', ${JSONObject.quote(label)})",
                null,
              )
            },
            onImportGlbClicked = {
              glbPickerLauncher.launch(
                arrayOf("model/gltf-binary", "model/gltf+json", "application/octet-stream", "*/*")
              )
            },
            onPlayPreviewClip = { clipName ->
              webViewRef?.evaluateJavascript(
                "window.GameAPI?.playPreviewClip(${JSONObject.quote(clipName)})",
                null,
              )
            },
            onApplyPreviewModel = {
              val meta = uiState.previewMeta
              val role = meta.role
              if (meta.isCustom) {
                val activeUrl = ModelStorageManager.promotePendingToActive(this@MainActivity, role)
                if (activeUrl != null) {
                  gameViewModel.markModelApplied(this@MainActivity, role, meta.label, null)
                  webViewRef?.evaluateJavascript(
                    "window.GameAPI?.confirmPreview(${JSONObject.quote(activeUrl)})",
                    null,
                  )
                } else {
                  webViewRef?.evaluateJavascript("window.GameAPI?.exitPreview()", null)
                }
              } else {
                ModelStorageManager.clearRoleModels(this@MainActivity, role)
                val presetId =
                  when (meta.label) {
                    "Barbarian Warlord", "Crimson Paladin" -> "crimson_paladin"
                    "Void Colossus" -> "void_colossus"
                    "Skeleton Warlord" -> "skeleton_warlord"
                    "Obsidian Sentinel" -> "obsidian_sentinel"
                    "Cinder Imp" -> "cinder_imp"
                    "Ashen Behemoth" -> "ashen_behemoth"
                    else -> "vanguard"
                  }
                gameViewModel.markModelApplied(this@MainActivity, role, null, presetId)
                webViewRef?.evaluateJavascript("window.GameAPI?.confirmPreview(null)", null)
              }
            },
            onResetDefaultModel = { role ->
              ModelStorageManager.clearRoleModels(this@MainActivity, role)
              val defaultPreset =
                when (role) {
                  "boss" -> "ashen_behemoth"
                  "minion" -> "cinder_imp"
                  else -> "vanguard"
                }
              val defaultLabel =
                when (role) {
                  "boss" -> "Ashen Behemoth"
                  "minion" -> "Cinder Imp"
                  else -> "Aegis Knight"
                }
              gameViewModel.markModelApplied(this@MainActivity, role, null, defaultPreset)
              webViewRef?.evaluateJavascript(
                "window.GameAPI?.resetModelToDefault('$role', '$defaultPreset');" +
                  "window.GameAPI?.previewPreset('$role', '$defaultPreset', ${JSONObject.quote(defaultLabel)});",
                null,
              )
            },
            onExitArmory = {
              webViewRef?.evaluateJavascript("window.GameAPI?.exitPreview()", null)
            },
            onSkipIntro = {
              webViewRef?.requestFocus()
              webViewRef?.evaluateJavascript("window.GameAPI?.skipIntro()", null)
            },
            onTogglePause = {
              val nextPaused = !uiState.isPaused
              webViewRef?.evaluateJavascript("window.GameAPI?.setPaused($nextPaused)", null)
            },
            onResume = {
              webViewRef?.requestFocus()
              webViewRef?.evaluateJavascript("window.GameAPI?.setPaused(false)", null)
            },
            onRetry = {
              webViewRef?.requestFocus()
              webViewRef?.evaluateJavascript("window.GameAPI?.retry()", null)
            },
            onNextBoss = {
              ModelStorageManager.clearRoleModels(this@MainActivity, "boss")
              val idx = BOSS_PRESETS.indexOfFirst { it.id == uiState.bossPresetId }
              val nextPreset = BOSS_PRESETS[(idx + 1) % BOSS_PRESETS.size].id
              gameViewModel.selectBossPreset(this@MainActivity, nextPreset)
              webViewRef?.requestFocus()
              webViewRef?.evaluateJavascript(
                "Promise.resolve(window.GameAPI?.selectBossPreset('$nextPreset')).finally(() => window.GameAPI?.startIntro())",
                null,
              )
            },
            onReturnToMenu = {
              webViewRef?.evaluateJavascript("window.GameAPI?.returnToMenu()", null)
            },
            onToggleMute = {
              val nextMuted = gameViewModel.toggleMute(this@MainActivity)
              webViewRef?.evaluateJavascript("window.GameAPI?.setMuted($nextMuted)", null)
            },
            onMasterVolumeChange = { vol ->
              gameViewModel.setMasterVolume(this@MainActivity, vol)
              webViewRef?.evaluateJavascript("window.GameAPI?.setMasterVolume($vol)", null)
            },
            onMusicVolumeChange = { vol ->
              gameViewModel.setMusicVolume(this@MainActivity, vol)
              webViewRef?.evaluateJavascript("window.GameAPI?.setMusicVolume($vol)", null)
            },
            onSfxVolumeChange = { vol ->
              gameViewModel.setSfxVolume(this@MainActivity, vol)
              webViewRef?.evaluateJavascript("window.GameAPI?.setSfxVolume($vol)", null)
            },
            onQualityChange = { tier ->
              gameViewModel.setQualityTier(this@MainActivity, tier)
              webViewRef?.evaluateJavascript("window.GameAPI?.setQuality('${tier.name}')", null)
            },
            onCameraSensitivityChange = { sens ->
              gameViewModel.setCameraSensitivity(this@MainActivity, sens)
              webViewRef?.evaluateJavascript("window.GameAPI?.setCameraSensitivity($sens)", null)
            },
            onInvertCameraYChange = { inv ->
              gameViewModel.setInvertCameraY(this@MainActivity, inv)
              webViewRef?.evaluateJavascript("window.GameAPI?.setInvertCameraY($inv)", null)
            },
            onControlScaleChange = { scale ->
              gameViewModel.setControlScale(this@MainActivity, scale)
              webViewRef?.evaluateJavascript("window.GameAPI?.setControlScale($scale)", null)
            },
            onResetProgress = {
              listOf("player", "boss", "minion").forEach { role ->
                ModelStorageManager.clearRoleModels(this@MainActivity, role)
              }
              gameViewModel.resetProgress(this@MainActivity)
              webViewRef?.evaluateJavascript(
                "window.GameAPI?.setMuted(false);" +
                  "window.GameAPI?.setMasterVolume(1.0);" +
                  "window.GameAPI?.setMusicVolume(0.7);" +
                  "window.GameAPI?.setSfxVolume(0.85);" +
                  "window.GameAPI?.setQuality('MEDIUM');" +
                  "window.GameAPI?.setCameraSensitivity(1.0);" +
                  "window.GameAPI?.setInvertCameraY(false);" +
                  "window.GameAPI?.setControlScale(1.0);" +
                  "window.GameAPI?.resetModelToDefault('player','vanguard');" +
                  "window.GameAPI?.resetModelToDefault('boss','ashen_behemoth');" +
                  "window.GameAPI?.resetModelToDefault('minion','cinder_imp');",
                null,
              )
            },
            onToggleCodex = { show -> gameViewModel.setShowControlsDialog(show) },
            onToggleSettings = { show -> gameViewModel.setShowSettingsDialog(show) },
            onToggleCredits = { show -> gameViewModel.setShowCreditsDialog(show) },
            onReloadArena = {
              gameViewModel.clearRuntimeError()
              webViewRef?.reload()
            },
            onDismissError = { gameViewModel.clearRuntimeError() },
          )
        }
      }
    }
  }

  override fun onWindowFocusChanged(hasFocus: Boolean) {
    super.onWindowFocusChanged(hasFocus)
    if (hasFocus) configureImmersiveMode()
  }

  private fun configureImmersiveMode() {
    val controller = WindowCompat.getInsetsController(window, window.decorView)
    controller.systemBarsBehavior =
      WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    controller.hide(WindowInsetsCompat.Type.systemBars())
  }
}
