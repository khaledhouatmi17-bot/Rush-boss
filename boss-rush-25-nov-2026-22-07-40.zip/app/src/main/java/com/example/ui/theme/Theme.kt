package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val BossRushDarkColorScheme =
  darkColorScheme(
    primary = EmberGold,
    onPrimary = ObsidianVoid,
    primaryContainer = MoltenCrimson,
    onPrimaryContainer = BoneParchment,
    secondary = EmberGlow,
    onSecondary = ObsidianVoid,
    secondaryContainer = AshenStone,
    onSecondaryContainer = BoneParchment,
    tertiary = EmeraldVitality,
    background = ObsidianVoid,
    onBackground = BoneParchment,
    surface = CathedralSlate,
    onSurface = BoneParchment,
    surfaceVariant = AshenStone,
    onSurfaceVariant = MutedAsh,
    outline = SteelBorder,
    error = MoltenCrimson,
    onError = BoneParchment,
  )

@Composable
fun BossRushTheme(content: @Composable () -> Unit) {
  MaterialTheme(colorScheme = BossRushDarkColorScheme, typography = Typography, content = content)
}
