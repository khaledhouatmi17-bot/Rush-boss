package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianVoid = Color(0xFF0C0B0E)
val CathedralSlate = Color(0xFF17141A)
val AshenStone = Color(0xFF231E26)
val EmberGold = Color(0xFFF2A649)
val MoltenCrimson = Color(0xFFE04826)
val EmberGlow = Color(0xFFFF7A33)
val BoneParchment = Color(0xFFF2E9DC)
val MutedAsh = Color(0xFFA89C94)
val SteelBorder = Color(0xFF473E49)
val EmeraldVitality = Color(0xFF3E9E6B)
