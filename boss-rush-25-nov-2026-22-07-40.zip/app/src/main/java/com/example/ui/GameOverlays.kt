package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.game.GamePhase
import com.example.game.GameUiState
import com.example.game.QualityTier
import com.example.ui.theme.AshenStone
import com.example.ui.theme.BoneParchment
import com.example.ui.theme.CathedralSlate
import com.example.ui.theme.EmberGlow
import com.example.ui.theme.EmberGold
import com.example.ui.theme.EmeraldVitality
import com.example.ui.theme.MoltenCrimson
import com.example.ui.theme.MutedAsh
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.SteelBorder

@Composable
fun GameOverlays(
  uiState: GameUiState,
  onStartBattle: () -> Unit,
  onSelectBossPreset: (String) -> Unit,
  onOpenArmory: () -> Unit,
  onSelectArmoryRole: (String) -> Unit,
  onPreviewPreset: (String, String, String) -> Unit,
  onImportGlbClicked: (String) -> Unit,
  onPlayPreviewClip: (String) -> Unit,
  onApplyPreviewModel: () -> Unit,
  onResetDefaultModel: (String) -> Unit,
  onExitArmory: () -> Unit,
  onSkipIntro: () -> Unit,
  onTogglePause: () -> Unit,
  onResume: () -> Unit,
  onRetry: () -> Unit,
  onNextBoss: () -> Unit,
  onReturnToMenu: () -> Unit,
  onToggleMute: () -> Unit,
  onMasterVolumeChange: (Float) -> Unit,
  onMusicVolumeChange: (Float) -> Unit,
  onSfxVolumeChange: (Float) -> Unit,
  onQualityChange: (QualityTier) -> Unit,
  onCameraSensitivityChange: (Float) -> Unit,
  onInvertCameraYChange: (Boolean) -> Unit,
  onControlScaleChange: (Float) -> Unit,
  onResetProgress: () -> Unit,
  onToggleCodex: (Boolean) -> Unit,
  onToggleSettings: (Boolean) -> Unit,
  onToggleCredits: (Boolean) -> Unit,
  onReloadArena: () -> Unit,
  onDismissError: () -> Unit,
) {
  BackHandler(
    enabled =
      uiState.showControlsDialog ||
        uiState.showSettingsDialog ||
        uiState.showCreditsDialog ||
        uiState.phase == GamePhase.PREVIEW ||
        uiState.phase == GamePhase.INTRO ||
        uiState.phase == GamePhase.COMBAT ||
        uiState.phase == GamePhase.PHASE_2 ||
        uiState.phase == GamePhase.VICTORY ||
        uiState.phase == GamePhase.DEFEAT
  ) {
    when {
      uiState.showControlsDialog -> onToggleCodex(false)
      uiState.showSettingsDialog -> onToggleSettings(false)
      uiState.showCreditsDialog -> onToggleCredits(false)
      uiState.phase == GamePhase.PREVIEW -> onExitArmory()
      uiState.phase == GamePhase.INTRO -> onSkipIntro()
      uiState.phase == GamePhase.COMBAT || uiState.phase == GamePhase.PHASE_2 -> onTogglePause()
      uiState.phase == GamePhase.VICTORY || uiState.phase == GamePhase.DEFEAT -> onReturnToMenu()
    }
  }

  Box(modifier = Modifier.fillMaxSize()) {
    // 1. Main Menu Overlay
    AnimatedVisibility(
      visible = uiState.phase == GamePhase.MENU,
      enter = fadeIn(),
      exit = fadeOut(),
    ) {
      MainMenuOverlay(
        uiState = uiState,
        onStartBattle = onStartBattle,
        onSelectBossPreset = onSelectBossPreset,
        onOpenArmory = onOpenArmory,
        onOpenCodex = { onToggleCodex(true) },
        onOpenSettings = { onToggleSettings(true) },
        onOpenCredits = { onToggleCredits(true) },
        onToggleMute = onToggleMute,
      )
    }

    // 2. 3D Model Armory & Live GLB Preview
    AnimatedVisibility(
      visible = uiState.phase == GamePhase.PREVIEW,
      enter = fadeIn(),
      exit = fadeOut(),
    ) {
      ArmoryPreviewOverlay(
        uiState = uiState,
        onSelectRole = onSelectArmoryRole,
        onPreviewPreset = onPreviewPreset,
        onImportGlbClicked = onImportGlbClicked,
        onPlayClip = onPlayPreviewClip,
        onApplyModel = onApplyPreviewModel,
        onResetDefault = onResetDefaultModel,
        onBack = onExitArmory,
      )
    }

    // 3. Intro Skip Affordance
    AnimatedVisibility(
      visible = uiState.phase == GamePhase.INTRO,
      enter = fadeIn(),
      exit = fadeOut(),
    ) {
      Box(
        modifier =
          Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).padding(16.dp),
      ) {
        OutlinedButton(
          onClick = onSkipIntro,
          border = BorderStroke(1.dp, EmberGold.copy(alpha = 0.65f)),
          colors =
            ButtonDefaults.outlinedButtonColors(
              containerColor = ObsidianVoid.copy(alpha = 0.65f),
              contentColor = BoneParchment,
            ),
          modifier =
            Modifier.align(Alignment.BottomEnd)
              .minimumInteractiveComponentSize()
              .testTag("skip_intro_button"),
        ) {
          Text(text = stringResource(R.string.btn_skip_intro), style = MaterialTheme.typography.labelLarge)
        }
      }
    }

    // 4. Top-Right Utility Controls during Combat
    if (uiState.phase == GamePhase.COMBAT || uiState.phase == GamePhase.PHASE_2) {
      Row(
        modifier =
          Modifier.align(Alignment.TopEnd)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(top = 8.dp, end = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        UtilityCircleButton(
          onClick = onToggleMute,
          contentDescription = stringResource(R.string.cd_sound_toggle),
          tag = "hud_mute_button",
          icon =
            if (uiState.isMuted) Icons.AutoMirrored.Filled.VolumeOff
            else Icons.AutoMirrored.Filled.VolumeUp,
        )
        UtilityCircleButton(
          onClick = onTogglePause,
          contentDescription = stringResource(R.string.cd_pause),
          tag = "pause_button",
          icon = Icons.Filled.Pause,
        )
      }
    }

    // 5. Pause Overlay
    AnimatedVisibility(
      visible = uiState.isPaused && (uiState.phase == GamePhase.COMBAT || uiState.phase == GamePhase.PHASE_2),
      enter = fadeIn() + scaleIn(initialScale = 0.94f),
      exit = fadeOut(),
    ) {
      PauseOverlay(
        onResume = onResume,
        onOpenSettings = { onToggleSettings(true) },
        onRetry = onRetry,
        onReturnToMenu = onReturnToMenu,
      )
    }

    // 6. Victory / Defeat Results Overlay
    AnimatedVisibility(
      visible =
        uiState.resultReady &&
          (uiState.phase == GamePhase.VICTORY || uiState.phase == GamePhase.DEFEAT),
      enter = fadeIn() + scaleIn(initialScale = 0.94f),
      exit = fadeOut(),
    ) {
      ResultsOverlay(
        uiState = uiState,
        isVictory = uiState.phase == GamePhase.VICTORY,
        onRetry = onRetry,
        onNextBoss = onNextBoss,
        onReturnToMenu = onReturnToMenu,
      )
    }

    // 7. Combat Codex Modal
    if (uiState.showControlsDialog) {
      CombatCodexOverlay(onClose = { onToggleCodex(false) })
    }

    // 8. Audio, Camera & Graphics Settings Modal
    if (uiState.showSettingsDialog) {
      SettingsDialog(
        uiState = uiState,
        onToggleMute = onToggleMute,
        onMasterVolumeChange = onMasterVolumeChange,
        onMusicVolumeChange = onMusicVolumeChange,
        onSfxVolumeChange = onSfxVolumeChange,
        onQualityChange = onQualityChange,
        onCameraSensitivityChange = onCameraSensitivityChange,
        onInvertCameraYChange = onInvertCameraYChange,
        onControlScaleChange = onControlScaleChange,
        onResetProgress = onResetProgress,
        onClose = { onToggleSettings(false) },
      )
    }

    // 9. Credits Modal
    if (uiState.showCreditsDialog) {
      CreditsOverlay(onClose = { onToggleCredits(false) })
    }

    // 10. Non-Blocking Runtime / WebGL Recovery Banner
    val err = uiState.runtimeError
    if (!err.isNullOrBlank()) {
      RuntimeErrorBanner(
        message = err,
        onReload = onReloadArena,
        onDismiss = onDismissError,
        modifier =
          Modifier.align(Alignment.TopCenter)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .padding(horizontal = 16.dp, vertical = 10.dp),
      )
    }
  }
}

@Composable
private fun MainMenuOverlay(
  uiState: GameUiState,
  onStartBattle: () -> Unit,
  onSelectBossPreset: (String) -> Unit,
  onOpenArmory: () -> Unit,
  onOpenCodex: () -> Unit,
  onOpenSettings: () -> Unit,
  onOpenCredits: () -> Unit,
  onToggleMute: () -> Unit,
) {
  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(
          Brush.horizontalGradient(
            colors =
              listOf(
                ObsidianVoid.copy(alpha = 0.88f),
                ObsidianVoid.copy(alpha = 0.56f),
                ObsidianVoid.copy(alpha = 0.25f),
              )
          )
        )
        .windowInsetsPadding(WindowInsets.safeDrawing)
        .padding(horizontal = 24.dp, vertical = 16.dp),
  ) {
    Row(
      modifier = Modifier.align(Alignment.TopEnd),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      UtilityCircleButton(
        onClick = onOpenCredits,
        contentDescription = stringResource(R.string.btn_credits),
        tag = "credits_button",
        icon = Icons.Filled.Info,
      )
      UtilityCircleButton(
        onClick = onOpenSettings,
        contentDescription = stringResource(R.string.btn_settings),
        tag = "settings_button",
        icon = Icons.Filled.Settings,
      )
      UtilityCircleButton(
        onClick = onToggleMute,
        contentDescription = stringResource(R.string.cd_sound_toggle),
        tag = "mute_button",
        icon =
          if (uiState.isMuted) Icons.AutoMirrored.Filled.VolumeOff
          else Icons.AutoMirrored.Filled.VolumeUp,
      )
    }

    Column(
      modifier =
        Modifier.align(Alignment.CenterStart)
          .widthIn(max = 580.dp)
          .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.Center,
    ) {
      Text(
        text = stringResource(R.string.game_subtitle),
        style = MaterialTheme.typography.labelLarge,
        color = EmberGold,
        letterSpacing = 3.5.sp,
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = stringResource(R.string.game_title_main),
        style = MaterialTheme.typography.displayLarge,
        color = BoneParchment,
      )
      Spacer(modifier = Modifier.height(6.dp))
      Box(
        modifier =
          Modifier.fillMaxWidth(0.72f)
            .height(2.dp)
            .background(Brush.horizontalGradient(listOf(MoltenCrimson, EmberGold, Color.Transparent)))
      )
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = stringResource(R.string.menu_tagline),
        style = MaterialTheme.typography.bodyLarge,
        color = MutedAsh,
      )

      val activeFighter = uiState.playerCustomName ?: uiState.playerPresetId.replace('_', ' ').uppercase()
      val activeBoss = uiState.bossCustomName ?: uiState.bossPresetId.replace('_', ' ').uppercase()
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "HERO: $activeFighter   •   BOSS: $activeBoss",
        style = MaterialTheme.typography.labelSmall,
        color = EmberGlow,
      )

      if (uiState.totalAttempts > 0) {
        val bestTimeLabel = uiState.bestTimeSeconds?.let { "${it}s" } ?: "--"
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "VICTORIES: ${uiState.totalVictories}/${uiState.totalAttempts}   •   BEST TIME: $bestTimeLabel   •   MAX DMG: ${uiState.bestDamageDealt}",
          style = MaterialTheme.typography.labelSmall,
          color = EmeraldVitality,
          modifier = Modifier.testTag("menu_records_text"),
        )
      }

      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = stringResource(R.string.menu_boss_select),
        style = MaterialTheme.typography.labelSmall,
        color = MutedAsh,
      )
      Spacer(modifier = Modifier.height(4.dp))
      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(BOSS_PRESETS) { bossOpt ->
          val selected = uiState.bossCustomName == null && uiState.bossPresetId == bossOpt.id
          FilterChip(
            selected = selected,
            onClick = { onSelectBossPreset(bossOpt.id) },
            label = { Text(bossOpt.label, style = MaterialTheme.typography.labelSmall, maxLines = 1) },
            colors =
              FilterChipDefaults.filterChipColors(
                selectedContainerColor = MoltenCrimson,
                selectedLabelColor = BoneParchment,
                containerColor = CathedralSlate.copy(alpha = 0.85f),
                labelColor = MutedAsh,
              ),
            modifier = Modifier.minimumInteractiveComponentSize().testTag("boss_select_${bossOpt.id}"),
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Button(
          onClick = onStartBattle,
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MoltenCrimson, contentColor = BoneParchment),
          border = BorderStroke(1.5.dp, EmberGold.copy(alpha = 0.75f)),
          modifier = Modifier.height(50.dp).minimumInteractiveComponentSize().testTag("start_battle_button"),
        ) {
          Icon(imageVector = Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = stringResource(R.string.btn_enter_battle), style = MaterialTheme.typography.labelLarge)
        }

        OutlinedButton(
          onClick = onOpenArmory,
          shape = RoundedCornerShape(8.dp),
          border = BorderStroke(1.dp, EmberGold.copy(alpha = 0.6f)),
          colors =
            ButtonDefaults.outlinedButtonColors(
              containerColor = CathedralSlate.copy(alpha = 0.85f),
              contentColor = BoneParchment,
            ),
          modifier = Modifier.height(50.dp).minimumInteractiveComponentSize().testTag("armory_button"),
        ) {
          Icon(imageVector = Icons.Filled.ViewInAr, contentDescription = null, modifier = Modifier.size(18.dp), tint = EmberGold)
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = stringResource(R.string.btn_armory), style = MaterialTheme.typography.labelLarge)
        }

        OutlinedButton(
          onClick = onOpenCodex,
          shape = RoundedCornerShape(8.dp),
          border = BorderStroke(1.dp, SteelBorder),
          colors =
            ButtonDefaults.outlinedButtonColors(
              containerColor = CathedralSlate.copy(alpha = 0.78f),
              contentColor = BoneParchment,
            ),
          modifier = Modifier.height(50.dp).minimumInteractiveComponentSize().testTag("controls_button"),
        ) {
          Icon(imageVector = Icons.Filled.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp), tint = EmberGold)
          Spacer(modifier = Modifier.width(6.dp))
          Text(text = stringResource(R.string.btn_controls_guide), style = MaterialTheme.typography.labelLarge)
        }
      }
    }
  }
}

@Composable
private fun PauseOverlay(
  onResume: () -> Unit,
  onOpenSettings: () -> Unit,
  onRetry: () -> Unit,
  onReturnToMenu: () -> Unit,
) {
  Box(
    modifier = Modifier.fillMaxSize().background(ObsidianVoid.copy(alpha = 0.78f)),
    contentAlignment = Alignment.Center,
  ) {
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = CathedralSlate),
      border = BorderStroke(1.dp, EmberGold.copy(alpha = 0.45f)),
      modifier = Modifier.widthIn(min = 300.dp, max = 380.dp).padding(16.dp),
    ) {
      Column(
        modifier = Modifier.padding(22.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text(
          text = stringResource(R.string.paused_title),
          style = MaterialTheme.typography.headlineLarge,
          color = EmberGold,
          textAlign = TextAlign.Center,
        )
        HorizontalDivider(color = SteelBorder)
        Button(
          onClick = onResume,
          colors = ButtonDefaults.buttonColors(containerColor = MoltenCrimson, contentColor = BoneParchment),
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("resume_button"),
        ) {
          Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(8.dp))
          Text(stringResource(R.string.btn_resume), style = MaterialTheme.typography.labelLarge)
        }
        OutlinedButton(
          onClick = onOpenSettings,
          border = BorderStroke(1.dp, EmberGold.copy(alpha = 0.45f)),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = BoneParchment),
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("pause_settings_button"),
        ) {
          Icon(Icons.Filled.Settings, contentDescription = null, modifier = Modifier.size(18.dp), tint = EmberGold)
          Spacer(Modifier.width(8.dp))
          Text(stringResource(R.string.btn_settings), style = MaterialTheme.typography.labelLarge)
        }
        OutlinedButton(
          onClick = onRetry,
          border = BorderStroke(1.dp, EmberGold.copy(alpha = 0.5f)),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = BoneParchment),
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("pause_retry_button"),
        ) {
          Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(8.dp))
          Text(stringResource(R.string.btn_retry), style = MaterialTheme.typography.labelLarge)
        }
        OutlinedButton(
          onClick = onReturnToMenu,
          border = BorderStroke(1.dp, SteelBorder),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = MutedAsh),
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("pause_menu_button"),
        ) {
          Text(stringResource(R.string.btn_return_menu), style = MaterialTheme.typography.labelLarge)
        }
      }
    }
  }
}

@Composable
private fun ResultsOverlay(
  uiState: GameUiState,
  isVictory: Boolean,
  onRetry: () -> Unit,
  onNextBoss: () -> Unit,
  onReturnToMenu: () -> Unit,
) {
  val accent = if (isVictory) EmberGold else MoltenCrimson
  val stats = uiState.stats
  val bossDisplayName =
    when {
      !uiState.bossCustomName.isNullOrBlank() -> uiState.bossCustomName.uppercase()
      uiState.bossPresetId == "void_colossus" -> "VOID COLOSSUS"
      uiState.bossPresetId == "skeleton_warlord" -> "SKELETON WARLORD"
      else -> "ASHEN BEHEMOTH"
    }
  val titleText =
    if (isVictory) "$bossDisplayName SLAIN"
    else stringResource(R.string.defeat_title)
  val subtitleText =
    if (isVictory) "$bossDisplayName crumbles to cinders beneath your blade."
    else stringResource(R.string.defeat_subtitle)

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(
          Brush.radialGradient(
            colors = listOf(ObsidianVoid.copy(alpha = 0.72f), ObsidianVoid.copy(alpha = 0.92f))
          )
        )
        .windowInsetsPadding(WindowInsets.safeDrawing),
    contentAlignment = Alignment.Center,
  ) {
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = CathedralSlate.copy(alpha = 0.94f)),
      border = BorderStroke(1.5.dp, accent.copy(alpha = 0.65f)),
      modifier = Modifier.widthIn(min = 340.dp, max = 560.dp).padding(16.dp),
    ) {
      Column(
        modifier = Modifier.padding(horizontal = 24.dp, vertical = 20.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Icon(imageVector = Icons.Filled.Shield, contentDescription = null, tint = accent, modifier = Modifier.size(32.dp))
        Spacer(Modifier.height(6.dp))
        Text(
          text = titleText,
          style = MaterialTheme.typography.headlineLarge,
          color = accent,
          textAlign = TextAlign.Center,
        )
        if (isVictory && uiState.isNewBestTime) {
          Spacer(Modifier.height(4.dp))
          Surface(
            color = EmberGold.copy(alpha = 0.2f),
            shape = RoundedCornerShape(999.dp),
            border = BorderStroke(1.dp, EmberGold),
          ) {
            Text(
              text = stringResource(R.string.new_best_time),
              style = MaterialTheme.typography.labelSmall,
              color = EmberGold,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp).testTag("new_best_badge"),
            )
          }
        }
        Spacer(Modifier.height(4.dp))
        Text(
          text = subtitleText,
          style = MaterialTheme.typography.bodyLarge,
          color = MutedAsh,
          textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(14.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          StatTile(label = stringResource(R.string.stat_time), value = "${stats.timeSeconds}s", modifier = Modifier.weight(1f))
          StatTile(label = stringResource(R.string.stat_damage), value = "${stats.damageDealt}", modifier = Modifier.weight(1f))
          StatTile(label = stringResource(R.string.stat_parries), value = "${stats.parries}", modifier = Modifier.weight(1f))
          StatTile(label = stringResource(R.string.stat_dodges), value = "${stats.dodges}", modifier = Modifier.weight(1f))
        }

        if (uiState.totalAttempts > 0) {
          val bestTimeLabel = uiState.bestTimeSeconds?.let { "${it}s" } ?: "--"
          Spacer(Modifier.height(8.dp))
          Text(
            text = "BEST TIME: $bestTimeLabel  •  MAX DMG: ${uiState.bestDamageDealt}  •  VICTORIES: ${uiState.totalVictories}/${uiState.totalAttempts}",
            style = MaterialTheme.typography.labelSmall,
            color = EmeraldVitality,
          )
        }

        Spacer(Modifier.height(16.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          if (isVictory) {
            Button(
              onClick = onNextBoss,
              colors = ButtonDefaults.buttonColors(containerColor = EmberGold, contentColor = ObsidianVoid),
              modifier = Modifier.weight(1f).height(48.dp).testTag("next_boss_button"),
            ) {
              Text(stringResource(R.string.btn_next_boss), style = MaterialTheme.typography.labelLarge)
              Spacer(Modifier.width(4.dp))
              Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
            }
          }
          Button(
            onClick = onRetry,
            colors = ButtonDefaults.buttonColors(containerColor = MoltenCrimson, contentColor = BoneParchment),
            border = BorderStroke(1.dp, EmberGold.copy(alpha = 0.65f)),
            modifier = Modifier.weight(1f).height(48.dp).testTag("retry_button"),
          ) {
            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(stringResource(R.string.btn_retry), style = MaterialTheme.typography.labelLarge)
          }
          OutlinedButton(
            onClick = onReturnToMenu,
            border = BorderStroke(1.dp, SteelBorder),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = BoneParchment),
            modifier = Modifier.weight(1f).height(48.dp).testTag("return_menu_button"),
          ) {
            Text(stringResource(R.string.btn_return_menu), style = MaterialTheme.typography.labelLarge)
          }
        }
      }
    }
  }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
  Surface(
    color = AshenStone,
    shape = RoundedCornerShape(8.dp),
    border = BorderStroke(1.dp, SteelBorder),
    modifier = modifier,
  ) {
    Column(
      modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(text = label, style = MaterialTheme.typography.labelSmall, color = MutedAsh)
      Spacer(Modifier.height(2.dp))
      Text(text = value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = BoneParchment)
    }
  }
}

@Composable
private fun CombatCodexOverlay(onClose: () -> Unit) {
  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(ObsidianVoid.copy(alpha = 0.82f))
        .windowInsetsPadding(WindowInsets.safeDrawing),
    contentAlignment = Alignment.Center,
  ) {
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = CathedralSlate),
      border = BorderStroke(1.dp, EmberGold.copy(alpha = 0.55f)),
      modifier = Modifier.widthIn(min = 340.dp, max = 560.dp).padding(16.dp),
    ) {
      Column(
        modifier = Modifier.padding(22.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text(text = stringResource(R.string.btn_controls_guide), style = MaterialTheme.typography.titleLarge, color = EmberGold)
        HorizontalDivider(color = SteelBorder)
        Text(text = stringResource(R.string.controls_touch_header), style = MaterialTheme.typography.labelLarge, color = EmberGlow)
        Text(text = stringResource(R.string.controls_touch_body), style = MaterialTheme.typography.bodyLarge, color = BoneParchment)
        Spacer(Modifier.height(4.dp))
        Text(text = stringResource(R.string.controls_key_header), style = MaterialTheme.typography.labelLarge, color = EmberGlow)
        Text(text = stringResource(R.string.controls_key_body), style = MaterialTheme.typography.bodyLarge, color = BoneParchment)
        Spacer(Modifier.height(6.dp))
        Button(
          onClick = onClose,
          colors = ButtonDefaults.buttonColors(containerColor = MoltenCrimson, contentColor = BoneParchment),
          modifier = Modifier.align(Alignment.End).height(48.dp).testTag("close_codex_button"),
        ) {
          Text(stringResource(R.string.btn_close), style = MaterialTheme.typography.labelLarge)
        }
      }
    }
  }
}

@Composable
private fun CreditsOverlay(onClose: () -> Unit) {
  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(ObsidianVoid.copy(alpha = 0.84f))
        .windowInsetsPadding(WindowInsets.safeDrawing),
    contentAlignment = Alignment.Center,
  ) {
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = CathedralSlate),
      border = BorderStroke(1.dp, EmberGold.copy(alpha = 0.55f)),
      modifier = Modifier.widthIn(min = 340.dp, max = 540.dp).padding(16.dp),
    ) {
      Column(
        modifier = Modifier.padding(22.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text(text = stringResource(R.string.credits_title), style = MaterialTheme.typography.titleLarge, color = EmberGold)
        HorizontalDivider(color = SteelBorder)
        Text(text = stringResource(R.string.credits_body), style = MaterialTheme.typography.bodyLarge, color = BoneParchment)
        Spacer(Modifier.height(6.dp))
        Button(
          onClick = onClose,
          colors = ButtonDefaults.buttonColors(containerColor = MoltenCrimson, contentColor = BoneParchment),
          modifier = Modifier.align(Alignment.End).height(48.dp).testTag("close_credits_button"),
        ) {
          Text(stringResource(R.string.btn_close), style = MaterialTheme.typography.labelLarge)
        }
      }
    }
  }
}

@Composable
private fun RuntimeErrorBanner(
  message: String,
  onReload: () -> Unit,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = CathedralSlate.copy(alpha = 0.96f)),
    border = BorderStroke(1.dp, MoltenCrimson),
    modifier = modifier.widthIn(max = 560.dp),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Icon(Icons.Filled.Warning, contentDescription = null, tint = MoltenCrimson, modifier = Modifier.size(22.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(stringResource(R.string.error_banner_title), style = MaterialTheme.typography.labelLarge, color = EmberGold)
        Text(message, style = MaterialTheme.typography.labelSmall, color = BoneParchment)
      }
      Button(
        onClick = onReload,
        colors = ButtonDefaults.buttonColors(containerColor = MoltenCrimson, contentColor = BoneParchment),
        modifier = Modifier.height(48.dp).testTag("reload_arena_button"),
      ) {
        Text(stringResource(R.string.btn_reload_arena), style = MaterialTheme.typography.labelSmall)
      }
      OutlinedButton(
        onClick = onDismiss,
        border = BorderStroke(1.dp, SteelBorder),
        modifier = Modifier.height(48.dp).testTag("dismiss_error_button"),
      ) {
        Text(stringResource(R.string.btn_dismiss), style = MaterialTheme.typography.labelSmall, color = MutedAsh)
      }
    }
  }
}

@Composable
private fun UtilityCircleButton(
  onClick: () -> Unit,
  contentDescription: String,
  tag: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  modifier: Modifier = Modifier,
) {
  IconButton(
    onClick = onClick,
    modifier =
      modifier
        .minimumInteractiveComponentSize()
        .size(48.dp)
        .background(CathedralSlate.copy(alpha = 0.82f), CircleShape)
        .border(1.dp, EmberGold.copy(alpha = 0.45f), CircleShape)
        .testTag(tag),
  ) {
    Icon(imageVector = icon, contentDescription = contentDescription, tint = BoneParchment)
  }
}
