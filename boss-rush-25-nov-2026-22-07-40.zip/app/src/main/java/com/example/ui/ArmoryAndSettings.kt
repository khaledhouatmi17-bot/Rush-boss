package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.game.GameUiState
import com.example.game.QualityTier
import com.example.ui.theme.AshenStone
import com.example.ui.theme.BoneParchment
import com.example.ui.theme.CathedralSlate
import com.example.ui.theme.EmberGlow
import com.example.ui.theme.EmberGold
import com.example.ui.theme.EmeraldVitality
import com.example.ui.theme.MoltenCrimson
import com.example.ui.theme.MutedAsh
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.SteelBorder
import kotlin.math.roundToInt

data class PresetOption(val id: String, val label: String)

val PLAYER_PRESETS =
  listOf(
    PresetOption("vanguard", "Aegis Knight"),
    PresetOption("crimson_paladin", "Barbarian Warlord"),
  )

val BOSS_PRESETS =
  listOf(
    PresetOption("ashen_behemoth", "Ashen Behemoth"),
    PresetOption("void_colossus", "Void Colossus"),
    PresetOption("skeleton_warlord", "Skeleton Warlord"),
  )

val MINION_PRESETS =
  listOf(
    PresetOption("cinder_imp", "Cinder Imp"),
    PresetOption("obsidian_sentinel", "Obsidian Sentinel"),
  )

@Composable
fun ArmoryPreviewOverlay(
  uiState: GameUiState,
  onSelectRole: (String) -> Unit,
  onPreviewPreset: (role: String, presetId: String, label: String) -> Unit,
  onImportGlbClicked: (role: String) -> Unit,
  onPlayClip: (String) -> Unit,
  onApplyModel: () -> Unit,
  onResetDefault: (String) -> Unit,
  onBack: () -> Unit,
) {
  val role = uiState.selectedArmoryRole
  val presets =
    when (role) {
      "boss" -> BOSS_PRESETS
      "minion" -> MINION_PRESETS
      else -> PLAYER_PRESETS
    }

  Box(modifier = Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).padding(12.dp)) {
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = CathedralSlate.copy(alpha = 0.92f)),
      border = BorderStroke(1.dp, EmberGold.copy(alpha = 0.55f)),
      modifier = Modifier.align(Alignment.CenterStart).fillMaxHeight().width(336.dp),
    ) {
      Column(
        modifier = Modifier.fillMaxSize().padding(14.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column {
            Text(
              text = stringResource(R.string.armory_title),
              style = MaterialTheme.typography.titleLarge,
              color = EmberGold,
            )
            Text(
              text = stringResource(R.string.armory_subtitle),
              style = MaterialTheme.typography.labelSmall,
              color = MutedAsh,
            )
          }
          OutlinedButton(
            onClick = onBack,
            border = BorderStroke(1.dp, SteelBorder),
            modifier = Modifier.minimumInteractiveComponentSize().height(48.dp).testTag("armory_back_button"),
          ) {
            Text(stringResource(R.string.armory_back), style = MaterialTheme.typography.labelSmall, color = BoneParchment)
          }
        }

        // Role Tabs
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          val roles =
            listOf(
              "player" to stringResource(R.string.role_player),
              "boss" to stringResource(R.string.role_boss),
              "minion" to stringResource(R.string.role_minion),
            )
          roles.forEach { (rKey, rLabel) ->
            FilterChip(
              selected = role == rKey,
              onClick = { onSelectRole(rKey) },
              label = { Text(rLabel, style = MaterialTheme.typography.labelSmall) },
              colors =
                FilterChipDefaults.filterChipColors(
                  selectedContainerColor = MoltenCrimson,
                  selectedLabelColor = BoneParchment,
                  containerColor = AshenStone,
                  labelColor = MutedAsh,
                ),
              modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("armory_role_$rKey"),
            )
          }
        }

        // Built-in Stylized Cartoon Presets
        Text(
          text = "STYLIZED PRESETS",
          style = MaterialTheme.typography.labelSmall,
          color = EmberGlow,
        )
        LazyRow(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(presets) { opt ->
            val isSelected =
              !uiState.previewMeta.isCustom && uiState.previewMeta.label == opt.label
            FilterChip(
              selected = isSelected,
              onClick = { onPreviewPreset(role, opt.id, opt.label) },
              label = { Text(opt.label, style = MaterialTheme.typography.labelSmall, maxLines = 1) },
              colors =
                FilterChipDefaults.filterChipColors(
                  selectedContainerColor = EmberGold.copy(alpha = 0.28f),
                  selectedLabelColor = EmberGold,
                  containerColor = AshenStone,
                  labelColor = BoneParchment,
                ),
              modifier = Modifier.minimumInteractiveComponentSize().testTag("armory_preset_${opt.id}"),
            )
          }
        }

        // Import GLB from Device Storage
        Button(
          onClick = { onImportGlbClicked(role) },
          colors = ButtonDefaults.buttonColors(containerColor = AshenStone, contentColor = BoneParchment),
          border = BorderStroke(1.dp, EmberGold.copy(alpha = 0.6f)),
          modifier = Modifier.fillMaxWidth().height(48.dp).testTag("import_glb_button"),
        ) {
          Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = EmberGold, modifier = Modifier.size(18.dp))
          Spacer(Modifier.width(8.dp))
          Text(stringResource(R.string.armory_import_glb), style = MaterialTheme.typography.labelLarge)
        }

        // Preview Inspection Card
        val meta = uiState.previewMeta
        Surface(
          color = ObsidianVoid.copy(alpha = 0.72f),
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, if (meta.error.isNotEmpty()) MoltenCrimson else SteelBorder),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
              text = "PREVIEW: ${meta.label}",
              style = MaterialTheme.typography.titleMedium,
              color = BoneParchment,
              fontWeight = FontWeight.Bold,
            )
            if (meta.error.isNotEmpty()) {
              Text(text = meta.error, style = MaterialTheme.typography.labelSmall, color = MoltenCrimson)
            } else {
              val rigDesc =
                if (meta.hasRig) "Rigged • ${meta.animations.size} Animation(s)"
                else "Static Mesh • Procedural Motion Ready"
              Text(
                text = "Meshes: ${meta.meshCount}  •  $rigDesc",
                style = MaterialTheme.typography.labelSmall,
                color = EmeraldVitality,
              )
              if (meta.animations.size > 1) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  items(meta.animations) { clip ->
                    FilterChip(
                      selected = false,
                      onClick = { onPlayClip(clip) },
                      label = { Text(clip, style = MaterialTheme.typography.labelSmall) },
                      modifier = Modifier.minimumInteractiveComponentSize(),
                    )
                  }
                }
              }
            }
          }
        }

        Spacer(Modifier.weight(1f))

        // Confirm Apply & Reset Default
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = onApplyModel,
            enabled = meta.error.isEmpty(),
            colors = ButtonDefaults.buttonColors(containerColor = MoltenCrimson, contentColor = BoneParchment),
            modifier = Modifier.weight(1.2f).height(48.dp).testTag("apply_model_button"),
          ) {
            Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(stringResource(R.string.armory_apply), style = MaterialTheme.typography.labelLarge)
          }

          OutlinedButton(
            onClick = { onResetDefault(role) },
            border = BorderStroke(1.dp, SteelBorder),
            modifier = Modifier.weight(0.9f).height(48.dp).testTag("reset_model_button"),
          ) {
            Icon(Icons.Filled.RestartAlt, contentDescription = null, tint = MutedAsh, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(4.dp))
            Text(stringResource(R.string.armory_reset), style = MaterialTheme.typography.labelSmall, color = MutedAsh)
          }
        }
      }
    }
  }
}

@Composable
fun SettingsDialog(
  uiState: GameUiState,
  onToggleMute: () -> Unit,
  onMasterVolumeChange: (Float) -> Unit,
  onMusicVolumeChange: (Float) -> Unit,
  onSfxVolumeChange: (Float) -> Unit,
  onQualityChange: (QualityTier) -> Unit,
  onCameraSensitivityChange: (Float) -> Unit,
  onInvertCameraYChange: (Boolean) -> Unit,
  onControlScaleChange: (Float) -> Unit,
  onResetProgress: () -> Unit,
  onClose: () -> Unit,
) {
  var confirmReset by remember { mutableStateOf(false) }

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(ObsidianVoid.copy(alpha = 0.84f))
        .windowInsetsPadding(WindowInsets.safeDrawing),
    contentAlignment = Alignment.Center,
  ) {
    Card(
      shape = RoundedCornerShape(14.dp),
      colors = CardDefaults.cardColors(containerColor = CathedralSlate),
      border = BorderStroke(1.dp, EmberGold.copy(alpha = 0.55f)),
      modifier = Modifier.widthIn(min = 340.dp, max = 560.dp).padding(14.dp),
    ) {
      Column(
        modifier = Modifier.padding(20.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Text(
          text = stringResource(R.string.settings_title),
          style = MaterialTheme.typography.titleLarge,
          color = EmberGold,
        )
        HorizontalDivider(color = SteelBorder)

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = stringResource(R.string.settings_mute),
            style = MaterialTheme.typography.bodyLarge,
            color = BoneParchment,
          )
          Switch(
            checked = uiState.isMuted,
            onCheckedChange = { onToggleMute() },
            colors = SwitchDefaults.colors(checkedThumbColor = EmberGold, checkedTrackColor = MoltenCrimson),
            modifier = Modifier.testTag("settings_mute_switch"),
          )
        }

        SettingsSliderRow(
          label = stringResource(R.string.settings_master_vol),
          valueText = "${(uiState.masterVolume * 100).roundToInt()}%",
          value = uiState.masterVolume,
          valueRange = 0f..1f,
          onValueChange = onMasterVolumeChange,
          tag = "master_volume_slider",
        )

        SettingsSliderRow(
          label = stringResource(R.string.settings_music_vol),
          valueText = "${(uiState.musicVolume * 100).roundToInt()}%",
          value = uiState.musicVolume,
          valueRange = 0f..1f,
          onValueChange = onMusicVolumeChange,
          tag = "music_volume_slider",
        )

        SettingsSliderRow(
          label = stringResource(R.string.settings_sfx_vol),
          valueText = "${(uiState.sfxVolume * 100).roundToInt()}%",
          value = uiState.sfxVolume,
          valueRange = 0f..1f,
          onValueChange = onSfxVolumeChange,
          tag = "sfx_volume_slider",
        )

        HorizontalDivider(color = SteelBorder)

        Text(stringResource(R.string.settings_quality), style = MaterialTheme.typography.labelSmall, color = MutedAsh)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          QualityTier.entries.forEach { tier ->
            FilterChip(
              selected = uiState.qualityTier == tier,
              onClick = { onQualityChange(tier) },
              label = { Text(tier.name, style = MaterialTheme.typography.labelSmall) },
              colors =
                FilterChipDefaults.filterChipColors(
                  selectedContainerColor = MoltenCrimson,
                  selectedLabelColor = BoneParchment,
                  containerColor = AshenStone,
                  labelColor = MutedAsh,
                ),
              modifier = Modifier.weight(1f).minimumInteractiveComponentSize().testTag("quality_${tier.name.lowercase()}"),
            )
          }
        }

        SettingsSliderRow(
          label = stringResource(R.string.settings_camera_sens),
          valueText = String.format("%.1fx", uiState.cameraSensitivity),
          value = uiState.cameraSensitivity,
          valueRange = 0.4f..2.2f,
          onValueChange = onCameraSensitivityChange,
          tag = "camera_sensitivity_slider",
        )

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = stringResource(R.string.settings_invert_cam_y),
            style = MaterialTheme.typography.bodyLarge,
            color = BoneParchment,
          )
          Switch(
            checked = uiState.invertCameraY,
            onCheckedChange = onInvertCameraYChange,
            colors = SwitchDefaults.colors(checkedThumbColor = EmberGold, checkedTrackColor = MoltenCrimson),
            modifier = Modifier.testTag("invert_camera_y_switch"),
          )
        }

        SettingsSliderRow(
          label = stringResource(R.string.settings_control_scale),
          valueText = "${(uiState.controlScale * 100).roundToInt()}%",
          value = uiState.controlScale,
          valueRange = 0.75f..1.3f,
          onValueChange = onControlScaleChange,
          tag = "control_scale_slider",
        )

        HorizontalDivider(color = SteelBorder)

        if (!confirmReset) {
          OutlinedButton(
            onClick = { confirmReset = true },
            border = BorderStroke(1.dp, MoltenCrimson.copy(alpha = 0.7f)),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MoltenCrimson),
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("reset_progress_button"),
          ) {
            Icon(Icons.Filled.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(stringResource(R.string.settings_reset_progress), style = MaterialTheme.typography.labelLarge)
          }
        } else {
          Surface(
            color = ObsidianVoid.copy(alpha = 0.8f),
            shape = RoundedCornerShape(10.dp),
            border = BorderStroke(1.dp, MoltenCrimson),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text(
                text = stringResource(R.string.settings_reset_confirm_title),
                style = MaterialTheme.typography.titleMedium,
                color = MoltenCrimson,
              )
              Text(
                text = stringResource(R.string.settings_reset_confirm_body),
                style = MaterialTheme.typography.labelSmall,
                color = BoneParchment,
              )
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                  onClick = {
                    confirmReset = false
                    onResetProgress()
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = MoltenCrimson, contentColor = BoneParchment),
                  modifier = Modifier.weight(1f).height(48.dp).testTag("confirm_reset_button"),
                ) {
                  Text(stringResource(R.string.btn_confirm_reset), style = MaterialTheme.typography.labelLarge)
                }
                OutlinedButton(
                  onClick = { confirmReset = false },
                  border = BorderStroke(1.dp, SteelBorder),
                  modifier = Modifier.weight(1f).height(48.dp).testTag("cancel_reset_button"),
                ) {
                  Text(stringResource(R.string.btn_cancel), style = MaterialTheme.typography.labelLarge, color = BoneParchment)
                }
              }
            }
          }
        }

        Spacer(Modifier.height(4.dp))
        Button(
          onClick = onClose,
          colors = ButtonDefaults.buttonColors(containerColor = MoltenCrimson, contentColor = BoneParchment),
          modifier = Modifier.align(Alignment.End).height(48.dp).testTag("close_settings_button"),
        ) {
          Text(stringResource(R.string.btn_close), style = MaterialTheme.typography.labelLarge)
        }
      }
    }
  }
}

@Composable
private fun SettingsSliderRow(
  label: String,
  valueText: String,
  value: Float,
  valueRange: ClosedFloatingPointRange<Float>,
  onValueChange: (Float) -> Unit,
  tag: String,
) {
  Column {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text(label, style = MaterialTheme.typography.labelSmall, color = MutedAsh)
      Text(valueText, style = MaterialTheme.typography.labelSmall, color = EmberGold)
    }
    Slider(
      value = value,
      onValueChange = onValueChange,
      valueRange = valueRange,
      colors = SliderDefaults.colors(thumbColor = EmberGold, activeTrackColor = MoltenCrimson),
      modifier = Modifier.testTag(tag),
    )
  }
}
