package com.example.game

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream

object ModelStorageManager {
  private const val MODELS_DIR = "models"

  data class ImportResult(
    val success: Boolean,
    val displayName: String,
    val previewUrl: String = "",
    val error: String = "",
  )

  fun getModelsDir(context: Context): File {
    return File(context.filesDir, MODELS_DIR).apply { if (!exists()) mkdirs() }
  }

  fun getModelFile(context: Context, filename: String): File {
    return File(getModelsDir(context), filename)
  }

  fun importPendingModel(context: Context, role: String, uri: Uri): ImportResult {
    val displayName = resolveDisplayName(context, uri)
    val isGltfJson = displayName.endsWith(".gltf", ignoreCase = true)
    val ext = if (isGltfJson) "gltf" else "glb"
    val pendingFile = getModelFile(context, "pending_${role}.$ext")
    // Clear alternate extension pending file if present
    val altExt = if (isGltfJson) "glb" else "gltf"
    getModelFile(context, "pending_${role}.$altExt").delete()

    return try {
      context.contentResolver.openInputStream(uri)?.use { input ->
        val header = ByteArray(4)
        val readHeader = input.read(header)
        if (readHeader < 4) {
          return ImportResult(false, displayName, error = "Selected file is empty or unreadable.")
        }
        val isValidGlb =
          header[0] == 'g'.code.toByte() &&
            header[1] == 'l'.code.toByte() &&
            header[2] == 'T'.code.toByte() &&
            header[3] == 'F'.code.toByte()
        val firstChar = header[0].toInt().toChar()
        val isValidJson = isGltfJson && (firstChar == '{' || firstChar == ' ' || firstChar == '\n' || firstChar == '\r')

        if (!isValidGlb && !isValidJson) {
          return ImportResult(
            false,
            displayName,
            error = "Invalid 3D file. Please choose a valid binary .glb or self-contained .gltf file.",
          )
        }

        FileOutputStream(pendingFile).use { out ->
          out.write(header, 0, readHeader)
          input.copyTo(out)
        }
      } ?: return ImportResult(false, displayName, error = "Unable to open selected file.")

      val url = "https://bossrush.local/user-models/${pendingFile.name}?t=${System.currentTimeMillis()}"
      ImportResult(true, displayName, previewUrl = url)
    } catch (e: Exception) {
      ImportResult(false, displayName, error = e.message ?: "Import failed.")
    }
  }

  fun promotePendingToActive(context: Context, role: String): String? {
    val pendingGlb = getModelFile(context, "pending_${role}.glb")
    val pendingGltf = getModelFile(context, "pending_${role}.gltf")
    val source =
      when {
        pendingGlb.exists() -> pendingGlb
        pendingGltf.exists() -> pendingGltf
        else -> return null
      }
    val ext = source.extension
    // Remove previous active files
    getModelFile(context, "active_${role}.glb").delete()
    getModelFile(context, "active_${role}.gltf").delete()
    val dest = getModelFile(context, "active_${role}.$ext")
    source.copyTo(dest, overwrite = true)
    source.delete()
    return "https://bossrush.local/user-models/${dest.name}?t=${System.currentTimeMillis()}"
  }

  fun getActiveCustomModelUrl(context: Context, role: String): String? {
    val glb = getModelFile(context, "active_${role}.glb")
    if (glb.exists()) return "https://bossrush.local/user-models/${glb.name}"
    val gltf = getModelFile(context, "active_${role}.gltf")
    if (gltf.exists()) return "https://bossrush.local/user-models/${gltf.name}"
    return null
  }

  fun clearRoleModels(context: Context, role: String) {
    getModelFile(context, "active_${role}.glb").delete()
    getModelFile(context, "active_${role}.gltf").delete()
    getModelFile(context, "pending_${role}.glb").delete()
    getModelFile(context, "pending_${role}.gltf").delete()
  }

  private fun resolveDisplayName(context: Context, uri: Uri): String {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
      if (cursor.moveToFirst()) {
        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (idx >= 0) return cursor.getString(idx) ?: "CustomModel.glb"
      }
    }
    return uri.lastPathSegment?.substringAfterLast('/') ?: "CustomModel.glb"
  }
}
