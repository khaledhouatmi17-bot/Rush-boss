package com.example.game

import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONObject
import kotlin.math.max

enum class GamePhase {
  MENU,
  PREVIEW,
  INTRO,
  COMBAT,
  PHASE_2,
  VICTORY,
  DEFEAT,
}

enum class QualityTier {
  LOW,
  MEDIUM,
  HIGH,
}

data class BattleStats(
  val timeSeconds: Int = 0,
  val damageDealt: Int = 0,
  val parries: Int = 0,
  val dodges: Int = 0,
)

data class ModelPreviewMeta(
  val role: String = "player",
  val label: String = "Aegis Knight",
  val isCustom: Boolean = false,
  val error: String = "",
  val meshCount: Int = 0,
  val hasRig: Boolean = true,
  val animations: List<String> = emptyList(),
)

data class GameUiState(
  val phase: GamePhase = GamePhase.MENU,
  val isPaused: Boolean = false,
  val isMuted: Boolean = false,
  val masterVolume: Float = 1.0f,
  val musicVolume: Float = 0.70f,
  val sfxVolume: Float = 0.85f,
  val qualityTier: QualityTier = QualityTier.MEDIUM,
  val cameraSensitivity: Float = 1.0f,
  val invertCameraY: Boolean = false,
  val controlScale: Float = 1.0f,
  val showControlsDialog: Boolean = false,
  val showSettingsDialog: Boolean = false,
  val showCreditsDialog: Boolean = false,
  val selectedArmoryRole: String = "player",
  val playerPresetId: String = "vanguard",
  val bossPresetId: String = "ashen_behemoth",
  val minionPresetId: String = "cinder_imp",
  val playerCustomName: String? = null,
  val bossCustomName: String? = null,
  val minionCustomName: String? = null,
  val previewMeta: ModelPreviewMeta = ModelPreviewMeta(),
  val resultReady: Boolean = false,
  val stats: BattleStats = BattleStats(),
  val totalVictories: Int = 0,
  val totalAttempts: Int = 0,
  val bestTimeSeconds: Int? = null,
  val bestDamageDealt: Int = 0,
  val bestParries: Int = 0,
  val isNewBestTime: Boolean = false,
  val runtimeError: String? = null,
)

class GameViewModel : ViewModel() {
  private val _uiState = MutableStateFlow(GameUiState())
  val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

  private var recordedCurrentResult: Boolean = false

  fun loadPersistedPrefs(context: Context) {
    val prefs = runCatching { context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }.getOrNull() ?: return
    val quality =
      runCatching { QualityTier.valueOf(safeString(prefs, "quality", "MEDIUM") ?: "MEDIUM") }
        .getOrDefault(QualityTier.MEDIUM)

    val masterVol = safeFloat(prefs, "master_vol", 1.0f, 0f, 1f)
    val musicVol = safeFloat(prefs, "music_vol", 0.70f, 0f, 1f)
    val sfxVol = safeFloat(prefs, "sfx_vol", 0.85f, 0f, 1f)
    val camSens = safeFloat(prefs, "camera_sens", 1.0f, 0.4f, 2.2f)
    val ctrlScale = safeFloat(prefs, "control_scale", 1.0f, 0.75f, 1.3f)
    val invertY = safeBoolean(prefs, "invert_cam_y", false)
    val muted = safeBoolean(prefs, "muted", false)

    val recordsJson = safeString(prefs, KEY_BEST_RECORDS, null)
    val parsedRecords = parseRecordsSafely(recordsJson)

    _uiState.update {
      it.copy(
        isMuted = muted,
        masterVolume = masterVol,
        musicVolume = musicVol,
        sfxVolume = sfxVol,
        qualityTier = quality,
        cameraSensitivity = camSens,
        invertCameraY = invertY,
        controlScale = ctrlScale,
        playerPresetId = safeString(prefs, "player_preset", "vanguard") ?: "vanguard",
        bossPresetId = safeString(prefs, "boss_preset", "ashen_behemoth") ?: "ashen_behemoth",
        minionPresetId = safeString(prefs, "minion_preset", "cinder_imp") ?: "cinder_imp",
        playerCustomName = safeString(prefs, "player_custom_name", null),
        bossCustomName = safeString(prefs, "boss_custom_name", null),
        minionCustomName = safeString(prefs, "minion_custom_name", null),
        totalVictories = parsedRecords.totalVictories,
        totalAttempts = parsedRecords.totalAttempts,
        bestTimeSeconds = parsedRecords.bestTimeSeconds,
        bestDamageDealt = parsedRecords.bestDamageDealt,
        bestParries = parsedRecords.bestParries,
      )
    }
  }

  private fun savePref(context: Context?, block: (SharedPreferences.Editor) -> Unit) {
    val prefs = runCatching { context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }.getOrNull() ?: return
    prefs.edit().apply(block).apply()
  }

  fun onBridgeStateJson(rawJson: String) {
    try {
      val obj = JSONObject(rawJson)
      val parsedPhase =
        when (obj.optString("phase", "MENU")) {
          "PREVIEW" -> GamePhase.PREVIEW
          "INTRO" -> GamePhase.INTRO
          "COMBAT" -> GamePhase.COMBAT
          "PHASE_2" -> GamePhase.PHASE_2
          "VICTORY" -> GamePhase.VICTORY
          "DEFEAT" -> GamePhase.DEFEAT
          else -> GamePhase.MENU
        }
      val ready = obj.optBoolean("resultReady", false)
      if (!ready || (parsedPhase != GamePhase.VICTORY && parsedPhase != GamePhase.DEFEAT)) {
        recordedCurrentResult = false
      }
      _uiState.update { prev ->
        prev.copy(
          phase = parsedPhase,
          isPaused = obj.optBoolean("paused", false),
          resultReady = ready,
          isNewBestTime = if (ready && parsedPhase == GamePhase.VICTORY) prev.isNewBestTime else false,
          stats =
            BattleStats(
              timeSeconds = obj.optInt("timeSeconds", 0).coerceAtLeast(0),
              damageDealt = obj.optInt("damageDealt", 0).coerceAtLeast(0),
              parries = obj.optInt("parries", 0).coerceAtLeast(0),
              dodges = obj.optInt("dodges", 0).coerceAtLeast(0),
            ),
        )
      }
    } catch (_: Exception) {
    }
  }

  fun recordBattleOutcomeIfNeeded(context: Context) {
    val st = _uiState.value
    if (!st.resultReady) return
    if (st.phase != GamePhase.VICTORY && st.phase != GamePhase.DEFEAT) return
    if (recordedCurrentResult) return

    recordedCurrentResult = true
    val isVictory = st.phase == GamePhase.VICTORY
    val nextAttempts = st.totalAttempts + 1
    val nextVictories = if (isVictory) st.totalVictories + 1 else st.totalVictories
    val fightTime = st.stats.timeSeconds.coerceAtLeast(1)
    val prevBest = st.bestTimeSeconds
    val newBestTimeFlag = isVictory && (prevBest == null || fightTime < prevBest)
    val nextBestTime =
      when {
        !isVictory -> prevBest
        prevBest == null -> fightTime
        else -> minOf(prevBest, fightTime)
      }
    val nextBestDamage = max(st.bestDamageDealt, st.stats.damageDealt)
    val nextBestParries = max(st.bestParries, st.stats.parries)

    _uiState.update {
      it.copy(
        totalAttempts = nextAttempts,
        totalVictories = nextVictories,
        bestTimeSeconds = nextBestTime,
        bestDamageDealt = nextBestDamage,
        bestParries = nextBestParries,
        isNewBestTime = newBestTimeFlag,
      )
    }

    val payload =
      JSONObject()
        .put("totalVictories", nextVictories)
        .put("totalAttempts", nextAttempts)
        .put("bestTimeSeconds", nextBestTime ?: -1)
        .put("bestDamageDealt", nextBestDamage)
        .put("bestParries", nextBestParries)
        .toString()

    savePref(context) { it.putString(KEY_BEST_RECORDS, payload) }
  }

  fun onPreviewMetaJson(rawJson: String) {
    try {
      val obj = JSONObject(rawJson)
      val animArr = obj.optJSONArray("animations")
      val anims = mutableListOf<String>()
      if (animArr != null) {
        for (i in 0 until animArr.length()) {
          anims.add(animArr.optString(i))
        }
      }
      _uiState.update {
        it.copy(
          previewMeta =
            ModelPreviewMeta(
              role = obj.optString("role", it.selectedArmoryRole),
              label = obj.optString("label", "Model"),
              isCustom = obj.optBoolean("isCustom", false),
              error = obj.optString("error", ""),
              meshCount = obj.optInt("meshCount", 0),
              hasRig = obj.optBoolean("hasRig", false),
              animations = anims,
            )
        )
      }
    } catch (_: Exception) {
    }
  }

  fun onGameErrorJson(rawJson: String) {
    try {
      val obj = JSONObject(rawJson)
      val msg = obj.optString("message", "").trim()
      _uiState.update { it.copy(runtimeError = msg.ifEmpty { null }) }
    } catch (_: Exception) {
    }
  }

  fun setRuntimeError(message: String?) {
    _uiState.update { it.copy(runtimeError = message?.trim()?.ifEmpty { null }) }
  }

  fun clearRuntimeError() {
    _uiState.update { it.copy(runtimeError = null) }
  }

  fun setPreviewError(role: String, label: String, error: String) {
    _uiState.update {
      it.copy(
        previewMeta = ModelPreviewMeta(role = role, label = label, isCustom = true, error = error)
      )
    }
  }

  fun toggleMute(context: Context? = null): Boolean {
    val next = !_uiState.value.isMuted
    _uiState.update { it.copy(isMuted = next) }
    savePref(context) { it.putBoolean("muted", next) }
    return next
  }

  fun setMasterVolume(context: Context? = null, vol: Float) {
    val clamped = if (vol.isFinite()) vol.coerceIn(0f, 1f) else 1.0f
    _uiState.update { it.copy(masterVolume = clamped) }
    savePref(context) { it.putFloat("master_vol", clamped) }
  }

  fun setMusicVolume(context: Context, vol: Float) {
    val clamped = if (vol.isFinite()) vol.coerceIn(0f, 1f) else 0.70f
    _uiState.update { it.copy(musicVolume = clamped) }
    savePref(context) { it.putFloat("music_vol", clamped) }
  }

  fun setSfxVolume(context: Context, vol: Float) {
    val clamped = if (vol.isFinite()) vol.coerceIn(0f, 1f) else 0.85f
    _uiState.update { it.copy(sfxVolume = clamped) }
    savePref(context) { it.putFloat("sfx_vol", clamped) }
  }

  fun setQualityTier(context: Context, tier: QualityTier) {
    _uiState.update { it.copy(qualityTier = tier) }
    savePref(context) { it.putString("quality", tier.name) }
  }

  fun setCameraSensitivity(context: Context? = null, sensitivity: Float) {
    val clamped = if (sensitivity.isFinite()) sensitivity.coerceIn(0.4f, 2.2f) else 1.0f
    _uiState.update { it.copy(cameraSensitivity = clamped) }
    savePref(context) { it.putFloat("camera_sens", clamped) }
  }

  fun setInvertCameraY(context: Context? = null, invert: Boolean) {
    _uiState.update { it.copy(invertCameraY = invert) }
    savePref(context) { it.putBoolean("invert_cam_y", invert) }
  }

  fun setControlScale(context: Context? = null, scale: Float) {
    val clamped = if (scale.isFinite()) scale.coerceIn(0.75f, 1.3f) else 1.0f
    _uiState.update { it.copy(controlScale = clamped) }
    savePref(context) { it.putFloat("control_scale", clamped) }
  }

  fun selectBossPreset(context: Context? = null, presetId: String) {
    _uiState.update { it.copy(bossPresetId = presetId, bossCustomName = null) }
    savePref(context) { ed ->
      ed.putString("boss_preset", presetId)
      ed.remove("boss_custom_name")
    }
  }

  fun setShowControlsDialog(show: Boolean) {
    _uiState.update { it.copy(showControlsDialog = show) }
  }

  fun setShowSettingsDialog(show: Boolean) {
    _uiState.update { it.copy(showSettingsDialog = show) }
  }

  fun setShowCreditsDialog(show: Boolean) {
    _uiState.update { it.copy(showCreditsDialog = show) }
  }

  fun setSelectedArmoryRole(role: String) {
    _uiState.update { it.copy(selectedArmoryRole = role) }
  }

  fun markModelApplied(context: Context, role: String, customName: String?, presetId: String?) {
    _uiState.update { st ->
      when (role) {
        "player" ->
          st.copy(
            playerCustomName = customName,
            playerPresetId = presetId ?: st.playerPresetId,
          )
        "boss" ->
          st.copy(
            bossCustomName = customName,
            bossPresetId = presetId ?: st.bossPresetId,
          )
        else ->
          st.copy(
            minionCustomName = customName,
            minionPresetId = presetId ?: st.minionPresetId,
          )
      }
    }
    savePref(context) { ed ->
      when (role) {
        "player" -> {
          ed.putString("player_custom_name", customName)
          if (presetId != null) ed.putString("player_preset", presetId)
        }
        "boss" -> {
          ed.putString("boss_custom_name", customName)
          if (presetId != null) ed.putString("boss_preset", presetId)
        }
        else -> {
          ed.putString("minion_custom_name", customName)
          if (presetId != null) ed.putString("minion_preset", presetId)
        }
      }
    }
  }

  fun resetProgress(context: Context? = null) {
    recordedCurrentResult = false
    runCatching {
      context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)?.edit()?.clear()?.apply()
    }
    _uiState.update { current ->
      GameUiState(
        phase = current.phase,
        isPaused = current.isPaused,
        showSettingsDialog = current.showSettingsDialog,
      )
    }
  }

  private data class ParsedRecords(
    val totalVictories: Int = 0,
    val totalAttempts: Int = 0,
    val bestTimeSeconds: Int? = null,
    val bestDamageDealt: Int = 0,
    val bestParries: Int = 0,
  )

  private fun parseRecordsSafely(raw: String?): ParsedRecords {
    if (raw.isNullOrBlank()) return ParsedRecords()
    return try {
      val obj = JSONObject(raw)
      val bestT = obj.optInt("bestTimeSeconds", -1)
      ParsedRecords(
        totalVictories = obj.optInt("totalVictories", 0).coerceAtLeast(0),
        totalAttempts = obj.optInt("totalAttempts", 0).coerceAtLeast(0),
        bestTimeSeconds = if (bestT > 0) bestT else null,
        bestDamageDealt = obj.optInt("bestDamageDealt", 0).coerceAtLeast(0),
        bestParries = obj.optInt("bestParries", 0).coerceAtLeast(0),
      )
    } catch (_: Exception) {
      ParsedRecords()
    }
  }

  private fun safeFloat(
    prefs: SharedPreferences,
    key: String,
    defaultVal: Float,
    minVal: Float,
    maxVal: Float,
  ): Float {
    return try {
      val v = prefs.getFloat(key, defaultVal)
      if (v.isFinite()) v.coerceIn(minVal, maxVal) else defaultVal
    } catch (_: Exception) {
      defaultVal
    }
  }

  private fun safeBoolean(prefs: SharedPreferences, key: String, defaultVal: Boolean): Boolean {
    return try {
      prefs.getBoolean(key, defaultVal)
    } catch (_: Exception) {
      defaultVal
    }
  }

  private fun safeString(prefs: SharedPreferences, key: String, defaultVal: String?): String? {
    return try {
      prefs.getString(key, defaultVal)
    } catch (_: Exception) {
      defaultVal
    }
  }

  companion object {
    private const val PREFS_NAME = "boss_rush_prefs"
    private const val KEY_BEST_RECORDS = "best_records_json"
  }
}
