package com.example.game

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.io.FileInputStream
import java.io.IOException

private const val GAME_HOST = "bossrush.local"
private const val GAME_ENTRY_URL = "https://$GAME_HOST/game/index.html"

class AndroidGameBridge(
  private val onStateJson: (String) -> Unit,
  private val onPreviewMetaJson: (String) -> Unit,
  private val onGameErrorJson: (String) -> Unit = {},
) {
  private val mainHandler = Handler(Looper.getMainLooper())

  @JavascriptInterface
  fun onStateChange(json: String) {
    mainHandler.post { onStateJson(json) }
  }

  @JavascriptInterface
  fun onPreviewMeta(json: String) {
    mainHandler.post { onPreviewMetaJson(json) }
  }

  @JavascriptInterface
  fun onGameError(json: String) {
    mainHandler.post { onGameErrorJson(json) }
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GameWebView(
  modifier: Modifier = Modifier,
  onWebViewReady: (WebView) -> Unit,
  onPageReady: (WebView) -> Unit,
  onStateJson: (String) -> Unit,
  onPreviewMetaJson: (String) -> Unit,
  onGameErrorJson: (String) -> Unit = {},
  onRuntimeError: (String) -> Unit = {},
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current

  val webView =
    remember(context) {
      createConfiguredWebView(
          context = context,
          onPageReady = onPageReady,
          onStateJson = onStateJson,
          onPreviewMetaJson = onPreviewMetaJson,
          onGameErrorJson = onGameErrorJson,
          onRuntimeError = onRuntimeError,
        )
        .also { onWebViewReady(it) }
    }

  DisposableEffect(lifecycleOwner, webView) {
    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_RESUME -> webView.onResume()
        Lifecycle.Event.ON_PAUSE -> webView.onPause()
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      lifecycleOwner.lifecycle.removeObserver(observer)
      webView.removeJavascriptInterface("AndroidBridge")
      webView.stopLoading()
      webView.destroy()
    }
  }

  AndroidView(
    factory = { webView },
    modifier = modifier,
    update = { view ->
      if (!view.hasFocus()) {
        view.requestFocus()
      }
    },
  )
}

@SuppressLint("SetJavaScriptEnabled")
private fun createConfiguredWebView(
  context: Context,
  onPageReady: (WebView) -> Unit,
  onStateJson: (String) -> Unit,
  onPreviewMetaJson: (String) -> Unit,
  onGameErrorJson: (String) -> Unit,
  onRuntimeError: (String) -> Unit,
): WebView {
  return WebView(context).apply {
    layoutParams =
      ViewGroup.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT,
      )
    setBackgroundColor(Color.parseColor("#0C0B0E"))
    setLayerType(View.LAYER_TYPE_HARDWARE, null)
    isFocusable = true
    isFocusableInTouchMode = true
    isHapticFeedbackEnabled = false
    overScrollMode = View.OVER_SCROLL_NEVER
    isVerticalScrollBarEnabled = false
    isHorizontalScrollBarEnabled = false
    isLongClickable = false
    setOnLongClickListener { true }

    settings.apply {
      javaScriptEnabled = true
      domStorageEnabled = true
      mediaPlaybackRequiresUserGesture = false
      cacheMode = WebSettings.LOAD_DEFAULT
      allowFileAccess = false
      allowContentAccess = false
      useWideViewPort = true
      loadWithOverviewMode = true
      setSupportZoom(false)
      builtInZoomControls = false
      displayZoomControls = false
    }

    addJavascriptInterface(
      AndroidGameBridge(onStateJson, onPreviewMetaJson, onGameErrorJson),
      "AndroidBridge",
    )
    webChromeClient = WebChromeClient()
    webViewClient =
      object : WebViewClient() {
        override fun onPageFinished(view: WebView?, url: String?) {
          super.onPageFinished(view, url)
          if (view != null) onPageReady(view)
        }

        override fun onReceivedError(
          view: WebView?,
          request: WebResourceRequest?,
          error: WebResourceError?,
        ) {
          super.onReceivedError(view, request, error)
          if (request?.isForMainFrame == true) {
            onRuntimeError(error?.description?.toString() ?: "Failed to load arena scene.")
          }
        }

        override fun onRenderProcessGone(
          view: WebView?,
          detail: RenderProcessGoneDetail?,
        ): Boolean {
          onRuntimeError("3D graphics renderer stopped unexpectedly. Tap Reload Arena to recover.")
          return true
        }

        override fun shouldInterceptRequest(
          view: WebView?,
          request: WebResourceRequest?,
        ): WebResourceResponse? {
          val url = request?.url ?: return null
          if (url.host != GAME_HOST) return null
          val rawPath = url.path?.trimStart('/') ?: return null

          // Serve imported user GLB/GLTF models from internal app storage
          if (rawPath.startsWith("user-models/")) {
            val fileName = rawPath.removePrefix("user-models/")
            if (fileName.contains("..") || fileName.contains("/")) return null
            val modelFile = ModelStorageManager.getModelFile(context, fileName)
            if (!modelFile.exists()) return null
            val mime =
              if (fileName.endsWith(".gltf", ignoreCase = true)) "model/gltf+json"
              else "model/gltf-binary"
            return try {
              WebResourceResponse(mime, null, FileInputStream(modelFile))
            } catch (_: IOException) {
              null
            }
          }

          return try {
            val stream = context.assets.open(rawPath)
            val mimeType =
              when {
                rawPath.endsWith(".html") -> "text/html"
                rawPath.endsWith(".js") || rawPath.endsWith(".mjs") -> "application/javascript"
                rawPath.endsWith(".css") -> "text/css"
                rawPath.endsWith(".json") -> "application/json"
                rawPath.endsWith(".svg") -> "image/svg+xml"
                rawPath.endsWith(".glb") -> "model/gltf-binary"
                rawPath.endsWith(".gltf") -> "model/gltf+json"
                else -> "application/octet-stream"
              }
            WebResourceResponse(mimeType, "UTF-8", stream)
          } catch (_: IOException) {
            null
          }
        }
      }

    loadUrl(GAME_ENTRY_URL)
  }
}
