package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.game.GamePhase
import com.example.game.GameViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `app name matches Boss Rush`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Boss Rush", appName)
  }

  @Test
  fun `game view model parses bridge state transitions`() {
    val vm = GameViewModel()
    assertEquals(GamePhase.MENU, vm.uiState.value.phase)

    vm.onBridgeStateJson("""{"phase":"INTRO","paused":false,"resultReady":false}""")
    assertEquals(GamePhase.INTRO, vm.uiState.value.phase)

    vm.onBridgeStateJson("""{"phase":"PHASE_2","paused":false,"resultReady":false,"damageDealt":1420}""")
    assertEquals(GamePhase.PHASE_2, vm.uiState.value.phase)
    assertEquals(1420, vm.uiState.value.stats.damageDealt)

    vm.onBridgeStateJson("""{"phase":"VICTORY","paused":false,"resultReady":true,"timeSeconds":64,"damageDealt":2600,"parries":3,"dodges":8}""")
    assertEquals(GamePhase.VICTORY, vm.uiState.value.phase)
    assertTrue(vm.uiState.value.resultReady)
    assertEquals(3, vm.uiState.value.stats.parries)
    assertEquals(8, vm.uiState.value.stats.dodges)
  }
}
