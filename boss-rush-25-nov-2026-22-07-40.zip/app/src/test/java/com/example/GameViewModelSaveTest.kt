package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.game.GamePhase
import com.example.game.GameViewModel
import com.example.game.QualityTier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GameViewModelSaveTest {

  private lateinit var context: Context

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    context.getSharedPreferences("boss_rush_prefs", Context.MODE_PRIVATE).edit().clear().commit()
  }

  @Test
  fun `persisted settings and custom boss selection round-trip across instances`() {
    val vm = GameViewModel()
    vm.toggleMute(context)
    vm.setMasterVolume(context, 0.55f)
    vm.setMusicVolume(context, 0.42f)
    vm.setSfxVolume(context, 0.91f)
    vm.setQualityTier(context, QualityTier.HIGH)
    vm.setCameraSensitivity(context, 1.65f)
    vm.setInvertCameraY(context, true)
    vm.setControlScale(context, 1.15f)
    vm.selectBossPreset(context, "void_colossus")

    val reloaded = GameViewModel()
    reloaded.loadPersistedPrefs(context)
    val state = reloaded.uiState.value

    assertTrue(state.isMuted)
    assertEquals(0.55f, state.masterVolume, 0.001f)
    assertEquals(0.42f, state.musicVolume, 0.001f)
    assertEquals(0.91f, state.sfxVolume, 0.001f)
    assertEquals(QualityTier.HIGH, state.qualityTier)
    assertEquals(1.65f, state.cameraSensitivity, 0.001f)
    assertTrue(state.invertCameraY)
    assertEquals(1.15f, state.controlScale, 0.001f)
    assertEquals("void_colossus", state.bossPresetId)
    assertNull(state.bossCustomName)
  }

  @Test
  fun `corrupted preferences and malformed records JSON recover safely to defaults`() {
    context
      .getSharedPreferences("boss_rush_prefs", Context.MODE_PRIVATE)
      .edit()
      .putString("master_vol", "corrupt_string")
      .putInt("muted", 42)
      .putString("quality", "NON_EXISTENT")
      .putString("best_records_json", "{not_valid_json")
      .commit()

    val vm = GameViewModel()
    vm.loadPersistedPrefs(context)
    val state = vm.uiState.value

    assertFalse(state.isMuted)
    assertEquals(1.0f, state.masterVolume, 0.001f)
    assertEquals(QualityTier.MEDIUM, state.qualityTier)
    assertEquals(0, state.totalVictories)
    assertEquals(0, state.totalAttempts)
    assertNull(state.bestTimeSeconds)
  }

  @Test
  fun `recordBattleOutcomeIfNeeded tracks best time without double counting and resetProgress wipes data`() {
    val vm = GameViewModel()

    vm.onBridgeStateJson("""{"phase":"VICTORY","paused":false,"resultReady":true,"timeSeconds":62,"damageDealt":2650,"parries":4,"dodges":7}""")
    vm.recordBattleOutcomeIfNeeded(context)
    // Calling twice for the same resultReady state must not increment twice
    vm.recordBattleOutcomeIfNeeded(context)

    assertEquals(1, vm.uiState.value.totalVictories)
    assertEquals(1, vm.uiState.value.totalAttempts)
    assertEquals(62, vm.uiState.value.bestTimeSeconds)
    assertEquals(2650, vm.uiState.value.bestDamageDealt)
    assertEquals(4, vm.uiState.value.bestParries)
    assertTrue(vm.uiState.value.isNewBestTime)

    // Slower victory should not overwrite bestTimeSeconds or set isNewBestTime
    vm.onBridgeStateJson("""{"phase":"COMBAT","paused":false,"resultReady":false}""")
    vm.onBridgeStateJson("""{"phase":"VICTORY","paused":false,"resultReady":true,"timeSeconds":85,"damageDealt":2700,"parries":2,"dodges":5}""")
    vm.recordBattleOutcomeIfNeeded(context)

    assertEquals(2, vm.uiState.value.totalVictories)
    assertEquals(2, vm.uiState.value.totalAttempts)
    assertEquals(62, vm.uiState.value.bestTimeSeconds)
    assertEquals(2700, vm.uiState.value.bestDamageDealt)
    assertFalse(vm.uiState.value.isNewBestTime)

    // Verify reload from disk preserves records
    val reloaded = GameViewModel()
    reloaded.loadPersistedPrefs(context)
    assertEquals(2, reloaded.uiState.value.totalVictories)
    assertEquals(62, reloaded.uiState.value.bestTimeSeconds)

    // Reset wipes all persisted prefs & records
    reloaded.resetProgress(context)
    assertEquals(0, reloaded.uiState.value.totalVictories)
    assertEquals(0, reloaded.uiState.value.totalAttempts)
    assertNull(reloaded.uiState.value.bestTimeSeconds)
    assertEquals(1.0f, reloaded.uiState.value.masterVolume, 0.001f)
    assertEquals(GamePhase.MENU, reloaded.uiState.value.phase)
  }

  @Test
  fun `runtime error bridge updates and clears recovery banner state`() {
    val vm = GameViewModel()
    vm.onGameErrorJson("""{"code":"WEBGL_CONTEXT_LOST","message":"Graphics context paused.","recoverable":true}""")
    assertEquals("Graphics context paused.", vm.uiState.value.runtimeError)

    vm.clearRuntimeError()
    assertNull(vm.uiState.value.runtimeError)
  }
}
