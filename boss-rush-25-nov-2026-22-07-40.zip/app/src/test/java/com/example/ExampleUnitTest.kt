package com.example

import com.example.game.GamePhase
import com.example.game.GameViewModel
import com.example.game.QualityTier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun initialStateAndSettingsTogglesAreValid() {
    val vm = GameViewModel()
    assertEquals(GamePhase.MENU, vm.uiState.value.phase)
    assertFalse(vm.uiState.value.isMuted)
    assertEquals(QualityTier.MEDIUM, vm.uiState.value.qualityTier)

    assertTrue(vm.toggleMute())
    assertTrue(vm.uiState.value.isMuted)

    vm.setShowControlsDialog(true)
    assertTrue(vm.uiState.value.showControlsDialog)
    vm.setShowControlsDialog(false)
    assertFalse(vm.uiState.value.showControlsDialog)

    vm.setShowSettingsDialog(true)
    assertTrue(vm.uiState.value.showSettingsDialog)
    vm.setShowSettingsDialog(false)
    assertFalse(vm.uiState.value.showSettingsDialog)

    vm.setSelectedArmoryRole("boss")
    assertEquals("boss", vm.uiState.value.selectedArmoryRole)

    vm.setPreviewError("boss", "Bad.txt", "Invalid 3D file")
    assertEquals("Invalid 3D file", vm.uiState.value.previewMeta.error)
    assertEquals("Bad.txt", vm.uiState.value.previewMeta.label)
  }
}
