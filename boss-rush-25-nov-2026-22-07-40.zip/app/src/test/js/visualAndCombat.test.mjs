import test from 'node:test';
import assert from 'node:assert/strict';
import module from 'node:module';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const assetsRoot = path.resolve(process.cwd(), 'app/src/main/assets');
module.registerHooks({
  resolve(specifier, context, nextResolve) {
    if (specifier === 'three') {
      return {
        url: pathToFileURL(path.join(assetsRoot, 'vendor/three.module.min.js')).href,
        shortCircuit: true,
      };
    }
    if (specifier.startsWith('/vendor/')) {
      return {
        url: pathToFileURL(path.join(assetsRoot, specifier.slice(1))).href,
        shortCircuit: true,
      };
    }
    return nextResolve(specifier, context);
  },
});

if (!globalThis.document) {
  globalThis.document = {
    createElement: () => ({
      className: '',
      style: {},
      classList: { add() {}, remove() {}, toggle() {} },
      addEventListener() {},
      remove() {},
    }),
    getElementById: () => null,
  };
}

const THREE = await import('three');
const { VFXManager } = await import('../../main/assets/game/vfx.js');
const { CombatCamera } = await import('../../main/assets/game/camera.js');
const { SoundEngine } = await import('../../main/assets/game/audio.js');
const { PlayerCharacter, PlayerState } = await import('../../main/assets/game/player.js');
const { AshenKnightBoss, BossState } = await import('../../main/assets/game/boss.js');

test('VFXManager pooled flashes, craters, directional sparks, whirlwind skill, and Phase 2 pulse update and clear cleanly', () => {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(55, 1.77, 0.1, 140);
  const vfx = new VFXManager(scene, camera);

  const origin = new THREE.Vector3(1, 0, 2);
  vfx.spawnHitFlash(origin, 0xffe082, 2.4);
  vfx.spawnGroundCrater(origin, 2.5, 0xff6a22);
  vfx.spawnDirectionalSparks(origin, 0.5, 12, 0xffe075, 9.0, 14);
  vfx.spawnSkillWhirlwind(origin, 0.5, 0xff7b29);
  vfx.spawnPhase2ArenaPulse(origin);

  assert.ok(vfx.hitFlashes.some((h) => h.active));
  assert.ok(vfx.craters.some((c) => c.active));
  assert.ok(vfx.slashArcs.some((a) => a.active));
  assert.ok(vfx.magicBursts.some((b) => b.active));
  assert.ok(vfx.shockwaves.some((s) => s.active));

  for (let i = 0; i < 65; i++) {
    vfx.update(0.016);
  }
  assert.ok(vfx.hitFlashes.every((h) => !h.active));
  assert.ok(vfx.craters.every((c) => !c.active));

  vfx.spawnHitFlash(origin);
  vfx.spawnGroundCrater(origin);
  vfx.clearAll();
  assert.ok(vfx.hitFlashes.every((h) => !h.active));
  assert.ok(vfx.craters.every((c) => !c.active));
});

test('CombatCamera shake stays bounded and decays smoothly without NaN or clipping', () => {
  const camera = new THREE.PerspectiveCamera(55, 1.77, 0.1, 140);
  const camCtrl = new CombatCamera(camera);
  const arena = { resolveObstacleCollision() {}, radius: 22 };
  const playerPos = new THREE.Vector3(0, 0, 8);
  const bossPos = new THREE.Vector3(0, 0, -6);

  camCtrl.addShake(5.0);
  assert.ok(camCtrl.shakeTrauma <= 1.0);

  for (let i = 0; i < 90; i++) {
    camCtrl.update(0.016, i * 0.016, 'COMBAT', 0, playerPos, bossPos, arena, 1.9);
    assert.ok(Number.isFinite(camera.position.x));
    assert.ok(Number.isFinite(camera.position.y));
    assert.ok(Number.isFinite(camera.position.z));
    assert.ok(camera.position.y >= 1.15);
  }
  assert.equal(camCtrl.shakeTrauma, 0);
});

test('SoundEngine exposes cooldown guard, combo swing variations, death SFX, and external asset registration cleanly', async () => {
  const audio = new SoundEngine();
  assert.equal(audio._canPlay('test_sfx', 100), true);
  assert.equal(audio._canPlay('test_sfx', 100), false);

  audio.playComboSwing(0, false);
  audio.playComboSwing(1, false);
  audio.playComboSwing(2, true);
  audio.playEnemyDeath(true);
  const registered = await audio.registerAudioAsset('impact_heavy', 'assets/sfx/heavy_hit.ogg');
  assert.equal(registered, true);
  assert.equal(audio.customAudioUrls.get('impact_heavy'), 'assets/sfx/heavy_hit.ogg');
  audio.dispose();
});

test('Player & Boss procedural rigs run full animation cycle and Phase 2 pulse without breaking combat invariants', () => {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(55, 1.77, 0.1, 140);
  const vfx = new VFXManager(scene, camera);
  const audio = new SoundEngine();
  const arena = { resolveObstacleCollision() {} };

  const player = new PlayerCharacter(scene);
  assert.ok(player.contactAura);

  // Trigger light attack -> hits target once per swing
  assert.equal(player.triggerLightAttack(new THREE.Vector3(0, 0, 0)), true);
  assert.equal(player.state, PlayerState.ATTACK);
  player.markTargetHit('boss');
  assert.equal(player.hasHitTarget('boss'), true);

  for (let i = 0; i < 40; i++) {
    player.update(0.016, i * 0.016, new THREE.Vector3(0, 0, -1), new THREE.Vector3(0, 0, 0), arena, true);
  }

  const boss = new AshenKnightBoss(scene);
  assert.ok(boss.contactAura);
  boss.startCombat();
  const res = boss.takeDamage(boss.maxHp * 0.6, 10, true);
  assert.equal(res.triggeredPhase2, true);
  assert.equal(boss.state, BossState.ENRAGED);

  // Run past 0.9s ENRAGED transform trigger
  for (let i = 0; i < 65; i++) {
    boss.update(0.016, i * 0.016, player.root.position, arena, vfx, audio, {
      onHeavyImpact() {},
      onBossMeleeHit() {},
    });
  }
  assert.equal(boss.phase, 2);
});
