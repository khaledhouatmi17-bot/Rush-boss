import test from 'node:test';
import assert from 'node:assert/strict';
import module from 'node:module';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const assetsRoot = path.resolve(process.cwd(), 'app/src/main/assets');
module.registerHooks({
  resolve(specifier, context, nextResolve) {
    if (specifier === 'three') {
      return {
        url: pathToFileURL(path.join(assetsRoot, 'vendor/three.module.min.js')).href,
        shortCircuit: true,
      };
    }
    if (specifier.startsWith('/vendor/')) {
      return {
        url: pathToFileURL(path.join(assetsRoot, specifier.slice(1))).href,
        shortCircuit: true,
      };
    }
    return nextResolve(specifier, context);
  },
});

if (!globalThis.document) {
  globalThis.document = {
    createElement: () => ({
      className: '',
      style: {},
      classList: { add() {}, remove() {}, toggle() {} },
      addEventListener() {},
      remove() {},
    }),
    getElementById: () => null,
  };
}

const THREE = await import('three');
const { GLBAnimationController } = await import('../../main/assets/game/modelManager.js');
const { PlayerCharacter, PlayerState } = await import('../../main/assets/game/player.js');
const { AshenKnightBoss, BossState } = await import('../../main/assets/game/boss.js');
const { MinionEnemy } = await import('../../main/assets/game/enemies.js');

function makeClip(name, duration = 1.0) {
  const track = new THREE.QuaternionKeyframeTrack(
    '.quaternion',
    [0, duration],
    [0, 0, 0, 1, 0, 0, 0, 1]
  );
  return new THREE.AnimationClip(name, duration, [track]);
}

test('GLBAnimationController preserves non-zero initial Y offset when clips like HIT or STUNNED are missing', () => {
  const modelRoot = new THREE.Group();
  const initialY = 1.15;
  modelRoot.position.set(0, initialY, 0);

  // Model only has Idle and Walk clips; HIT, STUNNED, ATTACK, DEATH are absent.
  const ctrl = new GLBAnimationController(modelRoot, [makeClip('Idle'), makeClip('Walking_A')]);
  assert.equal(ctrl.basePositionY, initialY);

  // Move through IDLE -> WALK -> ATTACK -> HIT -> STUNNED -> DEATH -> IDLE
  const states = [
    { key: 'IDLE', moving: false, frames: 10 },
    { key: 'WALK', moving: true, frames: 10 },
    { key: 'ATTACK', moving: false, frames: 15 },
    { key: 'HIT', moving: false, frames: 20 },
    { key: 'STUNNED', moving: false, frames: 20 },
    { key: 'DEATH', moving: false, frames: 20 },
  ];

  let elapsed = 0;
  const dt = 1 / 60;
  let prevY = modelRoot.position.y;

  for (const s of states) {
    ctrl.playState(s.key, s.key === 'HIT' || s.key === 'DEATH');
    for (let i = 0; i < s.frames; i++) {
      elapsed += dt;
      ctrl.update(dt, s.key, elapsed, s.moving);
      const curY = modelRoot.position.y;
      assert.ok(
        curY >= initialY - 1e-4,
        `Expected Y (${curY}) to stay >= initialY (${initialY}) during ${s.key}`
      );
      assert.ok(
        Math.abs(curY - prevY) < 0.05,
        `Unexpected sudden Y jump from ${prevY} to ${curY} during ${s.key}`
      );
      prevY = curY;
    }
  }

  // Settling into HIT or STUNNED keeps Y at initialY (never drops toward 0)
  ctrl.playState('STUNNED');
  for (let i = 0; i < 40; i++) {
    elapsed += dt;
    ctrl.update(dt, 'STUNNED', elapsed, false);
  }
  assert.ok(Math.abs(modelRoot.position.y - initialY) < 0.002);

  ctrl.dispose();
});

test('GLBAnimationController smooths transition from procedural MOVE bounce into clip-backed IDLE/ATTACK without sudden drop or stuck tilt', () => {
  const modelRoot = new THREE.Group();
  const initialY = 0.85;
  modelRoot.position.set(0, initialY, 0);

  // Has IDLE & ATTACK, missing MOVE
  const ctrl = new GLBAnimationController(modelRoot, [makeClip('Idle'), makeClip('Attack')]);

  let elapsed = 0;
  const dt = 1 / 60;
  let prevY = modelRoot.position.y;

  // Move procedurally (no MOVE clip)
  for (let i = 0; i < 20; i++) {
    elapsed += dt;
    ctrl.update(dt, 'MOVE', elapsed, true);
    assert.ok(modelRoot.position.y >= initialY - 1e-4);
    assert.ok(Math.abs(modelRoot.position.y - prevY) < 0.05);
    prevY = modelRoot.position.y;
  }

  // Transition into clip-backed ATTACK
  ctrl.playState('ATTACK', true);
  for (let i = 0; i < 45; i++) {
    elapsed += dt;
    ctrl.update(dt, 'ATTACK', elapsed, false);
    assert.ok(modelRoot.position.y >= initialY - 1e-4);
    assert.ok(Math.abs(modelRoot.position.y - prevY) < 0.05);
    prevY = modelRoot.position.y;
  }

  assert.ok(Math.abs(modelRoot.position.y - initialY) < 0.002);
  assert.ok(Math.abs(modelRoot.rotation.z) < 0.002);
  ctrl.dispose();
});

test('Player, Boss, and Minion preserve non-zero visualGroup Y offset during HIT, STUNNED, and DEFEATED states', () => {
  const scene = new THREE.Scene();
  const noopArena = { resolveObstacleCollision() {} };
  const noopVfx = {
    spawnDust() {}, spawnShieldWard() {}, spawnSparks() {}, spawnSmoke() {},
    spawnFloatingText() {}, showCircleTelegraph() {}, showDashTelegraph() {},
    hideTelegraphs() {}, spawnShockwave() {}, spawnMagicBurst() {}, spawnEruptionPillar() {},
  };
  const noopAudio = {
    playShieldClash() {}, playFootstep() {}, playSwordSwing() {},
    playShockwave() {}, playFireBurst() {}, playPhase2Transform() {},
  };

  // Player with non-zero initial Y offset and only Idle clip
  const player = new PlayerCharacter(scene);
  const playerVisual = new THREE.Group();
  playerVisual.position.y = 0.92;
  player.applyCustomGLB(playerVisual, [makeClip('Idle')]);
  player.takeDamage(50, new THREE.Vector3(0, 0, 5), noopArena);
  assert.equal(player.state, PlayerState.HIT);
  for (let i = 0; i < 15; i++) {
    player.update(0.016, i * 0.016, new THREE.Vector3(), null, noopArena, true);
  }
  assert.ok(Math.abs(player.visualGroup.position.y - 0.92) < 1e-4);

  // Boss with non-zero initial Y offset and Idle/Death clips (missing STUNNED)
  const boss = new AshenKnightBoss(scene);
  const bossVisual = new THREE.Group();
  bossVisual.position.y = 1.45;
  boss.applyCustomGLB(bossVisual, [makeClip('Idle'), makeClip('Death')]);
  boss.startCombat();
  boss.staggerFromParry();
  assert.equal(boss.state, BossState.STUNNED);
  for (let i = 0; i < 20; i++) {
    boss.update(0.016, i * 0.016, player.root.position, noopArena, noopVfx, noopAudio, {
      onHeavyImpact() {},
      onBossMeleeHit() {},
    });
  }
  assert.ok(Math.abs(boss.visualGroup.position.y - 1.45) < 1e-4);

  // Boss DEFEATED uses DEATH clip cleanly without double-tilting root.rotation.x
  boss.takeDamage(boss.hp + 100, 0, false);
  assert.equal(boss.state, BossState.DEFEATED);
  for (let i = 0; i < 15; i++) {
    boss.animatePose(0.016, i * 0.016, 1.0);
  }
  assert.equal(boss.visualGroup.rotation.x, 0);
  assert.ok(Math.abs(boss.visualGroup.position.y - 1.45) < 1e-4);

  // Minion with non-zero initial Y offset and only Idle clip
  const minion = new MinionEnemy(scene, 'cinder_imp', new THREE.Vector3(4, 0, 0));
  const minionVisual = new THREE.Group();
  minionVisual.position.y = 0.78;
  minion.applyCustomGLB(minionVisual, [makeClip('Idle')]);
  minion.takeDamage(20, player.root.position, false, noopVfx, noopAudio, noopArena);
  assert.equal(minion.state, 'HIT');
  for (let i = 0; i < 15; i++) {
    minion.update(0.016, i * 0.016, player.root.position, noopArena, () => {});
  }
  assert.ok(Math.abs(minion.visualGroup.position.y - 0.78) < 1e-4);
});
