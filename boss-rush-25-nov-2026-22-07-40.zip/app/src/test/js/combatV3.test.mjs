import test from 'node:test';
import assert from 'node:assert/strict';
import module from 'node:module';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const assetsRoot = path.resolve(process.cwd(), 'app/src/main/assets');
module.registerHooks({
  resolve(specifier, context, nextResolve) {
    if (specifier === 'three') {
      return {
        url: pathToFileURL(path.join(assetsRoot, 'vendor/three.module.min.js')).href,
        shortCircuit: true,
      };
    }
    if (specifier.startsWith('/vendor/')) {
      return {
        url: pathToFileURL(path.join(assetsRoot, specifier.slice(1))).href,
        shortCircuit: true,
      };
    }
    return nextResolve(specifier, context);
  },
});

function createMockElement(id = '') {
  const listeners = new Map();
  const classes = new Set();
  return {
    id,
    tagName: 'DIV',
    width: 128,
    height: 128,
    className: '',
    style: {},
    classList: {
      add: (...cls) => cls.forEach((c) => classes.add(c)),
      remove: (...cls) => cls.forEach((c) => classes.delete(c)),
      toggle: (c, force) => {
        if (force === undefined) {
          if (classes.has(c)) classes.delete(c);
          else classes.add(c);
        } else if (force) classes.add(c);
        else classes.delete(c);
      },
      contains: (c) => classes.has(c),
    },
    addEventListener(type, fn) {
      if (!listeners.has(type)) listeners.set(type, []);
      listeners.get(type).push(fn);
    },
    removeEventListener(type, fn) {
      const list = listeners.get(type);
      if (!list) return;
      const idx = list.indexOf(fn);
      if (idx >= 0) list.splice(idx, 1);
    },
    dispatchEvent(evt) {
      const list = listeners.get(evt.type) || [];
      for (const fn of [...list]) fn(evt);
    },
    getBoundingClientRect() {
      return { left: 20, top: 200, width: 124, height: 124 };
    },
    setPointerCapture() {},
    remove() {},
    getContext() {
      return {
        fillStyle: '#000',
        strokeStyle: '#000',
        lineWidth: 1,
        fillRect() {},
        clearRect() {},
        beginPath() {},
        moveTo() {},
        lineTo() {},
        arc() {},
        ellipse() {},
        fill() {},
        stroke() {},
        save() {},
        restore() {},
        translate() {},
        rotate() {},
        createRadialGradient: () => ({ addColorStop() {} }),
        createLinearGradient: () => ({ addColorStop() {} }),
      };
    },
  };
}

const domRegistry = new Map([
  ['joystick-zone', createMockElement('joystick-zone')],
  ['joystick-base', createMockElement('joystick-base')],
  ['joystick-knob', createMockElement('joystick-knob')],
  ['btn-attack', createMockElement('btn-attack')],
  ['btn-heavy', createMockElement('btn-heavy')],
  ['btn-dodge', createMockElement('btn-dodge')],
  ['btn-parry', createMockElement('btn-parry')],
  ['btn-skill', createMockElement('btn-skill')],
  ['btn-lock', createMockElement('btn-lock')],
]);

const windowMock = createMockElement('window');
globalThis.window = Object.assign(windowMock, { innerWidth: 1280, innerHeight: 720 });
globalThis.document = {
  createElement: (tag) => createMockElement(tag),
  getElementById: (id) => domRegistry.get(id) || null,
};

const THREE = await import('three');
const {
  PlayerCharacter,
  PlayerState,
  PERFECT_PARRY_WINDOW,
  PARRY_BLOCK_DURATION,
  PERFECT_DODGE_WINDOW,
} = await import('../../main/assets/game/player.js');
const { AshenKnightBoss, BossState } = await import('../../main/assets/game/boss.js');
const { VFXManager } = await import('../../main/assets/game/vfx.js');
const { SoundEngine } = await import('../../main/assets/game/audio.js');
const { InputController } = await import('../../main/assets/game/controls.js');

const noopArena = { resolveObstacleCollision() {} };

test('V3 Combo System: 3-hit light chain hits once per swing, triggers combo finisher, heavy finisher, and resets on timeout', () => {
  const scene = new THREE.Scene();
  const player = new PlayerCharacter(scene);
  const target = new THREE.Vector3(0, 0, 5);
  const zeroMove = new THREE.Vector3(0, 0, 0);

  // 1st light swing
  assert.equal(player.triggerLightAttack(target), true);
  assert.equal(player.state, PlayerState.ATTACK);
  assert.equal(player.comboStep, 0);

  // Advance into hit window and confirm single-hit tracking
  player.update(0.14, 0.14, zeroMove, target, noopArena, true, {});
  const atk1 = player.getActiveAttackInfo();
  assert.ok(atk1);
  assert.equal(atk1.isComboFinisher, false);
  player.markTargetHit('boss');
  assert.equal(player.hasHitTarget('boss'), true);

  // Queue 2nd combo step and advance past step 0 duration (0.46s)
  player.triggerLightAttack(target);
  assert.equal(player.queuedAction, 'ATTACK');
  player.update(0.36, 0.50, zeroMove, target, noopArena, true, {});
  assert.equal(player.state, PlayerState.ATTACK);
  assert.equal(player.comboStep, 1);
  assert.equal(player.hasHitTarget('boss'), false); // fresh swing clears hitTargets

  // Queue 3rd combo step (Combo Finisher)
  player.update(0.16, 0.66, zeroMove, target, noopArena, true, {});
  player.triggerLightAttack(target);
  player.update(0.36, 1.02, zeroMove, target, noopArena, true, {});
  assert.equal(player.comboStep, 2);

  player.update(0.18, 1.20, zeroMove, target, noopArena, true, {});
  const atk3 = player.getActiveAttackInfo();
  assert.ok(atk3);
  assert.equal(atk3.isComboFinisher, true);
  assert.equal(atk3.heavy, true);
  assert.ok(atk3.damage > atk1.damage);

  // Queue Heavy Finisher right out of light combo
  player.triggerHeavyAttack(target);
  assert.equal(player.queuedAction, 'HEAVY');
  player.update(0.46, 1.66, zeroMove, target, noopArena, true, {});
  assert.equal(player.state, PlayerState.HEAVY);
  assert.equal(player.isHeavyFinisher, true);

  player.update(0.34, 2.0, zeroMove, target, noopArena, true, {});
  const heavyFinisherInfo = player.getActiveAttackInfo();
  assert.ok(heavyFinisherInfo);
  assert.equal(heavyFinisherInfo.isHeavyFinisher, true);
  assert.ok(heavyFinisherInfo.damage > 210);

  // Wait past recovery & combo reset timeout -> next light attack starts fresh at step 0
  for (let i = 0; i < 80; i++) {
    player.update(0.02, 2.0 + i * 0.02, zeroMove, target, noopArena, true, {});
  }
  assert.equal(player.comboResetTimer, 0);
  assert.equal(player.triggerLightAttack(target), true);
  assert.equal(player.comboStep, 0);
  player.dispose();
});

test('V3 Defense: Perfect Parry staggers boss cleanly without infinite stun loop, while late Parry transitions to Block mitigation', () => {
  const scene = new THREE.Scene();
  const player = new PlayerCharacter(scene);
  const boss = new AshenKnightBoss(scene);
  const noopVfx = { spawnShieldWard() {} };
  const zeroMove = new THREE.Vector3();

  // Trigger parry -> within PERFECT_PARRY_WINDOW (<= 0.18s)
  assert.equal(player.triggerParry(boss.root.position, noopVfx), true);
  player.update(0.08, 0.08, zeroMove, boss.root.position, noopArena, true, {});
  assert.equal(player.isPerfectParrying(), true);
  assert.equal(player.isBlocking(), false);

  const stamBeforeParry = player.stamina;
  player.onParrySuccess();
  assert.ok(player.stamina > stamBeforeParry);
  assert.equal(boss.staggerFromParry(), true);
  assert.equal(boss.state, BossState.STUNNED);
  assert.equal(boss.criticalAvailable, true);
  // Cannot infinitely re-stagger an already stunned boss
  assert.equal(boss.staggerFromParry(), false);

  // Advance past PERFECT_PARRY_WINDOW into normal Block window
  player.update(PERFECT_PARRY_WINDOW + 0.02, 0.30, zeroMove, boss.root.position, noopArena, true, {});
  assert.equal(player.isPerfectParrying(), false);
  assert.equal(player.isBlocking(), true);

  // Blocked hit deals reduced chip damage without putting player into HIT stun
  player.onBlockSuccess(boss.root.position, noopArena);
  player.takeBlockedDamage(36);
  assert.equal(player.hp, 964);
  assert.equal(player.state, PlayerState.PARRY);

  // Stance ends after PARRY_BLOCK_DURATION
  player.update(PARRY_BLOCK_DURATION, 0.8, zeroMove, boss.root.position, noopArena, true, {});
  assert.equal(player.state, PlayerState.IDLE);

  player.dispose();
  boss.dispose();
});

test('V3 Dodge & Critical Attack: Perfect Dodge grants finite i-frames + counter buff, and Critical Strike requires stunned boss once per stagger', () => {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(55, 1.77, 0.1, 140);
  const vfx = new VFXManager(scene, camera);
  const player = new PlayerCharacter(scene);
  const boss = new AshenKnightBoss(scene);
  const zeroMove = new THREE.Vector3();

  player.root.position.set(0, 0, -4.5); // within 4.9m of boss at z = -7.5

  // Cannot critical strike non-stunned boss
  assert.equal(boss.canReceiveCriticalStrike(player.root.position, 4.9), false);

  // Perfect Dodge window -> grants counter buff + energy trail
  assert.equal(player.triggerDodge(new THREE.Vector3(1, 0, 0), vfx), true);
  player.update(0.06, 0.06, zeroMove, boss.root.position, noopArena, true, {});
  assert.equal(player.isInvulnerable(), true);
  assert.equal(player.isPerfectDodgeWindow(), true);

  player.onPerfectDodge();
  assert.ok(player.counterBuffTimer > 1.5);
  assert.ok(player.perfectDodgeTrailTimer > 0.2);

  // Late dodge (> 0.18s) still invulnerable briefly, then expires at 0.34s
  player.update(PERFECT_DODGE_WINDOW + 0.02, 0.26, zeroMove, boss.root.position, noopArena, true, {});
  assert.equal(player.isPerfectDodgeWindow(), false);
  assert.equal(player.isInvulnerable(), true);

  player.update(0.12, 0.38, zeroMove, boss.root.position, noopArena, true, {});
  assert.equal(player.isInvulnerable(), false);

  // Consuming counter buff clears timer cleanly
  assert.equal(player.consumeCounterBuff(), true);
  assert.equal(player.consumeCounterBuff(), false);

  // Finish dodge to IDLE and step back into critical range
  player.update(0.1, 0.48, zeroMove, boss.root.position, noopArena, true, {});
  assert.equal(player.state, PlayerState.IDLE);
  player.root.position.set(0, 0, -4.5);

  // Stagger boss -> Critical Opportunity becomes available once per stagger window
  assert.equal(boss.staggerFromParry(), true);
  assert.equal(boss.canReceiveCriticalStrike(player.root.position, 4.9), true);

  assert.equal(player.triggerHeavyAttack(boss.root.position, { isCritical: true }), true);
  player.update(0.24, 0.72, zeroMove, boss.root.position, noopArena, true, {});
  const critAtk = player.getActiveAttackInfo();
  assert.ok(critAtk);
  assert.equal(critAtk.isCriticalStrike, true);

  assert.equal(boss.consumeCriticalStrike(), true);
  assert.equal(boss.canReceiveCriticalStrike(player.root.position, 4.9), false); // strictly 1 per stagger
  const hpBefore = boss.hp;
  const dmgRes = boss.takeDamage(critAtk.damage, critAtk.poise, false, true);
  assert.ok(dmgRes.damage > critAtk.damage); // 1.4x stunned multiplier applies
  assert.ok(boss.hp > 0 && boss.hp < hpBefore); // impactful without auto-winning
  assert.ok(boss.hitRecoilTimer > 0);

  // Boss recovers cleanly from STUNNED after 2.6s
  const mockVfx = {
    spawnSparks() {},
    spawnSmoke() {},
    spawnGroundCrater() {},
    spawnHitFlash() {},
    showCircleTelegraph() {},
    showDashTelegraph() {},
    hideTelegraphs() {},
  };
  const mockAudio = { playShockwave() {}, playFootstep() {}, playSwordSwing() {} };
  for (let i = 0; i < 140; i++) {
    boss.update(0.02, i * 0.02, player.root.position, noopArena, mockVfx, mockAudio, {
      onHeavyImpact() {},
      onBossMeleeHit() {},
    });
  }
  assert.notEqual(boss.state, BossState.STUNNED);

  vfx.dispose();
  player.dispose();
  boss.dispose();
});

test('V3 VFX, SoundEngine Categories, and Android Touch Controls (InputController) work reliably', () => {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(55, 1.77, 0.1, 140);
  const vfx = new VFXManager(scene, camera);

  vfx.spawnPerfectParryBurst(new THREE.Vector3(0, 0, 0), 0.2);
  vfx.spawnBlockBurst(new THREE.Vector3(1, 0, 0), 0.2);
  vfx.spawnPerfectDodgeTrail(new THREE.Vector3(0, 0, 1), 0.5);
  vfx.spawnComboFinisherBurst(new THREE.Vector3(0, 0, 2), 0.3, true);
  vfx.spawnCriticalStrikeBurst(new THREE.Vector3(0, 0, -2), 0.1);
  assert.ok(vfx.wards.some((w) => w.active));
  assert.ok(vfx.craters.some((c) => c.active));
  vfx.clearAll();
  vfx.dispose();

  const audio = new SoundEngine();
  let toneCount = 0;
  audio._tone = () => { toneCount++; };
  audio._noiseBurst = () => {};
  audio.ctx = { state: 'running', currentTime: 0, suspend: async () => {}, resume: async () => {}, close: async () => {} };

  audio.playLightAttack(0);
  audio._lastPlayed.clear();
  audio.playHeavyAttack(true);
  audio.playBossHit(true);
  audio.playPerfectParry();
  audio.playPerfectDodge();
  audio.playCriticalAttack();
  audio.playPlayerDamage();
  audio.playShieldClash();
  assert.ok(toneCount >= 14);
  audio.dispose();

  // Touch input simulation
  const eventsFired = [];
  const input = new InputController({
    onAnyInput: () => eventsFired.push('any'),
    onLight: () => eventsFired.push('light'),
    onHeavy: () => eventsFired.push('heavy'),
    onDodge: () => eventsFired.push('dodge'),
    onParry: () => eventsFired.push('parry'),
    onSkill: () => eventsFired.push('skill'),
    onLockToggle: () => eventsFired.push('lock'),
  });

  const joyZone = domRegistry.get('joystick-zone');
  joyZone.dispatchEvent({ type: 'pointerdown', pointerId: 1, clientX: 82, clientY: 222, preventDefault() {}, stopPropagation() {} });
  const mv = input.getMoveVector(camera);
  assert.ok(mv.length() > 0.5);
  windowMock.dispatchEvent({ type: 'pointerup', pointerId: 1 });
  assert.equal(input.getMoveVector(camera).length(), 0);

  for (const [id, expected] of [
    ['btn-attack', 'light'],
    ['btn-heavy', 'heavy'],
    ['btn-dodge', 'dodge'],
    ['btn-parry', 'parry'],
    ['btn-skill', 'skill'],
    ['btn-lock', 'lock'],
  ]) {
    const btn = domRegistry.get(id);
    btn.dispatchEvent({ type: 'pointerdown', pointerId: 2, preventDefault() {}, stopPropagation() {} });
    assert.equal(btn.classList.contains('pressed'), true);
    assert.ok(eventsFired.includes(expected));
    windowMock.dispatchEvent({ type: 'pointerup', pointerId: 2 });
    assert.equal(btn.classList.contains('pressed'), false);
  }

  input.dispose();
});
