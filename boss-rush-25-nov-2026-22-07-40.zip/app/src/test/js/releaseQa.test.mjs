import test from 'node:test';
import assert from 'node:assert/strict';
import module from 'node:module';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const assetsRoot = path.resolve(process.cwd(), 'app/src/main/assets');
module.registerHooks({
  resolve(specifier, context, nextResolve) {
    if (specifier === 'three') {
      return {
        url: pathToFileURL(path.join(assetsRoot, 'vendor/three.module.min.js')).href,
        shortCircuit: true,
      };
    }
    if (specifier.startsWith('/vendor/')) {
      return {
        url: pathToFileURL(path.join(assetsRoot, specifier.slice(1))).href,
        shortCircuit: true,
      };
    }
    return nextResolve(specifier, context);
  },
});

function createMockElement(id = '', allow2d = true) {
  const listeners = new Map();
  const classes = new Set();
  return {
    id,
    tagName: 'DIV',
    width: 128,
    height: 128,
    className: '',
    style: {},
    classList: {
      add: (...cls) => cls.forEach((c) => classes.add(c)),
      remove: (...cls) => cls.forEach((c) => classes.delete(c)),
      toggle: (c, force) => {
        if (force === undefined) {
          if (classes.has(c)) classes.delete(c);
          else classes.add(c);
        } else if (force) classes.add(c);
        else classes.delete(c);
      },
      contains: (c) => classes.has(c),
    },
    addEventListener(type, fn) {
      if (!listeners.has(type)) listeners.set(type, []);
      listeners.get(type).push(fn);
    },
    removeEventListener(type, fn) {
      const list = listeners.get(type);
      if (!list) return;
      const idx = list.indexOf(fn);
      if (idx >= 0) list.splice(idx, 1);
    },
    dispatchEvent(evt) {
      const list = listeners.get(evt.type) || [];
      for (const fn of [...list]) fn(evt);
    },
    getBoundingClientRect() {
      return { left: 20, top: 200, width: 124, height: 124 };
    },
    setPointerCapture() {},
    remove() {},
    getContext() {
      if (!allow2d) return null;
      return {
        fillStyle: '#000',
        strokeStyle: '#000',
        lineWidth: 1,
        fillRect() {},
        clearRect() {},
        beginPath() {},
        moveTo() {},
        lineTo() {},
        arc() {},
        ellipse() {},
        fill() {},
        stroke() {},
        save() {},
        restore() {},
        translate() {},
        rotate() {},
        createRadialGradient: () => ({ addColorStop() {} }),
        createLinearGradient: () => ({ addColorStop() {} }),
        getImageData: (_x, _y, w, h) => ({ data: new Uint8ClampedArray(w * h * 4) }),
        createImageData: (w, h) => ({ data: new Uint8ClampedArray(w * h * 4) }),
        putImageData() {},
      };
    },
  };
}

let mock2dEnabled = true;
const domRegistry = new Map([
  ['joystick-zone', createMockElement('joystick-zone')],
  ['joystick-base', createMockElement('joystick-base')],
  ['joystick-knob', createMockElement('joystick-knob')],
  ['btn-attack', createMockElement('btn-attack')],
  ['btn-heavy', createMockElement('btn-heavy')],
  ['btn-dodge', createMockElement('btn-dodge')],
  ['btn-parry', createMockElement('btn-parry')],
  ['btn-skill', createMockElement('btn-skill')],
  ['btn-lock', createMockElement('btn-lock')],
]);

const windowMock = createMockElement('window');
globalThis.window = Object.assign(windowMock, { innerWidth: 1280, innerHeight: 720 });
globalThis.document = {
  createElement: (tag) => createMockElement(tag, mock2dEnabled),
  getElementById: (id) => domRegistry.get(id) || null,
};

const THREE = await import('three');
const { GLBModelLoader, disposeObject3D } = await import('../../main/assets/game/modelManager.js');
const { CathedralArena } = await import('../../main/assets/game/arena.js');
const { VFXManager, SwordTrail } = await import('../../main/assets/game/vfx.js');
const { SoundEngine } = await import('../../main/assets/game/audio.js');
const { AdaptiveQualityController } = await import('../../main/assets/game/performance.js');
const { InputController } = await import('../../main/assets/game/controls.js');
const { PlayerCharacter, PlayerState } = await import('../../main/assets/game/player.js');
const { AshenKnightBoss, BossState } = await import('../../main/assets/game/boss.js');
const { MinionManager } = await import('../../main/assets/game/enemies.js');

const noopArena = { resolveObstacleCollision() {} };

test('GLBModelLoader caches parsed templates, deduplicates concurrent loads, isolates materials, bypasses ?t= URLs, and disposes cleanly', async () => {
  const loader = new GLBModelLoader();
  let parseCalls = 0;

  const sharedGeo = new THREE.BoxGeometry(1, 2, 1);
  let geoDisposed = 0;
  const origGeoDispose = sharedGeo.dispose.bind(sharedGeo);
  sharedGeo.dispose = () => {
    geoDisposed++;
    origGeoDispose();
  };

  loader.loader = {
    loadAsync: async () => {
      parseCalls++;
      const root = new THREE.Group();
      const mat = new THREE.MeshStandardMaterial({ color: 0x8899aa });
      const mesh = new THREE.Mesh(sharedGeo, mat);
      mesh.position.y = 1;
      root.add(mesh);
      return { scene: root, animations: [] };
    },
  };

  const [inst1, inst2] = await Promise.all([
    loader.loadAsync('/models/Knight.glb', 1.9, { enhancePBR: false }),
    loader.loadAsync('/models/Knight.glb', 1.9, { enhancePBR: false }),
  ]);

  assert.equal(parseCalls, 1);
  assert.notEqual(inst1.scene, inst2.scene);
  assert.notEqual(inst1.trackedMaterials[0], inst2.trackedMaterials[0]);

  // Disposing instance 1 must NOT dispose shared template geometry
  disposeObject3D(inst1.scene);
  assert.equal(geoDisposed, 0);

  // Dynamic ?t= custom reload URLs must bypass template cache
  const custom = await loader.loadAsync('https://bossrush.local/user-models/pending.glb?t=12345', 1.9, { enhancePBR: false });
  assert.equal(parseCalls, 2);

  disposeObject3D(inst2.scene);
  disposeObject3D(custom.scene, { includeShared: true });
  loader.clearCache();
  assert.ok(geoDisposed >= 1);
});

test('CathedralArena uses instanced meshes for curbs/spires and survives null 2D canvas contexts', () => {
  const scene = new THREE.Scene();
  const arena = new CathedralArena(scene);
  const instanced = [];
  scene.traverse((obj) => {
    if (obj.isInstancedMesh) instanced.push(obj);
  });
  assert.ok(instanced.some((m) => m.count === 30), 'Expected 30 instanced parapet curbs');
  assert.ok(instanced.some((m) => m.count === 8), 'Expected 8 instanced outer spires');
  arena.dispose();

  mock2dEnabled = false;
  try {
    const fallbackScene = new THREE.Scene();
    const fallbackArena = new CathedralArena(fallbackScene);
    assert.ok(fallbackArena.group);
    fallbackArena.dispose();
  } finally {
    mock2dEnabled = true;
  }
});

test('SoundEngine supports masterVolume, respects mute state, and handles AudioContext failure gracefully', () => {
  const audio = new SoundEngine();
  let lastSetTarget = null;
  audio.ctx = {
    state: 'running',
    currentTime: 1,
    suspend: async () => {},
    resume: async () => {},
    close: async () => {},
  };
  audio.master = {
    gain: {
      value: 0.78,
      setTargetAtTime(val) {
        lastSetTarget = val;
      },
    },
  };

  audio.setMasterVolume(0.5);
  assert.equal(audio.masterVolume, 0.5);
  assert.ok(Math.abs(lastSetTarget - 0.39) < 1e-4);

  audio.setMuted(true);
  assert.equal(lastSetTarget, 0);
  audio.setMuted(false);
  assert.ok(Math.abs(lastSetTarget - 0.39) < 1e-4);
  audio.dispose();

  // AudioContext throwing must not crash caller
  const prevAudioCtx = globalThis.window.AudioContext;
  globalThis.window.AudioContext = function ThrowingAudioContext() {
    throw new Error('Audio hardware unavailable');
  };
  try {
    const brokenAudio = new SoundEngine();
    brokenAudio.unlock();
    assert.equal(brokenAudio.initFailed, true);
    assert.equal(brokenAudio.ctx, null);
    brokenAudio.playLightAttack(0);
    brokenAudio.dispose();
  } finally {
    globalThis.window.AudioContext = prevAudioCtx;
  }
});

test('SwordTrail shares single GPU texture across instances and disposes when last reference releases', () => {
  const scene = new THREE.Scene();
  const t1 = new SwordTrail(scene, 12, 0x62d9ff);
  const t2 = new SwordTrail(scene, 12, 0xff4b1f);
  assert.ok(t1.trailTex);
  assert.equal(t1.trailTex, t2.trailTex);

  let texDisposed = 0;
  const origDispose = t1.trailTex.dispose.bind(t1.trailTex);
  t1.trailTex.dispose = () => {
    texDisposed++;
    origDispose();
  };

  t1.dispose();
  assert.equal(texDisposed, 0);
  t2.dispose();
  assert.equal(texDisposed, 1);

  const vfx = new VFXManager(scene, new THREE.PerspectiveCamera(55, 1.77, 0.1, 140));
  const slot1 = vfx._acquireSlot(vfx.hitFlashes, true);
  slot1.active = true;
  const slot2 = vfx._acquireSlot(vfx.hitFlashes, true);
  assert.notEqual(slot1, slot2);
  vfx.dispose();
});

test('AdaptiveQualityController exposes LOW/MEDIUM/HIGH profiles with expected shadow & pixelRatio bounds', () => {
  const low = new AdaptiveQualityController('LOW', 2.5).getEffectiveProfile();
  const med = new AdaptiveQualityController('MEDIUM', 2.5).getEffectiveProfile();
  const high = new AdaptiveQualityController('HIGH', 2.5).getEffectiveProfile();

  assert.equal(low.shadowsEnabled, false);
  assert.ok(low.pixelRatio <= 1.0);
  assert.equal(med.shadowsEnabled, true);
  assert.ok(med.pixelRatio <= 1.4);
  assert.equal(high.shadowsEnabled, true);
  assert.ok(high.pixelRatio <= 2.0);
  assert.ok(low.pixelRatio < med.pixelRatio && med.pixelRatio < high.pixelRatio);
});

test('InputController.clearTransient clears stuck pressed states and joystick offsets on blur', () => {
  const camera = new THREE.PerspectiveCamera(55, 1.77, 0.1, 140);
  const input = new InputController({});
  const btn = domRegistry.get('btn-attack');
  btn.dispatchEvent({ type: 'pointerdown', pointerId: 9, preventDefault() {}, stopPropagation() {} });
  assert.equal(btn.classList.contains('pressed'), true);

  windowMock.dispatchEvent({ type: 'blur' });
  assert.equal(btn.classList.contains('pressed'), false);
  assert.equal(input.getMoveVector(camera).length(), 0);
  input.dispose();
});

test('End-to-end combat lifecycle: boss Phase 2 trigger, minion wave spawn/clear, boss defeat, and player defeat', () => {
  const scene = new THREE.Scene();
  const boss = new AshenKnightBoss(scene);
  const player = new PlayerCharacter(scene);
  const minions = new MinionManager(scene);
  const noopVfx = { spawnMagicBurst() {}, spawnSparks() {}, spawnSmoke() {}, spawnFloatingText() {} };
  const noopAudio = { playFireBurst() {}, playEnemyDeath() {}, playShieldClash() {} };

  // Phase 2 transition occurs cleanly once below 55% HP
  const resP2 = boss.takeDamage(Math.round(boss.maxHp * 0.5), 20, false, true);
  assert.equal(resP2.triggeredPhase2, true);
  assert.equal(boss.phase, 2);
  assert.equal(boss.state, BossState.ENRAGED);

  // Boss is invulnerable during ENRAGED transition animation
  const invulnRes = boss.takeDamage(500, 0, false, false);
  assert.equal(invulnRes.damage, 0);

  // Finish ENRAGED transition so boss returns to combat
  boss.state = BossState.APPROACH;
  boss.stateTime = 0;

  // Minion wave spawns and dies cleanly
  minions.spawnReinforcements(['cinder_imp', 'obsidian_sentinel'], boss.root.position, noopVfx, noopAudio);
  assert.equal(minions.minions.length, 2);
  for (const m of minions.minions) {
    m.takeDamage(9999, player.root.position, true, noopVfx, noopAudio, noopArena);
    assert.equal(m.state, 'DEAD');
  }

  // Boss defeat
  const resKill = boss.takeDamage(boss.hp + 500, 0, true, true);
  assert.equal(resKill.defeated, true);
  assert.equal(boss.state, BossState.DEFEATED);

  // Player defeat
  player.reset();
  assert.equal(player.takeDamage(9999, boss.root.position, noopArena), true);
  assert.equal(player.state, PlayerState.DEATH);
  assert.equal(player.hp, 0);

  minions.dispose();
  player.dispose();
  boss.dispose();
});
