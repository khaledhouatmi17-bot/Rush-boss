import test from 'node:test';
import assert from 'node:assert/strict';
import module from 'node:module';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

const assetsRoot = path.resolve(process.cwd(), 'app/src/main/assets');
module.registerHooks({
  resolve(specifier, context, nextResolve) {
    if (specifier === 'three') {
      return {
        url: pathToFileURL(path.join(assetsRoot, 'vendor/three.module.min.js')).href,
        shortCircuit: true,
      };
    }
    if (specifier.startsWith('/vendor/')) {
      return {
        url: pathToFileURL(path.join(assetsRoot, specifier.slice(1))).href,
        shortCircuit: true,
      };
    }
    return nextResolve(specifier, context);
  },
});

function createMock2DContext(canvas) {
  return {
    fillStyle: '#000',
    strokeStyle: '#000',
    lineWidth: 1,
    fillRect() {},
    clearRect() {},
    beginPath() {},
    moveTo() {},
    lineTo() {},
    arc() {},
    ellipse() {},
    fill() {},
    stroke() {},
    save() {},
    restore() {},
    translate() {},
    rotate() {},
    createRadialGradient() {
      return { addColorStop() {} };
    },
    createLinearGradient() {
      return { addColorStop() {} };
    },
    getImageData(_x, _y, w, h) {
      return { data: new Uint8ClampedArray(w * h * 4) };
    },
    createImageData(w, h) {
      return { data: new Uint8ClampedArray(w * h * 4) };
    },
    putImageData() {},
  };
}

if (!globalThis.document || !globalThis.__qaDomInstalled) {
  globalThis.__qaDomInstalled = true;
  globalThis.document = {
    createElement: (tag) => {
      const el = {
        tagName: tag,
        width: 128,
        height: 128,
        className: '',
        style: {},
        classList: { add() {}, remove() {}, toggle() {} },
        addEventListener() {},
        remove() {},
      };
      if (tag === 'canvas') {
        el.getContext = () => createMock2DContext(el);
      }
      return el;
    },
    getElementById: () => null,
  };
}

const THREE = await import('three');
const { MinionManager, MinionEnemy } = await import('../../main/assets/game/enemies.js');
const {
  GLBAnimationController,
  computeVisibleBoundingBox,
  markSharedResources,
} = await import('../../main/assets/game/modelManager.js');
const { PlayerCharacter, PlayerState } = await import('../../main/assets/game/player.js');
const { AshenKnightBoss, BossState, BossAttackType } = await import('../../main/assets/game/boss.js');
const { VFXManager, SwordTrail } = await import('../../main/assets/game/vfx.js');
const { CathedralArena } = await import('../../main/assets/game/arena.js');
const { CombatCamera } = await import('../../main/assets/game/camera.js');
const { SoundEngine } = await import('../../main/assets/game/audio.js');
const { AdaptiveQualityController } = await import('../../main/assets/game/performance.js');
const {
  applyStylizedRimShader,
  updateRimShaderUniforms,
  createCharacterAuraRing,
} = await import('../../main/assets/game/stylized.js');

function makeClip(name, duration = 1.0) {
  const track = new THREE.QuaternionKeyframeTrack(
    '.quaternion',
    [0, duration],
    [0, 0, 0, 1, 0, 0, 0, 1]
  );
  return new THREE.AnimationClip(name, duration, [track]);
}

test('MinionManager isolates cloned materials per instance and preserves shared template geometry/textures until manager disposal', () => {
  const scene = new THREE.Scene();
  const mgr = new MinionManager(scene);

  const sharedGeo = new THREE.BoxGeometry(0.5, 1.5, 0.5);
  const sharedTex = new THREE.DataTexture(new Uint8Array([255, 255, 255, 255]), 1, 1);
  const templateMat = new THREE.MeshStandardMaterial({ color: 0x999999, map: sharedTex });
  const templateMesh = new THREE.Mesh(sharedGeo, templateMat);
  const templateRoot = new THREE.Group();
  templateRoot.add(templateMesh);

  let geoDisposed = 0;
  let texDisposed = 0;
  const origGeoDispose = sharedGeo.dispose.bind(sharedGeo);
  const origTexDispose = sharedTex.dispose.bind(sharedTex);
  sharedGeo.dispose = () => {
    geoDisposed++;
    origGeoDispose();
  };
  sharedTex.dispose = () => {
    texDisposed++;
    origTexDispose();
  };

  mgr.setCustomTemplate(templateRoot, [makeClip('Idle')]);
  const noopVfx = { spawnMagicBurst() {}, spawnSparks() {}, spawnSmoke() {}, spawnFloatingText() {} };
  const noopAudio = { playFireBurst() {}, playEnemyDeath() {}, playShieldClash() {} };

  mgr.spawnReinforcements(['cinder_imp', 'cinder_imp'], new THREE.Vector3(0, 0, 0), noopVfx, noopAudio);
  assert.equal(mgr.minions.length, 2);

  const [m0, m1] = mgr.minions;
  assert.notEqual(m0.trackedMaterials[0], m1.trackedMaterials[0]);

  let m0MatDisposed = 0;
  const origM0MatDispose = m0.trackedMaterials[0].dispose.bind(m0.trackedMaterials[0]);
  m0.trackedMaterials[0].dispose = () => {
    m0MatDisposed++;
    origM0MatDispose();
  };

  // Hit flash on m0 must not bleed onto m1
  m0.hitFlash = 0.2;
  m0.update(0.016, 0.016, new THREE.Vector3(0, 0, 5), { resolveObstacleCollision() {} }, () => {});
  m1.update(0.016, 0.016, new THREE.Vector3(0, 0, 5), { resolveObstacleCollision() {} }, () => {});
  assert.ok(m0.trackedMaterials[0].emissiveIntensity > 0);
  assert.equal(m1.trackedMaterials[0].emissiveIntensity, 0);

  // Disposing minion 0 destroys its cloned material but spares shared template geometry & texture
  m0.dispose();
  assert.equal(m0MatDisposed, 1);
  assert.equal(geoDisposed, 0);
  assert.equal(texDisposed, 0);

  // Removing m0 manually and disposing manager cleans up shared template resources too
  mgr.minions = [m1];
  mgr.dispose();
  assert.equal(geoDisposed, 1);
  assert.equal(texDisposed, 1);
});

test('MinionEnemy.applyCustomGLB preserves y=0 foot grounding when equipVariant scales the model', () => {
  const scene = new THREE.Scene();
  const imp = new MinionEnemy(scene, 'cinder_imp', new THREE.Vector3(2, 0, 0));
  const sentinel = new MinionEnemy(scene, 'obsidian_sentinel', new THREE.Vector3(-2, 0, 0));

  const meshGeo = new THREE.BoxGeometry(0.6, 2.0, 0.6); // local min.y = -1.0
  const impVisual = new THREE.Group();
  impVisual.add(new THREE.Mesh(meshGeo, new THREE.MeshStandardMaterial()));
  impVisual.position.y = 1.0; // grounded at y = 0 before equip scaling

  const sentVisual = new THREE.Group();
  sentVisual.add(new THREE.Mesh(meshGeo, new THREE.MeshStandardMaterial()));
  sentVisual.position.y = 1.0;

  imp.applyCustomGLB(impVisual, [makeClip('Idle')], 'cinder_imp');
  sentinel.applyCustomGLB(sentVisual, [makeClip('Idle')], 'obsidian_sentinel');

  impVisual.updateMatrixWorld(true);
  sentVisual.updateMatrixWorld(true);
  const impBox = new THREE.Box3().setFromObject(impVisual);
  const sentBox = new THREE.Box3().setFromObject(sentVisual);

  assert.ok(Math.abs(impBox.min.y) < 1e-4, `Expected imp foot at y=0, got ${impBox.min.y}`);
  assert.ok(Math.abs(sentBox.min.y) < 1e-4, `Expected sentinel foot at y=0, got ${sentBox.min.y}`);

  imp.dispose();
  sentinel.dispose();
  meshGeo.dispose();
});

test('computeVisibleBoundingBox excludes hidden helper/spare weapon nodes and GLBAnimationController resets loop state after DEATH', () => {
  const root = new THREE.Group();
  const body = new THREE.Mesh(new THREE.BoxGeometry(1, 2, 1), new THREE.MeshBasicMaterial());
  body.position.y = 1; // y: 0..2
  const hiddenSpareSword = new THREE.Mesh(new THREE.BoxGeometry(0.2, 8, 0.2), new THREE.MeshBasicMaterial());
  hiddenSpareSword.position.y = 2;
  hiddenSpareSword.visible = false; // hidden y: -2..6
  root.add(body);
  root.add(hiddenSpareSword);

  const visibleBox = computeVisibleBoundingBox(root);
  assert.ok(Math.abs(visibleBox.min.y - 0) < 1e-4);
  assert.ok(Math.abs(visibleBox.max.y - 2) < 1e-4);

  // Only has Idle clip -> DEATH falls back to Idle with LoopOnce + clampWhenFinished
  const ctrl = new GLBAnimationController(root, [makeClip('Idle', 0.5)]);
  ctrl.playState('DEATH', true, 1.0, 0.05);
  ctrl.update(1.0, 'DEATH', 1.0, false); // reaches end and clamps
  assert.equal(ctrl.currentAction.clampWhenFinished, true);

  // Resetting back to IDLE must restore LoopRepeat and running state
  ctrl.playState('IDLE', false, 1.0, 0.1);
  assert.equal(ctrl.currentStateKey, 'IDLE');
  assert.equal(ctrl.currentAction.loop, THREE.LoopRepeat);
  assert.equal(ctrl.currentAction.clampWhenFinished, false);
  assert.equal(ctrl.currentAction.isRunning(), true);
  ctrl.dispose();
});

test('Player SKILL whirlwind VFX and Boss HEAVY_OVERHEAD slam VFX fire at hitbox/impact timing rather than state boundaries', () => {
  const scene = new THREE.Scene();
  const noopArena = { resolveObstacleCollision() {} };

  const player = new PlayerCharacter(scene);
  let skillCastCalls = 0;
  let skillUnleashCalls = 0;
  const events = {
    onSkillCast: () => skillCastCalls++,
    onSkillUnleash: () => skillUnleashCalls++,
    onSlashArc() {},
  };

  assert.equal(player.triggerSkill(new THREE.Vector3(0, 0, 0)), true);
  // Early windup frame (< 0.18s): hitbox inactive, unleash VFX not yet spawned
  player.update(0.05, 0.05, new THREE.Vector3(), new THREE.Vector3(0, 0, 0), noopArena, true, events);
  assert.equal(player.getActiveAttackInfo(), null);
  assert.equal(skillUnleashCalls, 0);

  // Advance across t = 0.18s hitbox opening
  player.update(0.14, 0.19, new THREE.Vector3(), new THREE.Vector3(0, 0, 0), noopArena, true, events);
  assert.ok(player.getActiveAttackInfo() !== null);
  assert.equal(skillUnleashCalls, 1);

  // Boss HEAVY_OVERHEAD slam VFX must fire around 0.52 * activeDur, before attack transitions to RECOVERY
  const boss = new AshenKnightBoss(scene);
  boss.state = BossState.ATTACK;
  boss.currentAttack = BossAttackType.HEAVY_OVERHEAD;
  boss.stateTime = 0;
  boss.shockwaveFired = false;

  let craterCalls = 0;
  let shockwaveAudioCalls = 0;
  const mockVfx = {
    spawnSparks() {},
    spawnSmoke() {},
    spawnGroundCrater: () => craterCalls++,
    spawnHitFlash() {},
    showCircleTelegraph() {},
    showDashTelegraph() {},
    hideTelegraphs() {},
  };
  const mockAudio = {
    playShockwave: () => shockwaveAudioCalls++,
    playFootstep() {},
    playSwordSwing() {},
  };

  // HEAVY_OVERHEAD activeDur = 0.32 -> 0.52 * 0.32 = 0.1664s
  boss.update(0.1, 0.1, player.root.position, noopArena, mockVfx, mockAudio, {
    onHeavyImpact() {},
    onBossMeleeHit() {},
  });
  assert.equal(boss.state, BossState.ATTACK);
  assert.equal(craterCalls, 0);

  boss.update(0.08, 0.18, player.root.position, noopArena, mockVfx, mockAudio, {
    onHeavyImpact() {},
    onBossMeleeHit() {},
  });
  assert.equal(boss.state, BossState.ATTACK); // Still in active swing!
  assert.equal(craterCalls, 1);
  assert.equal(shockwaveAudioCalls, 1);

  player.dispose();
  boss.dispose();
});

test('VFXManager.clearAll empties active particle slots and CathedralArena adaptive quality + dispose execute cleanly', () => {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(55, 1.77, 0.1, 140);
  const vfx = new VFXManager(scene, camera);

  vfx.spawnSparks({ x: 0, y: 1, z: 0 }, 25, 0xffaa33, 6, 10);
  vfx.spawnHitFlash({ x: 0, y: 1, z: 0 });
  vfx.spawnGroundCrater({ x: 0, y: 0, z: 0 });
  assert.ok(vfx.pLife.some((life) => life > 0));

  vfx.clearAll();
  assert.ok(vfx.pLife.every((life) => life === 0));
  for (let i = 0; i < vfx.maxParticles; i++) {
    assert.equal(vfx.pPositions[i * 3 + 1], -999);
  }
  assert.equal(vfx.pCursor, 0);
  vfx.dispose();

  const arena = new CathedralArena(scene);
  arena.applyRenderQuality({ shadowsEnabled: true, shadowMapSize: 512, arenaAdaptiveLevel: 1 });
  assert.equal(arena.mistGroup.visible, false);
  assert.equal(arena.embers.visible, true);
  assert.equal(arena.brazierLights.filter((b) => b.light.visible).length, 2);

  arena.applyRenderQuality({ shadowsEnabled: false, shadowMapSize: 512, arenaAdaptiveLevel: 2 });
  assert.equal(arena.embers.visible, false);
  assert.equal(arena.brazierLights.every((b) => !b.light.visible), true);

  arena.dispose();
});

test('SoundEngine prevents simultaneous multi-target impact stacking and repeated victory/defeat chimes', () => {
  const audio = new SoundEngine();
  let toneCount = 0;
  audio._tone = () => {
    toneCount++;
  };
  audio._noiseBurst = () => {};
  audio.ctx = { state: 'running', currentTime: 0, suspend: async () => {}, resume: async () => {}, close: async () => {} };

  // Calling flesh impact + armor impact on the same frame must only trigger once via shared 'impact_any' throttle
  audio.playImpact(false, false);
  const afterFirst = toneCount;
  assert.ok(afterFirst > 0);
  audio.playImpact(false, true);
  assert.equal(toneCount, afterFirst);

  toneCount = 0;
  audio.playVictory();
  const afterVictory = toneCount;
  assert.ok(afterVictory > 0);
  audio.playVictory();
  assert.equal(toneCount, afterVictory);

  toneCount = 0;
  audio.playDefeat();
  const afterDefeat = toneCount;
  assert.ok(afterDefeat > 0);
  audio.playDefeat();
  assert.equal(toneCount, afterDefeat);

  audio.suspend();
  audio.resumeIfNeeded();
  audio.dispose();
});

test('AdaptiveQualityController steps down under sustained slow frames and recovers smoothly under fast frames', () => {
  const changes = [];
  const perf = new AdaptiveQualityController('MEDIUM', 2.0, (p) => changes.push(p));

  assert.equal(perf.stepLevel, 0);

  // Clamped tab-resume spikes (>= 0.049) must be ignored
  for (let i = 0; i < 60; i++) {
    assert.equal(perf.recordFrame(0.05), false);
  }
  assert.equal(perf.stepLevel, 0);

  // Warmup frames (12) + sustained ~30fps (0.033s) -> triggers stepLevel 1 then 2
  for (let i = 0; i < 12; i++) perf.recordFrame(0.016);
  for (let i = 0; i < 90; i++) perf.recordFrame(0.033);
  assert.ok(perf.stepLevel >= 1);

  for (let i = 0; i < 90; i++) perf.recordFrame(0.033);
  assert.equal(perf.stepLevel, 2);
  const lowProfile = perf.getEffectiveProfile();
  assert.equal(lowProfile.shadowsEnabled, false);
  assert.equal(lowProfile.arenaAdaptiveLevel, 2);
  assert.ok(lowProfile.vfxScale < 1);

  // Sustained ~60fps (0.016s) -> smooth hysteresis recovery back to stepLevel 0
  for (let i = 0; i < 320; i++) perf.recordFrame(0.016);
  assert.equal(perf.stepLevel, 1);
  for (let i = 0; i < 320; i++) perf.recordFrame(0.016);
  assert.equal(perf.stepLevel, 0);
  assert.ok(changes.length >= 4);
});

test('Visual Overhaul V1: dynamic rim uniforms, arena shafts, directional/parry/crit/phase2 VFX, and character aura rings work and dispose cleanly', () => {
  const rimMat = new THREE.MeshStandardMaterial({ color: 0x667788 });
  applyStylizedRimShader(rimMat, 0x52d6ff, 0.52);
  assert.equal(rimMat.userData.hasStylizedRim, true);
  assert.equal(rimMat.customProgramCacheKey(), 'stylized-rim-v2');
  updateRimShaderUniforms([rimMat], 0xffaa33, 0.78);
  assert.equal(rimMat.userData.rimStrength, 0.78);
  assert.equal(rimMat.userData.rimColor.getHex(), 0xffaa33);
  rimMat.dispose();

  const auraRing = createCharacterAuraRing(0xff5518, 1.4, 1.8, 0.45);
  assert.ok(auraRing.isMesh);
  auraRing.geometry.dispose();
  auraRing.material.dispose();

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(55, 1.77, 0.1, 140);

  const arena = new CathedralArena(scene);
  assert.ok(arena.shaftGroup);
  assert.equal(arena.shaftMeshes.length, 5);
  assert.ok(arena.embers.geometry.getAttribute('color'));
  arena.update(0.016, 1.0);
  arena.applyRenderQuality({ shadowsEnabled: true, shadowMapSize: 1024, arenaAdaptiveLevel: 1 });
  assert.equal(arena.shaftGroup.visible, true);
  arena.applyRenderQuality({ shadowsEnabled: false, shadowMapSize: 512, arenaAdaptiveLevel: 2 });
  assert.equal(arena.shaftGroup.visible, false);
  arena.dispose();

  const vfx = new VFXManager(scene, camera);
  const pos = new THREE.Vector3(1, 0, 2);
  vfx.spawnDirectionalHitFlash(pos, 0.4, 0.25, 0xffe699, 2.2);
  vfx.spawnParryBurst(pos, 0.4);
  vfx.spawnCritImpact(pos, 0.4, true);
  vfx.spawnPhase2ArenaPulse(pos);
  vfx.showCircleTelegraph(0, 0, 3.5, 0.8, 0xff3b1f);
  vfx.showDashTelegraph(0, 0, 0.5, 10, 0.7);

  assert.ok(vfx.directionalFlashes.some((d) => d.active));
  assert.ok(vfx.phase2Columns.some((c) => c.active));
  assert.equal(vfx.circleTelegraph.visible, true);
  assert.equal(vfx.laneTelegraph.visible, true);

  vfx.update(0.1);
  vfx.clearAll();
  assert.ok(vfx.directionalFlashes.every((d) => !d.active));
  assert.ok(vfx.phase2Columns.every((c) => !c.active));
  assert.equal(vfx.circleTelegraph.visible, false);
  assert.equal(vfx.laneTelegraph.visible, false);
  vfx.dispose();

  const player = new PlayerCharacter(scene);
  assert.ok(player.auraRing);
  player.dispose();

  const boss = new AshenKnightBoss(scene);
  assert.ok(boss.bossAuraRing);
  const glbRoot = new THREE.Group();
  const glbMat = applyStylizedRimShader(new THREE.MeshStandardMaterial({ color: 0x888888 }), 0xff6a24, 0.56);
  glbRoot.add(new THREE.Mesh(new THREE.BoxGeometry(1, 3, 1), glbMat));
  boss._applyGLBVisual(glbRoot, [makeClip('Idle')], null, null, [glbMat], null, false);
  boss._applyPhaseVisuals(2);
  assert.equal(glbMat.userData.rimStrength, 0.78);
  assert.equal(boss.bossAuraRing.material.color.getHex(), 0xffaa33);
  boss.dispose();
});

test('Cinematic Visual Upgrade V2: arena lava cracks/debris, layered telegraphs, sword trail/aura, boss dark aura & Phase II crown, and camera impact kick', () => {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(55, 1.77, 0.1, 140);

  const arena = new CathedralArena(scene);
  assert.ok(arena.lavaCrackMat);
  assert.ok(arena.debrisGroup);
  assert.ok(arena.debrisGroup.children.length >= 16);
  arena.triggerBossAttackGlow(1.2);
  assert.ok(arena.bossAttackGlow >= 1.1);
  arena.update(0.016, 0.5);
  assert.ok(arena.lavaCrackMat.opacity > 0.15);
  arena.applyRenderQuality({ shadowsEnabled: false, shadowMapSize: 512, arenaAdaptiveLevel: 2 });
  assert.equal(arena.debrisGroup.visible, false);
  assert.equal(arena.lavaCrackMesh.visible, false);
  arena.applyRenderQuality({ shadowsEnabled: true, shadowMapSize: 1024, arenaAdaptiveLevel: 0 });
  assert.equal(arena.debrisGroup.visible, true);
  assert.equal(arena.lavaCrackMesh.visible, true);
  arena.dispose();

  const vfx = new VFXManager(scene, camera);
  assert.ok(vfx.circleMidRing);
  assert.ok(vfx.shockwaves.every((sw) => !!sw.innerMat));
  vfx.showCircleTelegraph(0, 0, 4.0, 0.85, 0xff3b1f);
  assert.ok(vfx.circleMidMat.opacity > 0.3);
  vfx.spawnPhase2ArenaPulse(new THREE.Vector3(0, 0, 0));
  assert.equal(vfx.phase2Columns.filter((c) => c.active).length, 2);
  vfx.dispose();

  const trail = new SwordTrail(scene, 12, 0x62d9ff);
  assert.ok(trail.mesh.geometry.getAttribute('uv'));
  trail.update(true, new THREE.Vector3(0, 1, 0), new THREE.Vector3(0, 2, 1));
  assert.equal(trail.mesh.visible, true);
  trail.dispose();

  const player = new PlayerCharacter(scene);
  assert.ok(player.swordEnergySprite);
  player.update(0.016, 0.5, new THREE.Vector3(), new THREE.Vector3(0, 0, 0), { resolveObstacleCollision() {} }, true, {});
  assert.equal(player.swordEnergySprite.visible, true);
  player.dispose();

  const boss = new AshenKnightBoss(scene);
  assert.ok(boss.darkEnergyAura);
  assert.ok(boss.phase2CrownRing);
  assert.equal(boss.phase2CrownRing.visible, false);
  boss._applyPhaseVisuals(2);
  assert.equal(boss.phase2CrownRing.visible, true);
  boss.dispose();

  const camCtrl = new CombatCamera(camera);
  camCtrl.snapToCombat(new THREE.Vector3(0, 0, 9.5), new THREE.Vector3(0, 0, -7.5));
  camCtrl.addImpactKick(0, -1, 0.3);
  assert.ok(camCtrl.impactOffset.lengthSq() > 0);
  camCtrl.update(0.016, 0.1, 'COMBAT', 0, new THREE.Vector3(0, 0, 9.5), new THREE.Vector3(0, 0, -7.5), null);
  assert.ok(Number.isFinite(camera.position.x) && camera.position.y >= 1.2);
});

